/**
	mduc 用户控制模块
 */
 var user_ctr = require("../controllers/user"),
 	co= 		require("co"),
 	config= 	require("./config"),
 	logger= 	require("./logger"),
 	proxy= 		require("./proxy"),
 	crypto= 	require('crypto'),
 	debug= 		require("debug")("util-mduc");
	var wechats= {
		"m-dev.intpayment.cn": {
			AppID: 		"wx0c3488a88f41f5e4",
			AppSecret: 	"84ff2b2116ec33e146fc9387d079737f",
			domain: 	"m-dev.intpayment.cn"
		},
		"m-pl.intpayment.cn": {
			AppID: 		"wx7dba12ce6b2e0dbe",
			AppSecret: 	"db144458cadf432610faccccc05c5b2f",
			domain: 	"m-pl.intpayment.cn"
		},
		"m.intpayment.cn": {
			AppID: 		"wxc20597f48329631c",
			AppSecret: 	"d1dcd7a71d94708d77bbb3899ed6597f",
			domain: 	"m.intpayment.cn"
		}
	};

function Mduc(){
	this.wxstate= 0;
	this.wxsteps= [];
}

Mduc.prototype= {
	constructor: Mduc,
	init: function(){
		var self= this;
		self.cfg_domain= config.domain.substring(7);
		return self;
	},
	setEnv: function(req, res){
		var self= this;
		self.wxsteps.push("------------------------UC("+ (+new Date())+ ")------------------------");
		if(res.locals.config.isWeixin){
			return self.doWXAuth(req, res);
		}else{
			return self.doNoAuth(req, res);
		}
	},
	checkUser: function(){

	},
	doWXAuth: function(req, res){
		var self=  		this,
			wechat= 	req.session.wechat||{},
			we_stat= 	wechat.status|| 1,
			we_cur= 	wechat.current||{},
			we_list= 	wechat.list||{},
			we_any_openids= [],
			we_any_unionid= "";
			we_cur.openid&& (req.session.wechat.openid= we_cur.openid);
		for(var k in we_list){
			if(req.hostname=== k){
				we_cur= wechat.current= we_list[k];
			}
			we_any_openids.push(we_list[k].openid);
			we_any_unionid= we_any_unionid|| we_list[k].unionid;
		}
		we_any_unionid&& (we_cur.unionid= we_any_unionid);
		self.wxsteps.push("2 doWXAuth");
		self.wxsteps.push(wechat);
		var query= req.query;
		//经过多次授权的异常情况会出现多个state，code
		if(query.state instanceof Array){
			query.state= query.state.pop();
		}
		if(query.code instanceof Array){
			query.code= query.code.pop();
		}
		self.wxstate= 100;
		//状态处理 10x
		(function(){
			/**
				1 判断是否分流
			*/
			if(!we_cur.AppID){
			 	self.wxstate= 10;
			}else if(req.hostname!== we_cur.domain){
			 	//必须使用域名对应的appid进行微信相关操作
			 	self.wxstate= 11;
			}else if(!we_cur.openid){
				self.wxstate= 20;
			}else if(!we_cur.unionid){
				self.wxstate= 30;
			}else if(self.cfg_domain=== req.hostname){
				self.wxstate= 35;
			}
			/**
				2 判读是否在授权流程中
			 */
			if(query.code&& /\w{32}/.test(query.code) ){
				if(20== query.state&& 20=== self.wxstate){
					self.wxstate= 25;
				}else if(40== query.state&& 30=== self.wxstate){
					self.wxstate= 25;
				}
			}
			self.wxsteps.push("wxstate: "+ self.wxstate);
		})();
		// get appid -> get openid -> get uc -> get unionid -> end

		return co(function*(){
			self.wxsteps.push("3 ... ...");
			var y_appid,
				y_openid,
				y_uc,
				y_unionid;
			if(25!== self.wxstate&& 35!== self.wxstate){
				y_appid= yield getAppid({domain: req.hostname});
				if(y_appid.AppID!== we_cur.AppID|| 11== self.wxstate){
					we_cur= wechat.current= y_appid;
					self.wxstate= 20;
				}
				self.wxsteps.push("wxstate[10/11]-y_appid: " );
			}
			//to openid
			if(20=== self.wxstate){
				var args= {
					scope: 			"snsapi_base",
					redirect_uri: 	encodeURIComponent(self.getWxUrl({type: "redirect", hostname: we_cur.domain}, req, res) ),
					type: 			"wxauth",
					state: 			20,
					AppID: 			we_cur.AppID
				},
				wxauthurl= self.getWxUrl(args);
				self.wxsteps.push("wxstate[10/11]-go wxpage: " );
				self.wxsteps.push("wxstate[10/11]-go authurl: "+ wxauthurl);
				res.redirect(wxauthurl );
				return "redirect";
			}
			//code-> openid
			if(25=== self.wxstate){
				self.wxsteps[0]= "----------wx back("+ (+new Date())+ ")--->";
				var args= {
					CODE: 		query.code,
					AppID: 		we_cur.AppID,
					AppSecret: 	we_cur.AppSecret
				};
				y_openid= yield getWxInfo(args);
				(40== query.state&& y_openid.unionid)&& (we_cur.unionid= y_openid.unionid);
				we_cur.openid= 	y_openid.openid;
				if(!we_cur.unionid){
					self.wxstate= 30;
				}else{
					//bind appid openid unionid
					var _args= {
						union_id: y_openid.unionid,
						union_id_data: {
							[we_cur.AppID]: we_cur.openid
						}
					};
					for(var k in we_list){
						_args.union_id_data[we_list[k]["AppID"]]= we_list[k]["openid"];
					}
					//获取微信详情
					yield getUserWx({
						access_token: y_openid.access_token,
						openid: y_openid.openid
					}).then(function(result){
						_args.open_id_type = 500;
						setWxcommon(_args, result);
						wechat.headimgurl= result.headimgurl;
						wechat.nickname= result.nickname;
						self.wxsteps.push("wxstate[25-02]-set wx common: " );
						module.exports.doWXBind(req, res);
					}).catch(function(e){
						self.wxsteps.push("wxstate[25-02]-set_error: " );
						setWxcommon(_args);
						console.log(e);
					});
					self.wxsteps.push("wxstate[25-01]-get user wx: " );
					self.wxstate= 100;
				}
				self.wxsteps.push("wxstate[25]-y_openid: " );
			}
			//get uc
			if(30=== self.wxstate){
				var args= { openid: "", app_id: ""},
					ids= [we_cur.openid],
					aids=[we_cur.AppID],
					has= false;
				for(var k in we_list){
					ids.push(we_list[k].openid);
					aids.push(we_list[k].AppID);
				}
				args.openid= ids.join(",");
				args.app_id= aids.join(",");
				args.open_id_type = 500;
				y_uc= yield getWxcommon(args);
				if("[object Object]"=== Object.prototype.toString.call(y_uc) ){
					for(var k in we_list){
						var openid= we_list[k].openid;
						if(y_uc[openid].unionid){
							we_list[k].unionid= y_uc[openid].unionid;
							y_uc[openid].wid&& (self.wid= y_uc[openid].wid);
							has= true;
						}
					}
					if(y_uc[we_cur.openid].union_id){
						we_cur.unionid= y_uc[we_cur.openid].union_id;
						y_uc[we_cur.openid].wid&& (self.wid= y_uc[we_cur.openid].wid);
						has= true;
					}
				}
				//is main domain
				if(self.cfg_domain=== req.hostname){
					self.wxstate= 35;
				}else{
					self.wxstate= has? 100: 40;
				}
				self.wxsteps.push("wxstate[30]-y_uc: "+ JSON.stringify(y_uc) );
			}
			//
			if(35=== self.wxstate){
				var y_appid2= yield getAppid2({union_id: we_cur.unionid|| "", ip_address: res.locals.config.clientIp, domain: we_cur.domain});
				self.wxsteps.push("wxstate[50]-y_appid2: " );
				if(y_appid2.domain!== req.hostname){
					wechat.list[we_cur.domain]= we_cur;
					req.session.save();
					res.redirect(self.getWxUrl({type: "original", hostname: y_appid2.domain}, req, res) );
					self.wxsteps.push("wxstate[50-02]-red new domain: " );
					return "redirect";
				}else if(!we_cur.unionid){
					self.wxstate= 40;
				}else{
					self.wxstate= 100;
				}
			}
			//to unionid
			if(40=== self.wxstate){
				var args= {
					scope: 			"snsapi_userinfo",
					redirect_uri: 	encodeURIComponent(self.getWxUrl({type: "redirect", hostname: we_cur.domain}, req, res) ),
					type: 			"wxauth",
					state: 			40,
					AppID: 			we_cur.AppID
				},
				wxauthurl= self.getWxUrl(args);
				self.wxsteps.push("wxstate[40]-go wxpage: " );
				self.wxsteps.push("wxstate[40]-go authurl: "+ wxauthurl);
				res.redirect(wxauthurl );
				return "redirect";
			}
			wechat.list[we_cur.domain]= we_cur;
			self.wxsteps.push("<----------------UC("+ (+new Date())+ ")END----------------------");

			var aLogin= null;
			if(we_cur.unionid&& we_cur.unionid!== req.session.user.union_id){
				aLogin= {key: "union_id", val: we_cur.unionid};
			}else if(self.wid&& self.wid!== req.session.user.wid){
				aLogin= {key: "wid", val: self.wid};
			}else{

			}
			if(aLogin){
				var y_user= yield autoLogin(aLogin);
				if(y_user&& y_user.user_id){
					req.session.user = y_user;
                    req.session.user.id = y_user.user_id;
                    req.session.user.openid = we_cur.openid;
				}else{

				}
			}
			return "done";
		});
	},
	getWxUrl: function(args, req, res){
		if("original"=== args.type){
			return [req.protocol, "://", args.hostname, req.originalUrl].join("");
		}else if("redirect"=== args.type){
			var originalUrl= req.originalUrl;
			return [req.protocol, "://", args.hostname, originalUrl].join("");
		}else if("wxauth"=== args.type){
			return ["", args.AppID, "&redirect_uri=", args.redirect_uri, "&response_type=code&scope=", args.scope, "&state=", args.state, "#wechat_redirect"].join("");
		}else{
			return null;
		}
	},
	doNoAuth: function(req, res){
		return new Promise(function(resolve, reject){
			resolve("doNoAuth");
		});
	}
}

/**
	根据 域名, 返回appid，appsecret
	@param {object} args
	@param {function} fn
	@return void
 */
function getAppid(args){
	return new Promise(function(resolve, reject){
		proxy.invoke({
			data: 		{
				method: "wechat.account.findByDomain",
				params: args
			},
			protocol: 	"http",
			host: 		config.mduc.host,
			port: 		config.mduc.port,
			path: 		"/api",
			method: 	"POST",
			contentType: "application/json;charset=UTF-8"
		}, function (err, result) {
			if(err|| 0!= result.code){
				reject([10, "break on getAppid"]);
			}else{
				var account= result.data.availableAccount,
					data= null;
				if(!account){
					return reject([10, "break on getAppid"]);
				}
				data= {
						AppID: 		account.account_app_id,
			 			AppSecret: 	account.account_app_sec,
						//scope: 		"snsapi_base",
						domain: 	account.domain
					};
				resolve(data);
			}
		});
	});
}
/**
	根据 域名，ip 等进行分流, 返回appid，appsecret
	@param {object} args
	@param {function} fn
	@return void
 */
function getAppid2(args){
	return new Promise(function(resolve, reject){
		proxy.invoke({
			data: 		{
				method: "wechat.account.usableAccount",
				params: args
			},
			protocol: 	"http",
			host: 		config.mduc.host,
			port: 		config.mduc.port,
			path: 		"/api",
			method: 	"POST",
			contentType: "application/json;charset=UTF-8"
		}, function (err, result) {
			if(err|| 0!= result.code){
				reject([10, "break on getAppid2"]);
			}else{
				var account= result.data,
					data= {
						AppID: 		account.account_app_id,
			 			AppSecret: 	account.account_app_sec,
						//scope: 		"snsapi_base",
						domain: 	account.domain
					};
				resolve(data);
			}
		});
	});
}
/**
	根据 code 获取 openid 等信息
	@param {object} args
	@param {function} fn
	@return void
 */
function getWxInfo(args){
	return new Promise(function(resolve, reject){
		user_ctr.getWXopenId(args, function(err, result){
			if(err){
				reject([10, "break on getWxInfo"]);
			}else{
				resolve(result);
			}
		});
	});
}
/**
	根据 openid 获取 unionid，wid，等信息
	@param {object} args
	@param {function} fn
	@return void
 */
function getWxcommon(args){
	return new Promise(function(resolve, reject){
		proxy.invoke({
			data: 		{
				method: "uc.user.getByOpenid",
				params: args
			},
			protocol: 	"http",
			host: 		config.mduc.host,
			port: 		config.mduc.port,
			path: 		"/api",
			method: 	"POST",
			contentType: "application/json;charset=UTF-8"
		}, function (err, result) {
			if(err|| 0!= result.code){
				reject([10, "break on getWxcommon"]);
			}else{
				resolve(result.data);
			}
		});
	});
}
/**
 根据 openid 获取 unionid，wid，等信息
 @param {object} args
 @param {function} fn
 @return void
 */
function getDbWxcommon(args){
	return new Promise(function(resolve, reject){
		proxy.invoke({
			data: 		{
				method: "uc.user.getRelation",
				params: args
			},
			protocol: 	"http",
			host: 		config.mduc.host,
			port: 		config.mduc.port,
			path: 		"/api",
			method: 	"POST",
			contentType: "application/json;charset=UTF-8"
		}, function (err, result) {
			if(err){
				reject([10, "break on getDbWxcommon"]);
			}else{
				resolve(result.data);
			}
		});
	});
}
/**
	存储 openid ，unionid， appid 关系
	@param {object} args
	@param {function} fn
	@return void
 */
function setWxcommon(args, wx_info){
	if(wx_info){
		args.weixin= {
			nickname: 	wx_info.nickname,
			headimgurl: wx_info.headimgurl,
			country: 	wx_info.country,
			province: 	wx_info.province,
			city: 		wx_info.city,
			sex: 		wx_info.sex
		}
	}
	return new Promise(function(resolve, reject){
		proxy.invoke({
			data: 		{
				method: "uc.user.bindByOpenID",
				params: args
			},
			protocol: 	"http",
			host: 		config.mduc.host,
			port: 		config.mduc.port,
			path: 		"/api",
			method: 	"POST",
			contentType: "application/json;charset=UTF-8"
		}, function (err, result) {
			if(err|| 0!= result.code){
				reject([10, "break on setWxcommon"]);
			}else{
				resolve(result.data);
			}
		});
	});
}
/**

	
 */
function getUserWx(args){
	return new Promise(function(resolve, reject){
		user_ctr.getWXUserInfoByOpenid2(args, function(err, result){
			if(err){
				reject([10, "break on getUserWx"]);
			}else{
				resolve(result);
			}
		});
	});
}
/**
	绑定wid unionid 关系
	@param {object} args
	@param {function} fn
	@return void
 */
function setUserWx(args){
	return new Promise(function(resolve, reject){
		proxy.invoke({
			data: 		{
				method: "uc.user.bindWeixinInfo",
				params: args
			},
			protocol: 	"http",
			host: 		config.mduc.host,
			port: 		config.mduc.port,
			path: 		"/api",
			method: 	"POST",
			contentType: "application/json;charset=UTF-8"
		}, function (err, result) {
			if(err|| 0!= result.code){
				reject([10, "break on setUserWx"]);
			}else{
				resolve(result.data);
			}
		});
	});
}
/**
 绑定wid unionid 关系
 @param {object} args
 @param {function} fn
 @return void
 */
function setDbUserWx(args){
	return new Promise(function(resolve, reject){
		proxy.invoke({
			data: 		{
				method: "uc.user.bindMPAccount",
				params: args
			},
			protocol: 	"http",
			host: 		config.mduc.host,
			port: 		config.mduc.port,
			path: 		"/api",
			method: 	"POST",
			contentType: "application/json;charset=UTF-8"
		}, function (err, result) {
			if(err|| 0!= result.code){
				reject([10, "break on setDbUserWx"]);
			}else{
				resolve(result.data);
			}
		});
	});
}
/**
	自动登录
	@param {object} args=>{wid: xxxx}
	@param {function} fn
	@return void
 */
function autoLogin(args){
	return new Promise(function(resolve, reject){
		proxy.invoke({
			data: 		{
				method: "uc.user.getInfoByField",
				params: args
			},
			protocol: 	"http",
			host: 		config.mduc.host,
			port: 		config.mduc.port,
			path: 		"/api",
			method: 	"POST",
			contentType: "application/json;charset=UTF-8"
		}, function (err, result) {
			if(err|| 0!= result.code){
				reject([10, "break on setUserWx"]);
			}else{
				resolve(result.data);
			}
		});
	});
}

/**
	判断是或需要进行微信授权
	@param {string, string} args=> _path, nowwxauth
	@param {function} fn
	@return void
	验证顺序
	1: 如果有nowxauth参数，验证其合法性（规则： 对path加密后的值）
	2: pass-> return true 并且放入list缓存，以方便第二次验证
	3: fail-> return false
	4: 初始化的值， value===1
	5: 某些特殊的路径，如 /public/xxx, /api/xxxx, /loan/venue/xxxx
 */
var noWxAuth= (function(){
	var list= {
		"venue/anotherVenueIndex": 1 //20161111 会场不取身份
	};
	function _noAuth(_path, nowxauth){
		var action_and_method= _path.match(/[\w\.-]+(\/[\w\.-]+)?$/g)[0];
		if(nowxauth){
			if(list[action_and_method]=== nowxauth){
				return true;
			}
			var content = action_and_method + "nowxauth-3324sdfsdfss",
	            md5 = crypto.createHash('md5'),
	        	_nowxauth = (md5.update(content), md5.digest('hex')).slice(-5);
	        if(nowxauth=== _nowxauth){
	        	list[action_and_method]= nowxauth;
	        	return true;
	        }else{
	        	return false;
	        }
		}else if(1=== list[action_and_method]){
			return true;
		}else if(!/^\/(buyer|vd\/tuan|vd\/intpay)/i.test(_path)){
			return true;
		}else{
			return false;
		}
	}
	return _noAuth;
})();

module.exports= {
	init: function(){
		return function(req, res, next){
			if(noWxAuth(req.path, req.query.nowxauth) ){
				return next();
			}
			//res.mduc= new Mduc();
			var mduc= new Mduc();
			mduc.init().setEnv(req, res).then(function(v){
				//console.log(mduc.wxsteps);
				if("redirect"=== v){

				}else{
					next();
				}
				logger.info(mduc.wxsteps);
			}).catch(function(e){
				mduc.wxsteps.push(e);
				if("redirect"=== e){

				}else{
					next();
				}
				logger.info(mduc.wxsteps);
			});
		};
	},
	doWXBind: function(req, res){
		var user= req.session.user,
			we_cur= req.session.wechat.current;
			//wx_info= req.session.wechat.info;
		if(user.wid&& !user.union_id&& we_cur.unionid){
			//req.session.wechat.info= null;
			var args= {
				wid:  				user.wid,		
				openid: 			we_cur.openid,
				app_id: 			we_cur.AppID,
				//open_id_type: 		"",
				//open_id_is_active: 	"",
				union_id: 			we_cur.unionid
			};
			if(/intpayment/i.test(req.hostname)){
				args.open_id_type = 500;
				setUserWx(args);
			}else{
				setUserWx(args);
			}
		}
	},
	autoLogin: autoLogin,
	setWxcommon: setWxcommon
};