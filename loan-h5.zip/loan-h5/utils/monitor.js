/**
	系统耗时统计
 */

var proxy = require("./proxy"),
	config= require("./config"),
	http= require("http");

function Monitor(){
	this._data= {
		globalTicket: null, 		//全局标识
		monitorTrackId: null,		//唯一标识
		isSuccess: null,			//是否成功:1 成功,0 失败
		invokeType: "consumer",			//调用类型：provider提供方，consumer消费方
		providerApplication: "intpay.node-web",	//服务提供方应用名称
		providerHost: null,			//服务提供方IP
		providerHostPort: null,		//服务提供方端口
		providerVersion: null,		//服务提供方版本
		consumerApplication: null,	//应用名称
		consumerHost: null,			//服务消费方IP
		consumerHostPort: null,		//服务消费方端口
		consumerVersion: null,		//服务消费方版本
		groupName: null,			//分组名称
		service: null,				//接口名称
		method: null,				//接口方法
		elapsed: null,				//耗时
		concurrent: null,			//当前并发量
		bizData: null,				//日志业务数据
		input: null,				//输入
		output: null,				//输出
		invokeTime: null,//Dformat(args.startTime),			//调用时间格式：yyyy-MM-dd HH:mm:ss
		createTime: null,			//调用时间
		exception: null
	};
}

Monitor.prototype= {
	constructor: Monitor,
	start: function(args, fn){
		this._data.startTime= +new Date();
		for(var k in args){
			this._data[k]= args[k];
		}
		this._data.invokeTime= Dformat(this._data.startTime);
		fn&&fn.call(this);
		return this;
	},
	end: function(args, fn){
		this._data.endTime= +new Date();
		for(var k in args){
			this._data[k]= args[k];
		}
		fn&&fn.call(this);
		this.record();
		return this;
	},
	record: function(){
		this._data.elapsed= this._data.endTime- this._data.startTime;

		for(var k in this._data){
			if("startTime"=== k|| "endTime"=== k|| null=== this._data[k]){
				delete this._data[k];
			}
		}
		var path= JSON.stringify(this._data);
		proxy.invoke({
			data: {},
			protocol: "http",
			host: config.monitor.host,
			port: config.monitor.port,
			path: "/monitor-proxy?parameterInput="+ encodeURIComponent(path),
			//contentType: "application/json;charset=UTF-8",
			method:"GET"
		}, function (err, result) {
			//console.log(result);
		});
		return this;
	}
}

//
function Dformat(v){
	if(v instanceof Date){

	}else{
		v= new Date(v);
	}
	var y= v.getFullYear(),
		m= v.getMonth()+ 1,
		d= v.getDate(),
		h= v.getHours(),
		sec= v.getMinutes(),
		s= v.getSeconds()
	var fv= [y+ "-"+ ("0"+m).slice(-2)+ "-"+ ("0"+d).slice(-2)+ " "+ ("0"+h).slice(-2)+ ":"+ ("0"+sec).slice(-2)+ ":"+ ("0"+s).slice(-2)].join();
	return fv;
}


module.exports= Monitor;