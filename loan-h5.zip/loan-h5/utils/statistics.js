/**
	打点统计(目前用于/index.js和routes层)
	以get方式发送请求
	示例：StatType=vdpath&vdseqid=xxxx@xxxx@xxxx*xxxx*xxxx&b_v=xxxx&b_y=xxxx&b_o=xxxx&b_u=xxxx&d_h=xxxx&d_g=xxxx&d_t=xxxx
	参数说明：1) vdseqid={random}@{channelInfo}@{yunjie_id}*{open_id}*{user_id}
			  2) phraseBaseInfo => b_v={vid}&b_y={yunjie_id}&b_o={open_id}&b_u={user_id}
			  3) phraseDetailInfo => d_h={pageshow/fav/cart/order/corder/pay}&d_g={productdetail/vddetail/cartdetail}&d_t={productId}
**/
var tools = require("./tools"),
	proxy = require("../utils/proxy"),
    config = require("../utils/config");


function Statistics(){
	//d_g映射
	var table_d_g = {
		"home":				"home",				//首页
		"detail1":			"detail1",			//商品详情
		"shopcart":			"shopcart",			//购物车
		"favorite":			"favorite",			//我的收藏
		"addressSelect":	"addressSelect",	//选择收货地址
		"addressList":		"addressList",		//管理收货地址
		"addressEdit":		"addressEdit",		//修改/新增收货地址
		"userCenter":		"userCenter",		//我的
		"userLogin":		"userLogin",		//登录/绑定
		"modifyName":		"modifyName",		//个人信息
		"modifyMobile":		"modifyMobile",		//编辑昵称
		"list":				"orderList",		//订单列表
		"refundDetail":		"refundDetail",		//退款详情
		"orderDetail":		"orderDetail",		//订单详情
		"check":			"orderCheck",		//确认订单
		"pay":				"orderPay",			//好友来收款
		"payResult":		"payResult",		//支付成功
		"comment":			"comment",			//评价
		"logistics":		"logistics",		//物流信息
		"rights":			"rights",			//维权订单详情
		"refundGoods":		"refundGoods",		//申请退款
		"refundTransport":	"refundTransport",	//退货信息
		"":					""
	};
	this.table_d_g = table_d_g;
}

Statistics.prototype = {
	init: function(req, res, next){
		// var self = this,
		// 	channelInfo = req.query["channelInfo"]||req.session.channelInfo||"blank",
		// 	channelSource = req.query["channelSource"]||req.session.channelSource||"blank",
		// 	channelBusiness = req.query["channelBusiness"]||req.session.channelBusiness||"blank";
		// if(req.session.channelInfo === channelInfo){
		// 	req.session.hop ++;
		// }else{
		// 	req.session.hop = 1;
		// 	req.session.channelInfo = channelInfo;
		// 	req.session.channelSource= channelSource;
		// 	req.session.channelBusiness= channelBusiness;
		// 	req.session.random = Math.random().toString().slice(-6);
		// }
		// if("h5wxfri" === channelInfo || "h5wxcyc" === channelInfo){
  //       	req.session.fromUser = req.query.fromUser||",,,"; //10 12 加密后的数据
  //       }
  //       return self;
  		return this;
	},
	invoke: function(req, res, next, args){
		var self = this;
		args.random = req.session.urlInfo.random;
		args.channelInfo = req.session.urlInfo.channelInfo||"blank";
		args.fromUser = decodeURIComponent(req.session.urlInfo.fromUser);
		args.yunjie_id = req.session.user.yunjie_id;
		args.open_id = req.session.user.openid||-1;
		args.user_id = req.session.user.id||-1;
		args.vid = req.session.shopInfo ? (req.session.shopInfo.shop_id||-1) : -1;
		if("h5wxfri" === args.channelInfo || "h5wxcyc" === args.channelInfo){
			args.fromUser = tools.coder(tools.coder(args.fromUser, 10), 12);
		}else{
			args.fromUser = "**";
		}
		args.d_g = this.table_d_g[args.d_g];
		args.hop = req.session.urlInfo.hop||1;
		args.clientIp= res.locals.config.clientIp;
		//args.user_agent = res.locals.config.ua;
		args.from_app= ~~res.locals.config.isVdianAPP;
		//args.extendKV 扩展字段，调用方视情况调用
		var path = new Path(args, args.extendKV).toString();
		//console.log(path);
		proxy.invoke({
			data:{},
			protocol: "http",
			host: config.statistics.host,
			port: config.statistics.port,
			path: "/wm.js?"+path,
			method:"GET"
		}, function (err, result) {
			//console.log(result);
		});
		return self;
	},
	createFromUser: function(req, res, next, args){
		var self = this;
		res.locals.config.fromUser = encodeURIComponent(tools.coder(tools.coder([req.session.user.yunjie_id, req.session.user.openid||"", req.session.user.id||""].join("*"), 10), 12) );
		return self;
	},
	invoke4partner: function(req, res, next ,args){
		var self = this;
        args.random = req.session.urlInfo.random;
        args.channelInfo = req.session.activity.channelInfo||"blank";
        args.vid = req.session.activity.vid || -1;
        args.productId = req.session.activity.pop_id || -1;
        if("h5wxfri" === args.channelInfo || "h5wxcyc" === args.channelInfo){
            args.fromUser = tools.coder(tools.coder(args.fromUser, 10), 12);
        }else{
            args.fromUser = "**";
        }
        args.d_g = this.table_d_g[args.d_g];
        args.hop = req.session.hop||1;
        args.clientIp= res.locals.config.clientIp;
        args.from_app= ~~res.locals.config.isVdianAPP;
        var path = new Path(args, args.extendKV).toString();

        proxy.invoke({
            data:{},
            protocol: "http",
            host: config.statistics.host,
            port: config.statistics.port,
            path: "/wm.js?"+path,
            method:"GET"
        }, function (err, result) {
            //console.log(result);
        });
        return self;
	}
}


	//path参数类
	var params = {
		StatType: 	"vdpath",
		//vdseqid: 	"{random}@{channelInfo}@{from_yunjie_id}*{from_open_id}*{fromUser_id}",
		vdseqid: 	"{random}@{channelInfo}@{fromUser}",
		b_v: 		"{vid}",
		b_y: 		"{yunjie_id}",
		b_o: 		"{open_id}",
		b_u: 		"{user_id}",
		d_h: 		"{phraseType}",
		d_g: 		"{pageType}",
		d_t: 		"{productId}",
		d_gid: 		"{wp_goodsId}",
		d_pt:       "{productType}",
		d_pp:       "{pageProperties}",
		hop:        "{hop}",
		user_agent: "{user_agent}",
		from_app: 	"{from_app}",
		cip: 		"{clientIp}"
	},
	params_path = raw(params);

function Path(args, extendKV){
	if(extendKV){
		var _params= params;
		for(var k in extendKV){
			_params[k]= extendKV[k];
		}
		this.params_path= raw(_params);
		this.params = args;
	}else{
		this.params_path = params_path;//"StatType=vdpath&vdseqid={random}@{channelInfo}@{fromUser}&b_v={vid}&b_y={yunjie_id}&b_o={open_id}&b_u={user_id}&d_h={phraseType}&d_g={pageType}&d_t={productId}&hop={hop}";
		this.params = args;
	}
}

Path.prototype = {
	toString: function(){
		var params = this.params,
			params_path = this.params_path,
			path = params_path.replace(/{(.*?)}/gi, function($1, $2){
				return ($2 in params)?params[$2]: -1;
			});
		//console.log(this.params);
		return encodeURI(path);
	}
}

//字典排序
function raw(args) {
	var keys = Object.keys(args),
		newArgs = {},
		string = '';
	keys = keys.sort();
	keys.forEach(function (key) {
		newArgs[key] = args[key];
	});
	for (var k in newArgs) {
		string += '&' + k + '=' + newArgs[k];
	}
	string = string.substr(1);
	return string;
}

module.exports = new Statistics();