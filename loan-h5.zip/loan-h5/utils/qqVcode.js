var proxy= require("./proxy"),
	crypto = require("crypto"),
	qs= require("querystring");
/**
	qq 验证码
	@author eric.wu
	@time 20160329
*/
var SECRET_ID= "",
	SECRET_KEY= "",
	qHost= "",
	qPath= "";

function createVcode(args, fn){
	var _args= {
		userIp: args.cip,
		captchaType: 4,
		disturbLevel: 1,
		isHttps: 1,
		businessId: args.businessId,
		clientType: 1,
		sceneId: 10
	};
	processArgsData(_args, "CaptchaIframeQuery", fn);
};
function checkVcode(args, fn){
	var _args= {
		userIp: args.cip,
		captchaType: 4,
		ticket: args.ticket,
		businessId: args.businessId,
		sceneId: 10
	};
	processArgsData(_args, "CaptchaCheck", fn);
};
//
function processArgsData(args, type, fn){
	var _args= args,
		_param= createUrl("GET", type||"CaptchaIframeQuery", "gz", SECRET_ID, SECRET_KEY, _args);
	proxy.invoke({
        data:{},
        protocol: "https",
        host: qHost,
        port: 443,
        type: 'json',
        path: qPath+ _param,
        method: "GET"
    }, function(err, result){
    	if(!err){
    		result= JSON.parse(result);
    	}else{
    		result= {};
    	}
    	fn(err, result);
	});
}
//
function createUrl(method, action, region, secretId, secretKey, args){
	args.Nonce= parseInt(Math.random()*1e10),
	args.Action= action;
	args.Region= region;
	args.SecretId= secretId;
	args.Timestamp= parseInt(+new Date()/1000);
	//
	args.Signature= crypto.createHmac('sha1', secretKey).update(method+ qHost+ qPath+ createQueryString(args, false) ).digest().toString('base64');
	//
	return createQueryString(args, true);
}
//
function createQueryString(args, isURLEncoded){
	var keys= Object.keys(args),
		res_arr= [];
	keys.sort();
	for(var i=0, ci; ci= keys[i]; i++){
		if(!isURLEncoded){
			res_arr.push(ci+ "="+ args[ci]);
		}else{
			res_arr.push(ci+ "="+ encodeURIComponent(args[ci]) );
		}
	}
	return res_arr.join("&");
}

module.exports= {
	createVcode: createVcode,
	checkVcode: checkVcode
}
