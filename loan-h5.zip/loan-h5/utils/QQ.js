/*!
	qq登录授权
*/
var config= require("./config"),
	querystring= require("querystring");

function QQ(){

}

QQ.prototype= {
	toAuth: function(req, res, next){
		var qurl= encodeURIComponent(this.getOriginalUrl(req, res, next) ); //原始链接
        var vdAuth= this.getRedirectUrl(req, res, next, qurl); //qq 重定向回来的链接(作为参数)
        var qqAuth= this.getQQUrl(vdAuth );
		return res.redirect(qqAuth );
	},
	getOriginalUrl: function(req, res, next){
		return [req.protocol, "://", req.hostname, req.originalUrl].join("");
	},
	getRedirectUrl: function(req, res, next, qurl){
		return [req.protocol, "://", req.hostname, "/loan/qqauth?qurl="+ qurl].join("");
	},
	getQQUrl: function(vdAuth){
		var _baseUrl= '',
			_param= {
				display: 'mobile',
				response_type: 'code',
				client_id: config.walletQQ.appId,
				redirect_uri: vdAuth,
				scope: 'get_user_info',
				state: 'user_info'
			};
		return _baseUrl+ '?'+ querystring.stringify(_param );
	}
};

module.exports= new QQ();