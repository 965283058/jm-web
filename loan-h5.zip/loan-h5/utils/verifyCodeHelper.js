/**
 	验证码
 	a)目前只使用腾讯，不排除会切换

    请使用util/qqVcode.js
 */
var crypto = require("crypto"),
	http = require('http');

var useTecentAPI = true;//config.swth.useTecentAPI; //是否使用腾讯的图形验证码
var SecretId = '';
var SecretKey = '';
var buid = 1;
var uid = 1;
var captype = 8;

//生成验证码
function createVcode(args, fn){
	var time = new Date().getTime();
	var timestamp = Math.round(time/1000);
	var csnonce = Math.round(Math.random()*10000);
	var userip = args.userIp;
	//公共参数，按字典顺序
	var comms = 'Action=CaptchaQuery&Nonce='+csnonce+'&Region=sh&SecretId='+SecretId+'&Timestamp='+timestamp;
	//具体接口参数，按字典顺序
	var options = '&businessId='+buid+'&captchaType='+captype+'&script=1'+'&uid='+uid+'&userIp='+userip;
	//拼接签名原文
	var plaintext = 'GETcsec.api.qcloud.com/v2/index.php?'+comms+options;
	//签名
	var cssig = crypto.createHmac('sha1', SecretKey).update(plaintext).digest().toString('base64');
	//拉取验证码的javascript的url
	var queryUrl = 'http://a.api.aa.com/v2/index.php?' + comms + options+'&Signature=' + encodeURIComponent(cssig);

    console.log("请使用util/qqVcode.js");
	fn(null, {
		code: 0,
		data: {
			queryUrl: queryUrl,
			csnonce: csnonce
		}
	});
}

//核对验证码
function checkVcode(args, fn){
	var ticket = args.ticket,
        csnonce = args.csnonce;
    var time = new Date().getTime();
    var timestamp = Math.round(time/1000);
    var userip = args.userIp;

    var comms = 'Action=CaptchaCheck&Nonce='+csnonce+'&Region=sh&SecretId='+SecretId+'&Timestamp='+timestamp;
    var options = '&businessId='+buid+'&captchaType='+captype+'&ticket='+ticket+'&uid='+uid+'&userIp='+userip;
    var plaintext = 'GETcsec.api.qcloud.com/v2/index.php?'+comms+options;
    var cssig = crypto.createHmac('sha1', SecretKey).update(plaintext).digest().toString('base64');

    var queryUrl = 'http://aa.api.aa.com/v2/index.php?' + comms + options+'&Signature=' + encodeURIComponent(cssig);

    var body = "";
    http.get(queryUrl, function(res) {
        res.
        on('data',function(d){
            body += d;
        }).
        on('end', function(e){
            body = JSON.parse(body);
            if (body.code == 0) {
               	fn(null, {code:0, data:null, message: "valid"});
            } else {
                fn(null, {code:1000, data:null, message: "faild"});
            }
        });
    }).on('error', function(e) {
        fn(null, {code:1001, data:null, message: "faild"});
    });
}

module.exports= {
	createVcode: createVcode,
	checkVcode: checkVcode
}