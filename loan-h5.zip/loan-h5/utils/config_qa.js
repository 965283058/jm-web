var config = {
	port:8001,
	domain: "",
	preview: false//是否开启预览模式
};

module.exports = config;