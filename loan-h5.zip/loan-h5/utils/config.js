var config = {},
	NODE_ENV = process.env.NODE_ENV;
	/*NODE_ENV="pln";*/
if("development" === NODE_ENV){
	config = require('./config_development');
}else if("pl" === NODE_ENV){
	config = require('./config_pl');
}else if("pln" === NODE_ENV){
	//本地pl开发调试环境（非特殊情况不得使用）
	NODE_ENV= "pl";
	config = require('./config_pl');
	for(var k in config){
		var ck= config[k];
		if("object"=== typeof ck){
			for(var kk in ck){
				var ckk= ck[kk];
				if(/host/.test(kk)&& /^\d/.test(ckk) ){
					ck[kk]+= ".proxy.fe.weimob.com";
				}else if(/soaproxy/.test(ckk) ){
					ck.port="4020";
					ck[kk]= "127.5.4.1";
				}
			}
		}
	}
}else if("production" === NODE_ENV){
	config = require('./config_production');
}else if("qa" === NODE_ENV){
	config = require('./config_qa');
}else{
	config = require('./config_development');
	NODE_ENV= "development";
}

config.swth= {
	"useTecentAPI": true,
	"useAccessToken": true,
	"useShopCache": true,
	"useGeetestAPI": true
};


var signKey= "3333";//禁止修改

/**
 * geetest验证码私钥公钥
 *
 */
var geetestKeys = {
	public: '2222',
	private: '1111'
}
Object.defineProperties(config, {
	signKey: {
		get: function(){
			return signKey;
		}
	},
	signKey2: {
		get: function(){
			return "1111"; //禁止修改
		}
	},
	env: {
		get: function(){
			return NODE_ENV;
		}
	},
	geetestKeys: {
		get: function(){
			return geetestKeys;
		}
	}
}); 

module.exports = config;
