var config = {
	port: 5010,
	intpay:{
		host:"10.174.179.164",
		port: 8080
	},
	domain: "http://m-pl.intpayment.cn",
    preview: false//是否开启预览模式
};

module.exports = config;