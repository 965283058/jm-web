var config = {
	port: 5000,
	intpay:{
		host: "",
		port: 80
	},
	domain: "http://m.intpay.cn",
    preview: false//是否开启预览模式
};

module.exports = config;