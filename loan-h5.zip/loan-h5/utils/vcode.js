"use strict";
//
var  config= require('./config'),
	crypto = require('crypto');
var vcodeManager= {
    key: "vcode-10001",
    pubKey: config.signKey2,
    /**
		所有参数除了now都为必填
		当用来做校验的时候now也为必填
    */
    encodePassCode: function(mobile, mode, vkey, riskLevel, now){
    	var _now= now|| Date.now(),
    		content = [mobile, mode, vkey, riskLevel, _now, this.pubKey, this.key].join(""),
            md5 = crypto.createHash('md5'),
            passCode= (md5.update(content), md5.digest('hex')).slice(-6);
        return [riskLevel, _now, passCode].join("-"); //riskLevel, now 实在服务端生成的，所以要拼在md5Content中
    },
    checkEqual: function(_passCode, passCode){
    	return _passCode=== passCode;
    }
}

module.exports= vcodeManager;