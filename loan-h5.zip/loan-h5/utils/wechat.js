var config= require("./config"),
	wxSign= require("./sign"),
	jsApiList= [
        'checkJsApi',
        'onMenuShareTimeline',
        'onMenuShareAppMessage',
        'onMenuShareQQ',
        'onMenuShareWeibo',
        'hideMenuItems',
        'showMenuItems',
        'hideAllNonBaseMenuItem',
        'showAllNonBaseMenuItem',
        //'translateVoice',
        //'startRecord',
        //'stopRecord',
        //'onRecordEnd',
        //'playVoice',
        //'pauseVoice',
        //'stopVoice',
        //'uploadVoice',
        //'downloadVoice',
        'chooseImage',
        'previewImage',
        'uploadImage',
        'downloadImage',
        'getNetworkType',
        'openLocation',
        'getLocation',
        'hideOptionMenu',
        'showOptionMenu',
        'closeWindow',
        'scanQRCode',
        'chooseWXPay',
        //'openProductSpecificView',
        //'addCard',
        //'chooseCard',
        //'openCard',
        'openAddress'
    ];


function Wechat(){

}

Wechat.prototype= {
	constructor: Wechat,
	config: function(shop_ctr){
		var self= this;
		if(self.shop_ctr){
			return self;
		}
		self.shop_ctr= shop_ctr;
		return self;
	},
	// getAccessToken: function(fn){
	// 	var self= this, args= {shop_id: "1000_wechat"};
	// 	self.shop_ctr.getAccessToken(args, function(err, result){
 //            fn(err, result);
 //        });
	// 	return self;
	// },
	getJsTicket: function(fn){
		var self= this;
		// self.getAccessToken(function(err, result){
		// 	if(err){
		// 		fn(err, null);
		// 	}else{
		// 		var args= {
		// 			shop_id: "1000_wechat",
		// 			access_token: result
		// 		};
  //               self.shop_ctr.getJSTicket(args, function(err1, result1){
  //               	fn(err, result1);
  //               });
		// 	}
		// });
		var args= {
				shop_id: "1000_wechat_"+ self.AppID+ "_",  //有些歧义，只是借助shop_id存一条数据
				AppID: self.AppID,
				AppSecret: self.AppSecret,
				access_token: null // 废弃
			};
		self.shop_ctr.getJSTicket(args, function(err1, result1){
        	fn(err1, result1);
        });
		return self;
	},
	initJsTicket: function(args, fn){
		var self= this;
		self.AppID= args.AppID;
		self.AppSecret= args.AppSecret;
		self.url= args.url;
		if(!args.AppID){
			return fn(new Error("no appid"), null);
		}
		self.getJsTicket(function(err, js_ticket){
			if(err){
				fn(err, null);
			}else{
				var wxConfig = wxSign(js_ticket, args.url);
		        	wxConfig = {
			            debug: 		false,
			            appId: 		args.AppID,
			            timestamp: 	wxConfig.timestamp,
			            nonceStr: 	wxConfig.nonceStr,
			            signature: 	wxConfig.signature,
			            jsApiList: 	jsApiList
			        };
		        fn(err, wxConfig);
			}
		});
		return self;
	}
}

var wechat= new Wechat();

module.exports= wechat;