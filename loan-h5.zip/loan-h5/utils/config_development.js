var config = {
	port:80,
	api:{
		"host":"",
		"port":80
	},
	im:{
		"host":"",
		"port":7074,
		"port2": 8899,
		"appKey": ""
	},
	coupon: {
		"host": "",
		"port": "8888",
		"api": {
			"addCouponWithPhone": ""
		},
		"cusNo": ""
	},
	coupon2: {
		"host": "",//外网
		"host2": "",//外网
		"port": "8080",
		"port2": "8080",
		"api": {
			"exchange": "/intpay-coupon-web/coupon/h5/exchange",
			"coupon":"/intpay-coupon-web/coupon/h5/",
			"fissionCoupons": "/intpay-coupon-web/coupon/h5/"
		}
	},
	indiana:{
		host:"",
		port:""
	},
	indianaRaider:{
		host:"",
		port:""
	},
	promotion:{
		"host":"",
		"port":6005
	},
	wx:{

	},
	qqLbs:{
		"host":"",
		"key": ""
	},
	weichat:{
		aid: "",
	  	AppID: "",
      	AppSecret: ""
	},
	wp:{
		wechatUc:{
			host:"",
			port:11111
		},
		wechatToken:{
			host:"",
			port:"8080",
			path:''
		}
	},
	defaultShop: {
		vid: "21276"
	},
	db:{
		COOKIE_SECRET: 'cloudMall',
		DB: 'cloudMall_dev',
		PORT:'11211',
		USERNAME: 'memcached',
		PASSWORD: '',
		HOST: '121.43.196.204',
		// HOST:'127.0.0.1'
	},
	rdb:{
		COOKIE_SECRET: 'cloudMall',
		DB: 'cloudMall_dev',
		PORT: '6410',//'6380',
		USERNAME: 'redis',
		PASSWORD: 'redis-dev-001',
		HOST: '121.43.196.204'
	},
	rdb2:{
		COOKIE_SECRET: 'cloudMall',
		DB: 'cloudMall_dev',
		PORT: '6379',//'6380',
		USERNAME: 'redis',
		PASSWORD: '',
		HOST: 'c6a2778448dc4fc9.m.cnhza.kvstore.aliyuncs.com'
	},
	share: {
		url: ""
	},
	lama:{
		host:"",
		port:7070
	},
	monitor: {
		host: "",
		port: 8087
	},
	soaProxy: {
		host: "",
		port: 8087
	},
	walletQQ: {
		appId: '',
        appKey: '',
        business: 1,
        cardId: '',
        qcAdmin: ''
	},
	recommend: {

	},
	materialService: {
		host: "",
		port: 3009
	},
	defaultComment: {
		host: "",
		port: 80
	},
	pintuanSecond:{

	},
	mduc: {
		host: "",
		port: 80
	},
	gwh: {
		host: "",
		port: 3005
	},
	ossConfig: {
    	accessKeyId: '',
    	accessKeySecret: '',
    	bucket: 'loan-static'
	},
	sms: {
		host: "",
		remark_addFri: "",
		port: 80
	},
	intpay:{
		host: "10.150.20.96",
		port: 28095
	},
	couponPrefix:'',
	couponPrefix2:'',
	domain: "http://m-dev.intpay.cn",
	domain2: "",
	mdDomain: "",
	mdDomain2: "",
	mdDomain2_1: "",
    preview: false//是否开启预览模
};

module.exports = config;