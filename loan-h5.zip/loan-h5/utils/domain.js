 var config= 	require("./config"),
 	logger= 	require("./logger"),
 	proxy= 		require("./proxy"),
 	debug = 	require("debug")("util-domain");

var mdDomainResolve= null;
if("development"=== config.env){
	mdDomainResolve= function(str){
		return str.replace(/\w{4,11}\.hsmob\./i, "");
	}
}else if("pl"=== config.env){
	mdDomainResolve= function(str){
		return str.replace(/\w{4,11}\.md\.([\w-]{1,10})/i, function($1, $2){
			if("pl"=== $2){
				return "m.pl";
			}else if("duobao-pl"=== $2){
				return $2;
			}else{
				return $2+ ".m";
			}
		});
	}
}else if("production"=== config.env){
	mdDomainResolve= function(str){
		return str.replace(/\w{4,11}\.md\.([\w-]{1,10})/i, function($1, $2){
			if("intpay"=== $2){
				return "m.intpay";
			}else if("intpay"=== $2){
				return $2;
			}else{
				return $2+ ".m";
			}
		});
	}
}else{
	return str;
}

/**
	
	@param {object} args
	@param {function} fn
	@return void
 */
function checkHost(req, res){
	return new Promise(function(resolve, reject){
		var host = req.headers.host,
	        domain =  host.match(/^(?:\w{2,}|i)(?=\.)/i)||[],
	        originalUrl = req.originalUrl;
	    debug("host-(%s", host);
	    if("production"!== config.env&& /(\d{1,3}\.?){4}\:\d{4}$/.test(host) ){
	        //IP地址
	        return resolve();
	    }
	    if(domain[0] && !(new RegExp("\\b"+ domain[0]+ "\\.", "i").test(config.domain)) ){
	        var redirect_uri = req.originalUrl,
	            args = {
	                personalized_domain: domain[0]
	            };
	        //判断是否是shopxxx格式的个性域名
	        if ('i' === domain[0]) {
	            res.redirect(config.domain+"/util/user/login");
	            return reject("redirect");
	        }else if(host.indexOf(".md")>-1 ){
	            //分享的随机域名
	            res.redirect("http://"+ mdDomainResolve(host)+ originalUrl);
	            return reject("redirect");
	        }else if(/^shop(\d+)$/gi.test(domain[0])){
	            redirectVid(domain[0].slice(4));
	        }else if(/intpayment/i.test(domain[0]) ){
                resolve();
            }else{
	        	//return resolve();

	        }
	        function redirectVid(vid){
	            if(vid){
	                redirect_uri = redirect_uri.replace(/(vid=|sid=)(?:\d+)/g, function($1, $2){return $2+vid;});
	            }
	            redirect_uri = redirect_uri.length>2? redirect_uri: "/buyer/home?vid="+ vid|| "";
	            res.redirect(config.domain2+redirect_uri);
	            return reject("redirect");
	        }
	    }else{
	        if(req.originalUrl.length>2){
	            resolve();
	        }else{
	            res.redirect("/util/dw/0");
	            return reject("redirect");
	        }
	    }
	});
}



module.exports= {
	checkHost: function(req, res, next){
		checkHost(req, res).then(function(){
			next();
		}).catch(function(e){
			if("redirect"=== e){
				debug("redirected");
			}else{
				next();
			}
		});
	}
};