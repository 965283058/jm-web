/**
 *帮助类*
 */
var helper = {};
var config = require("./config");
var qs= require("querystring");
var QQ_util = require("./QQ");
var url= require('url');

/**
 *检测用户是否登录*
 *@params {Object} 请求
 *@return {boolean} 是否登录
 */
helper.checkLogin = function (req) {
	if (req.session.user && req.session.user.mobile > 1000) {
		return true;
	} else {
		return false;
	}
}

/**
 *检测是否是微信环境*
 *@params {Object} res
 *@return {boolean} 是否是微信环境
 */
helper.isWeixin= function(res){
    if (res.locals.config.isWeixin) {
        return true;
    }else{
        return false;
    }
}

/**
 * 建立粉丝关系并生成分享链接
 * @author Henry(jiabin.chen@weimob.com)
 * @param {Bbject} res 当前页访问对象
 * @return {String} 分享链接
 */
helper.getShareLink = function (req, res, pageName) {
    var _query= {},
        wid = 0,
        unionid = '';

    if (res.locals.config.isVdianAPP) {
        wid = res.locals.config.vapp.wid || 0;
    } else {
        wid = req.session.user.wid || 0;
        unionid = req.session.wechat.current.unionid || ''
    }
    
    var mapUrl = {
        tuanIndex: '',
        detail3: '',
        tuanJoin: '',

        oneGroup: '',
        superGroup: '',
        seckillGroup: '',
        overseaGroup: '',

        groupLeaderGift: '',
        groupLeaderQrcode: ""
    }
    var url = config.domain + mapUrl[pageName] + "?";
    
    for(var k in req.query){
        ('mwid'!==k&& 'munionid'!==k) &&(_query[k]= req.query[k]);
    }
    wid&& (_query.mwid= wid);
    unionid&& (_query.munionid= unionid);
    url+= qs.stringify(_query);
    return url;
}

/**
 * 判断是否符合建立粉丝条件
 */
helper.canBuildRel = function (args) {
    var flag = (args.query.mwid || args.query.munionid) && args.session.wechat.current.unionid;
    return flag;
}

/**
 * 生成建立粉丝关系参数
 */
helper.makeArgs2Build = function (req, res) {
    return args = {
        mwid: req.query.mwid || 0,
        munionId: req.query.munionid || '',
        swid: req.session.user.wid || 0,
        sunionId: req.session.wechat.current.unionid || '',
        url: res.locals.config.url,
        nickname: req.session.wechat.nickname || '',
        avatar: req.session.wechat.headimgurl || ''
    }

}

/**
 * 将参数转换成 get 支持的参数传递方式（即url形式）
 * args 键值对形式的对象
 */
helper.formateArgs = function (args) {
    var _args = "";
    for (key in args) {
        _args += "&" + key + "=" + args[key];
    }
    return _args.replace(/\&?/, "?");
}

/**
    @params {Object} req
    @params {Object} res
    @params {Function} next
    @return void
    @static

    a)跳转qq授权逻辑
        1)分享赚业务 src_biz_type = 1
        2)QQ APP
        3)yunjie.loan.cn, m.pl.weimob.com, m.weimob.com 域名
        4)session.qq.openid 为空
        5)5分钟内未进行过qq登录（如果五分钟内进行过qq登录，但是由于网络等特殊原因导致openid未取到，避免无限循环，跳过qq登录）
 */
helper.qqAuth = function (req, res) {
    var query= req.query,
        qq= req.session.qq,
        ua= res.locals.config.ua;
    if(query.src_biz_type&& "1"== query.src_biz_type&& /QQ/i.test(ua)&& !/micromessenger/i.test(ua)&& /(vd|weimob)/i.test(req.headers.host) ){
        if(!(qq&& (qq.openid|| 1000*60*5< +new Date()- qq.t))){
            return QQ_util.toAuth(req, res);
        }
    }
}

/**
    禁用浏览器缓存
**/
helper.nocache = function (req, res) {
    res.header('Cache-Control', 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    res.header('Expires', '-1');
    res.header('Pragma', 'no-cache');
}

/**
 * 请求方式限定
 */
helper.isPost = function (req, res) {
    var method = req. method;
    if (method != "POST") {
        return false;
    }
    return true;
}

helper.isGet = function (req, res) {
    var method = req.method;
    if (method != "GET") {
        return false;
    }
    return true;
}

/**
 * API接口强制登录,true则可调用，false则需要先登录
 */
helper.apiLogin = function (req, res) {
    var reg= /(login|logout|wpFreight|applogin)$/;
    var _pathname= url.parse( req.originalUrl).pathname;
    if(reg.test(_pathname)|| req.session.user.mobile>1000){
        return true;
    }else{
        return false;
    }
}

/**
 * 防机刷方案1：频率限制
 * 若发现同一用户高频请求（机刷），限制其继续请求
 */
helper.antiHRR = function (req, res, judgeNum, judgeTime) {
    var now = new Date().getTime();
    var badMan = false,
        _judgeNum = judgeNum || 5,
        _judgeTime = judgeTime || 3000;
    if (req.session.user.antiHRR) {
        if (req.session.user.antiHRR.count > _judgeNum) { //累计访问超过5次
            var delta = now - req.session.user.antiHRR.time;
            if (delta < _judgeTime) { //5次访问用时小于3秒，认为是机刷
                req.session.user.antiHRR.time = now;
                badMan = true;
            } else {//不是机刷则重置数据
                req.session.user.antiHRR.count = 1;
                req.session.user.antiHRR.time = now;
            }
        } else {
            req.session.user.antiHRR.count++;
        }
    } else {
        req.session.user.antiHRR = {
            count: 1,
            time: now
        };
    }
    return badMan;
}

/**
 * 防机刷方案2：验证码
 * generateCode和checkCode联合使用
 * NODE端和页面前端都使用同一套加密方法，对node给的参数进行加密生产code，在页面提交给node时验证code
 */
helper.generateCode = function (req, res) {
    var now = new Date().getTime();
    res.locals.config.nodeTimestamp = now;
    var code = 'abc'+(now-9999)*2;//算法
    if (req.session.user.antiCode) {
        req.session.user.antiCode.code = code;
    } else {
        req.session.user.antiCode = {
            code: code,
            count: 0
        }
    }
}
helper.checkCode = function (req, code, num) {
    var _num = num || 5;//容忍错误的次数
    if (req.session.user.antiCode) {
        if (req.session.user.antiCode.code == code) {
            req.session.user.antiCode.count = 0;//清零
            return true;
        } else {
            req.session.user.antiCode.count++;
            if (req.session.user.antiCode.count > _num) {
                return false;
            } else {
                return true;
            }
        }
    }
    return false;
}


module.exports = helper;