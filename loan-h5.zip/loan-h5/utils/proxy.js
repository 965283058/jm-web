"use strict";

var http= 		require("http"),
	https= 		require("https"),
	httpList= 	[http, https],
	Buffer= 	require('buffer').Buffer,
	crypto= 	require("crypto"),
	querystring= require('querystring'),
	config= 	require("./config"),
	logger= 	require("../utils/logger"),
//	redisHelper= require("../models/redisHelper"),
	TIMEOUT= 	{1:6000, 2:2000, 3:1000, 4:200, 5:0}; //超时的等级 根据APILEVEL 判断


/**
 	a)class Proxy
 	b)constructor
 	c)params {Object}
 */
function Proxy(args){
	var self= 		this,
		_header= 	null;
	self.data= 		{};
	self.params= 	null;
	self.opt= 		{};
	self.httpI= 		("https" === args.protocol)? 1: 0;
	self.type= 		args.type||"JSON";
	self.APILEVEL= 	args.APILEVEL|| 1;
	//
	if(args.data&& ("_header" in args.data) ){
		_header= args.data._header;
		delete args.data._header;
	}
	//
	if(args.format){
		args.format.call(self);
	}else{
		self.format(args);
	}
	//
	self.opt = {
		method: 	args.method||"GET",
		host: 		args.host||config.api.host,
		port: 		args.port||config.api.port,
		path: 		args.path,
		headers:{
			"Content-Type":"application/x-www-form-urlencoded",
			"Service-Info":"Nodejs-Proxy-intpay",
			"Content-Length":self.params.length
		}
	}
	if(_header){
		for(var k in _header){
			self.opt.headers[k]= _header[k];
		}
	}
	//传递header 信息
	if(args.data&& ("_header" in args.data) ){
		var _header= args.data._header;
		for(var k in _header){
			self.opt.headers[k]= _header[k];
		}
	}
	if(args.contentType == "application/json;charset=UTF-8"){
		self.opt.headers["Content-Type"] = args.contentType;
	}
	if(args.Apiclient == "loan-pc"){
		self.opt.headers["Apiclient"] = args.Apiclient;
	}
}
Proxy.prototype = {
	constructor: Proxy,
	invoke: function(fn){
		var self = this, body = "";
		self.startTime = self.endTime =  new Date().getTime();
		self.timer= setTimeout(function(){
			self.req.emit("timeout");
		}, TIMEOUT[self.APILEVEL]);
		//
		self.req= httpList[self.httpI].request(self.opt, function(res){
			var chunks = [];
			res.
			on('data',function(d){
				chunks.push(d);
				// body += d;
			}).
			on('end', function(e){
				var wholeData = Buffer.concat(chunks);
				body = wholeData.toString('utf8');
				clearTimeout(self.timer );
				setImmediate(function(){
					self.takeLog(body, "proxy");
				});
				fn.apply(null, self.resolveBody(body) );
			}).
			on("close", function(e){
				clearTimeout(self.timer );
				setImmediate(function(){
					self.takeLog(e, "error");
				});
				fn({code:2000, message:"closed"}, null );
	        }).
	        on("abort", function(e){
	        	setImmediate(function(){
					self.takeLog(e, "error");
				});
	            fn({code:2000, message:"timeout or cancel"}, null );
	        });
		}).
		on('error', function(e) {
			clearTimeout(self.timer );
			setImmediate(function(){
				self.takeLog(e, "error" );
			});
			fn(e, {status:1000} );
		}).
		on("timeout", function() {
	        if(self.req.res) {
	            self.req.res.emit("abort");
	        }
	        self.req.abort();
	    });
	    self.req.write(self.params);
		self.req.end();
		//
		return self;
	},
	resolveBody: function(body){
		var self = this;
		if("JSON" === self.type){
			try{
				body = JSON.parse(body);
			}catch(e){
				self.takeLog(e, "error");
				body = {"code":"500000","message":"系统累了,请刷新页面重试","data":[]};
			}finally{
				return [null, body];
			}
		}else{
			return [null, body];
		}
	},
	takeLog: function(body, type){
		var self = this,
			takeTimes = (self.endTime = new Date().getTime(), self.endTime - self.startTime),
			logs = ["[--PROXY--] " + (self.opt.host+ ":"+ self.opt.port+ self.opt.path) + " TAKETIMES(ms):" + takeTimes+ " "];
			logs.push(JSON.stringify(self.data) );
			logs.push(body);
			logger[type](logs.join("\r\n"));
		return self;
	},
	format: function(args){
		var self= this;
		if(args.data && (args.data instanceof Object) ){
			for(var k in args.data){
	            if (args.data[k] !== undefined) {
	                self.data[k] = args.data[k];
	            }
			}
		}
		//兼容java服务端无法解析JOSN全字符串化的参数
		if (args.keyValue) {
			self.params = 	querystring.stringify(self.data);
		} else if("string"=== typeof args.data){
			self.data= {params: args.data};
			self.params= new Buffer(args.data);
		} else {
			self.params = new Buffer(JSON.stringify(self.data));
		}
	}
}

module.exports = {
	invoke: function(args, fn){
		if (config.preview) {//预览模式
			var pp = new Proxy(args);
			redisHelper.acquire(function(err, client){
        		client.get("operation-data-remark", function(err, result){
            		pp.opt.headers['remark'] = result;
            		return pp.invoke(fn);
            	});
        	});
		} else {
			return new Proxy(args).invoke(fn);
		}
	}
};