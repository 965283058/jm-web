function supUrl(req, res, next){
	this.req = req;
	this.res = res;
	this.next = next;
	this.expandParams = {};
}

supUrl.prototype = {
	constructor: supUrl,
	filter: function(keys){
		if(keys && (keys instanceof Array) ){
			//
		}else{
			keys = [];
		}
		var self = this, key = null;
		while(key = keys.shift()){
			if(key in self.req.query){
				self.expandParams[key] = self.req.query[key];
			}
		}
		self.res.locals.vdUrl = new Url(self.expandParams);
		return self;
	},
	parser: function(fns){
		if(fns && (fns instanceof Array) ){
			//
		}else{
			fns = [];
		}
		var self = this, fn = null, len = fns.length;
		while(len--){
			fn = fns.shift();
			if(fn && fn.init){
				fn.init(self.req, self.res, self.next);
			}
		}
		return self;
	}
}


/****/
function Url(expandParams){
	this.expandParams = expandParams||{};
}

Url.prototype = {
	constructor: Url,
	parse: function(path){
		var self = this;
		self.path = path;
		return self;
	},
	toString: function(params){
		var self = this, _params = params||{}, search = "";
		for(var k in self.expandParams){
			if(k in _params){
				continue;
			}
			_params[k] = self.expandParams[k];
		}
		for(var k in _params){
            if (_params[k]) {
                search +=("&" + k + "=" + _params[k]);
            }
		}
		if(search.length&& self.path.indexOf("?")===-1 ){
			search = search.replace(/^&/, "?");
		}
		return self.path + search;
	}
}
	


module.exports = supUrl;