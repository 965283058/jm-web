var tools = require("./tools"),
	proxy = require("../utils/proxy"),
    config = require("../utils/config");


function Statistics(){
	
}

Statistics.prototype = {
	invoke: function(args){
		var self = this;
		var path = new Path(args).toString();
		proxy.invoke({
			data:{},
			protocol: "http",
			host: config.statistics.host,
			port: config.statistics.port,
			path: "/wm.js?"+path,
			method:"GET"
		}, function (err, result) {
			//console.log(result);
		});
		return self;
	}
}


	//path参数类
	var params = {
		StatType: 	"h5partner",
		vid: "{vid}",
		partnertele: "{partnertele}",
		action: "{action}",
		channel: "{channel}",
		pop_id: "{pop_id}"
	},
	params_path = raw(params);

function Path(args){
	this.params_path = params_path;
	this.params = args;
}

Path.prototype = {
	toString: function(){
		var params = this.params,
			params_path = this.params_path,
			path = params_path.replace(/{(.*?)}/gi, function($1, $2){
				return ($2 in params)?params[$2]: -1;
			});
		//console.log(this.params);
		return encodeURI(path);
	}
}

//字典排序
function raw(args) {
	var keys = Object.keys(args),
		newArgs = {},
		string = '';
	keys = keys.sort();
	keys.forEach(function (key) {
		newArgs[key] = args[key];
	});
	for (var k in newArgs) {
		string += '&' + k + '=' + newArgs[k];
	}
	string = string.substr(1);
	return string;
}

module.exports = new Statistics();