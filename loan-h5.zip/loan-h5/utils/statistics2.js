var crypto = require("crypto"),
	key = "kpnfb0hq6m4";
/**
	statistics2
	旨在替换statistics，并实现接口清晰易于扩展的方法
	对外提供的方法
	a)init
	b)invoke
	c)行为 action(fn)- pageview, tap, timestamp
	d)用户 user(fn)- yunjieid, ip, uid, vid, wid
	e)页面信息 page(fn)- channel, url, refererUrl, pageName
	f)app信息 app(fn)- UA, appversion, appmarket, uuid
	g)设备信息 platform(fn)- platform
	h)业务 business(fn)- vid, product, order, elementid
	i)扩展 extend(fn)
 */

 var tools= 		require("./tools"),
	 proxy= 		require("../utils/proxy"),
     config= 		require("../utils/config"),
     gks= 			["action", "page", "platform", "user", "business", "app", "extend"],
     g_action= 		["eventtype", "elementid", "timestamp"],
     g_page= 		["pagename", "url", "ua", "uuid"],
     g_platform= 	["platform", "platformversion", "manufacture", "model", "idfa", "imei"],
     g_user= 		["yunjieid", "uid", "wid", "cip", "cuid", "unionid"],
     g_business= 	["shopid", "producttype", "gid", "wpgoodsid", "aid", "orderno", "ordertype"],
     g_app= 		["appversion", "appmarket"],
     g_extend= 		[];


 /**
	@class Statistics
  */
function Statistics(){
  	var self = this;
  	return self;
}

/**
	@protoype {object}
 */

Statistics.prototype= {
	/**
		@param {req}
		@param {res}
		@param {next}
		@returns this
	  */
	init: function(req, res, next){
		var self = this;
		self.data= {};
		return self;
	},
	/**
		@param {req}
		@param {res}
		@param {next}
		@returns this
	  */
	invoke: function(req, res, next, args, fn){
		var self= this;
		self.data= {
			StatType:  "dkwpath",
			timestamp: +new Date(),
			shopid: req.session.shopInfo ? (req.session.shopInfo.shop_id||-1) : -1,
			from_app: ~~res.locals.config.isVdianAPP,
			//page
			url: res.locals.config.url,
            channel: req.session.urlInfo.channelInfo,
            wmsource: req.session.urlInfo.channelSource,
            wmbusiness: req.session.urlInfo.channelBusiness,
            hop: req.session.urlInfo.hop,
            //platform
            ua: res.locals.config.ua,
            platform: res.locals.config.platform,
			//user
			yunjie_id: req.session.user.yunjie_id,
			unionid: req.session.wechat.current.unionid||-1,
            uid: req.session.user.id,
            wid: req.session.user.wid|| -1,
            cwid: res.locals.config.vapp.wid||-1, //app实际的wid 有可能跟wid不一致
            cip: res.locals.config.clientIp,
            cuid: req.session.client.guid,
            uuid: res.locals.config.venv.serviceUUID|| ""

		};
		self.group(args);
		var	path= formatData(self.data);
		self.log(null, null, null, path, fn);
		return self;
	},
	log: function(req, res, next, path, fn){
		var self= this,
			sign= getSign(path),
			_path= path+ "&sign="+ sign.substring(0, 5);
		proxy.invoke({
            data:{},
            protocol: "http",
            host: config.statistics.host,
            port: config.statistics.port,
            path: "/wm.js?"+_path,
            method:"GET"
        }, function (err, result) {
        	if("function"=== typeof fn){
        		fn(err, result);
        	}
        });
		return self;
	},
	group: function(args){
		var self= this,
			gv= null;
		gks.forEach(function(v, k){
			gv= args[v];
			if("object"=== typeof gv){
				for(var kk in gv){
					self.data[kk]= gv[kk];
				}
			}
		});
	}
};

//字典排序 返回格式化数据
function formatData(args) {
	var keys= Object.keys(args),
		newArgs= {},
		string= '';
	keys= keys.sort();
	keys.forEach(function(v, i){
		string+= '&'+ v+ '='+ encodeURIComponent(args[v]);
	});
	string= string.substr(1);
	return string;
}
function getSign(str){
	var content = str + key;
    var md5 = crypto.createHash('md5');
    md5.update(content);
    var secret = md5.digest('hex');
    return secret;
}



 module.exports= Statistics;