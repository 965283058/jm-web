var redisHelper= require("../models/redisHelper"),
    config = require("../utils/config"),
	tools = require("../utils/tools");

//用于给运营配置的页面
exports.setRemark = function (req, res) {
    if (config.preview) {
	   var remark = req.body.remark;
        redisHelper.acquire(function(err, client){
            client.set("operation-data-remark", remark, function (err2, res2) {
        	   var result = {};
        	   if (err2) {
        		  result.code = 1001;
        		  result.message = '设置失败';
        		  result.data = res2;
        	   } else {
        		  result.code = 0;
        		  result.message = '设置成功';
        		  result.data = res2;
        	   }
        	   tools.rendJSON(req,res,result)
            });
        });
    } else {
        tools.rendJSON(req, res, {code:2000, message:'拒绝访问'});
    }
}