var location_ctr = require('../controllers/location'),
	tools = require("../utils/tools"),
	Helper = require("../utils/helper");

/*根据坐标信息获取地址详情*/
exports.geocoder = function (req, res) {
	if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var args = {
        lat: req.body.lat,
        lng: req.body.lng
    }
    location_ctr.geocoder(args, function(err, result){
        tools.rendJSON(req, res, result || {});
    });
}