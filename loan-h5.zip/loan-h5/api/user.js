"use strict";

var tools = require("../utils/tools"),
    user_ctr = require('../controllers/user'),
    mduc= require("../utils/mduc"),
    crypto = require('crypto'),
    verifyCodeHelper= require("../utils/verifyCodeHelper"),
    geetest = require('geetest')(config.geetestKeys.private, config.geetestKeys.public),
    QQVcode_utl= require("../utils/qqVcode"),
    Helper = require("../utils/helper");

/*******************************


/* 登录 */
exports.login = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var query= req.body,
        args= {
            mobile:     query.mobile,
            verifycode: query.verifycode,
            mode:       query.mode,
            clientIp:   tools.getClientIp(req),
            appIdentifier:req.body.appIdentifier||""
        },
        result= null;
    new Promise(function(resolve, reject){
        user_ctr.checkCode({
            mobile:     args.mobile,
            mode:       args.mode,
            code:       args.verifycode,
            clientIp:   args.clientIp,
            appIdentifier:args.appIdentifier
        }, function (err, result2) {
            //return resolve();
            if (err) {
                reject(err);
            } else if (0== result2.code) {
                resolve();
            }else{
                reject(result2.message);
            }
        });
    }).then(function(){
        return new Promise(function(resolve, reject){
             user_ctr.add({
                user_id:    req.session.user.id,
                openid:     req.session.wechat.openid,
                unionid:   req.session.wechat.current.unionid,
                mobile:     args.mobile,
                yunjie_id:  req.session.user.yunjie_id,
                code:       args.verifycode,
                clientIp:   args.clientIp,
                open_id_type: /duobao/i.test(req.hostname)? 300: 100,
                appIdentifier:args.appIdentifier
            }, function(err, result) {
                if (err) {
                    reject(err);
                } else if (result.code == 0) {
                    resolve(result);
                }else{
                    reject(result.message);
                }
            });
        });
    }).then(function(result){
        // 把当前用户放到session中
        var yunjie_id= req.session.user.yunjie_id;
        req.session.user=          result.data;
        req.session.user.id=       result.data.user_id;
        req.session.user.openid=   result.data.openid||result.data.vd_openid;
        req.session.user.shop_id = result.data.shop_id;
        req.session.user.yunjie_id=yunjie_id;
        // 注册成功后跳转到个人信息
        result.data= {
            isAdd:      result.data.isAdd,
            wid:        result.data.wid,
            mobile:     result.data.mobile,
            isSelfShop: false//req.session.shopInfo.user_id=== req.session.user.user_id
        };
        
        if(res.locals.config.isWeixin|| req.headers["wx-app"]){
            var u_uid=  req.session.user.union_id,
                c_uid=  req.session.wechat.current.unionid|| req.session.wechat.current.union_id;
            if(!u_uid){
                mduc.doWXBind(req, res);
            }else if(u_uid!== c_uid){
                return tools.rendJSON(req, res, {code: 1000, message: "unionid 非当前微信unionid" });
            }
            req.session.save();
            tools.rendJSON(req, res, result || {});
        }else{
            req.session.save();
            tools.rendJSON(req, res, result || {});    
        }
        user_ctr.loginMsg({
            wid: req.session.user.wid,
            BaseAppType: "H5",
            wxUnionId: req.session.wechat.current.unionid|| "",
            phone: req.session.user.mobile,
            browser: /micromessenger|qq|HTML5/i.exec(res.locals.config.ua)[0]
        }, function(){

        });
        
    }).catch(function(e){
        tools.rendJSON(req, res, {code: 1000, message: e, data: null});
    });
}


function checkAPPShopLogin(req, res) {
    return new Promise(function (resolve, reject) {
        var query = req.body,
            args = {
                mobile: query.mobile,
                uuid: query.uuid,
                shop_id: query.shop_id,
                wid: query.wid,
                token: query.token
            },
            error = -1;
        //
        if (/^\d{1,20}$/.test(args.shop_id) && /^\d{1,20}$/.test(args.wid)) {
            //jsapi授权的店铺信息
            shop_ctr.checkAPPShopLogin(args, function (err, result) {
                if (!err && 0 === result.code) {
                    error = 0;
                } else {
                    error = "1 invalid token";
                }
                if (req.session.activity) {

                } else {
                    req.session.activity = {};
                }
                req.session.activity.mum = {
                    shop_id: args.shop_id,
                    wid: args.wid,
                    status: error,
                    mobile: args.mobile
                }
                resolve();
            });
        } else {
            resolve();
        }
    })
}

/* 登录 */
exports.applogin = function (req, res) {
    checkAPPShopLogin(req, res).then(function () {
        var query = req.body,
            args = {
                mobile: query.mobile,
                uuid: query.uuid,
                shop_id: query.shop_id,
                wid: query.wid,
                token: query.token
            };
        var activityMum = req.session.activity.mum;
        if (activityMum.status != 0) {
            return tools.rendJSON(req, res, {
                code: 1000,
                message: "您的账号有误，或者已在其他设备登录。",
                data: []
            });
        } else {
            if (!/^\d{5,20}$/.test(args.mobile)) {
                return tools.rendJSON(req, res, {
                    code: 1000,
                    message: "手机号有误",
                    data: []
                });
            }
            user_ctr.getUserByMobile(args, function (err, result) {
                if (err) {
                    console.log(err);
                } else if (result.code == 0) {
                    //var isSelf= new RegExp(result.data.wid+ "$").test(args.wid);
                    var isSelf = true;
                    if (isSelf) {
                        // 把当前用户放到session中
                        var yunjie_id = req.session.user.yunjie_id;
                        req.session.user = result.data;
                        req.session.user.id = result.data.user_id;
                        req.session.user.openid = result.data.openid || result.data.vd_openid;
                        req.session.user.shop_id = result.data.shop_id;
                        req.session.user.yunjie_id = yunjie_id;
                        // 注册成功后跳转到个人信息
                        req.session.save();
                        delete result.data;
                    }
                    tools.rendJSON(req, res, result || {});
                } else {
                    // 设置提示信息
                    tools.rendJSON(req, res, result || {});
                }
            });
        }
    })
}


exports.getAccessToken = function (req, res) {
    if (!Helper.apiLogin(req, res)) {
        return tools.rendJSON(req, res,{code:1000, message:"请先登录" });
    }
    var args = {
        openid:"1"
    }
    user_ctr.getAccessToken(args, function(err, result){
        tools.rendJSON(req, res, {access_token:result.access_token});
    });
}

exports.wxinfo = function (req, res) {
    if (!Helper.apiLogin(req, res)) {
        return tools.rendJSON(req, res,{code:1000, message:"请先登录" });
    }
    user_ctr.getWXUserInfoByOpenid({openid: "1"}, function(err, result){
        res.end(JSON.stringify(result) );
    });
}

//获取是否已关注
exports.getWPUserByOpenid = function (req, res) {
    if (!Helper.apiLogin(req, res)) {
        return tools.rendJSON(req, res,{code:1000, message:"请先登录" });
    }
    var args = {
        openid:req.session.user.openid
    }
    if(!args.openid){
        tools.rendJSON(req, res, {});
    }else{
        user_ctr.getWPUserByOpenid(args, function(err, result){
            tools.rendJSON(req, res, result);
        });
    }
}


var validator= {
    handleEvent: function(req, res, next){
        return new Promise(function (resolve, reject) {
            var query= req.body|| {},
                mode= query.mode;
            if("h5IntpayLogin"===mode||"h5NewLogin"=== mode|| "h5FastLogin"=== mode|| "h5Login"=== mode || "h5CouponExchange"=== mode || "1010-coupon"===mode|| "tuan-coupon"=== mode){
                var _validate= query.validate;
                if(_validate){
                    return validator[{"geetest": "fkv_jiyan", "qq": "fkv_qq"}[_validate.type] ](req, res, resolve, reject);
                }else{
                    resolve();
                }
            }else if("h5SearchOrder"=== mode){
                return validator.fkv_tencent(req, res, resolve, reject);
            }else{
                req.body.verify_valid= true;
                resolve();
            }
        });
    },
    fkv_tencent: function(req, res, resolve, reject){
        var query= req.body|| {},
            ticket= query.data.ticket,
            csnonce= query.data.csnonce;
        req.body.verify_valid= false;
        if(ticket){
            var args= {
                ticket: ticket,
                csnonce: csnonce,
                userIp: tools.getClientIp(req)
            };
            verifyCodeHelper.checkVcode(args, function(err, result){
                if(0=== result.code){
                    req.body.verify_valid= true;
                    resolve();
                }else{
                    var data= {
                        code:1001,
                        message: "验证码校验失败！",
                        data:null
                    };
                    tools.rendJSON(req, res, data);
                    reject();
                }
            });
        }else{
            resolve();
        }
    },
    fkv_jiyan: function(req, res, resolve, reject){
        var query= req.body,
            _validate = query.validate;
        if(_validate){
            var args= {
                challenge: _validate.geetest_challenge,
                validate: _validate.geetest_validate,
                seccode: _validate.geetest_seccode
            };
            geetest.validate(args, function(err, result)  {
                if(err|| !result){
                    req.body.verify_valid= false;
                     var data= {
                        code:1001,
                        message: "风控验证码校验失败！",
                        data:null
                    };
                    req.body.passCode= "";
                    tools.rendJSON(req, res, data);
                    reject();
                }else{
                    req.body.verify_valid= true;
                    req.body.passCode = validator.encodePassCode(req.body.passCode);
                    resolve();
                }
            })
        }else{
            resolve();
        }
    },
    fkv_qq: function(req, res, resolve, reject){
        var query= req.body,
            _validate = query.validate;
        if(_validate){
            var args= {
                cip: res.locals.config.clientIp,
                businessId: parseInt(config.env.slice(0, 2), 32),
                ticket: _validate.ticket
            };
            QQVcode_utl.checkVcode(args, function(err, result){
                if(err){
                    req.body.verify_valid= false;
                    var data= {
                        code:1001,
                        message: "风控验证码校验失败！",
                        data:null
                    };
                    req.body.passCode= "";
                    ools.rendJSON(req, res, data);
                    reject();
                }else{
                    req.body.verify_valid= true;
                    req.body.passCode = validator.encodePassCode(req.body.passCode);
                    resolve();
                }
            });
        }else{
            resolve();
        }
    },
    init: function(args, fn){
        if(1== args.type){
        //极验
            geetest.register(function(err, challenge){
                var data= {
                    type:       "geetest",
                    err:        err,
                    challenge:  challenge
                };
                fn(data);
            });
        }else{
            var _args= {
                cip: args.clientIp,
                businessId: parseInt(config.env.slice(0, 2)+ "02", 32)
            };
            QQVcode_utl.createVcode(_args, function(err, result){
                var data= {
                    type:   "qq",
                    err:    err,
                    url:    result.url
                };
                fn(data);
            });
        }
    },
    encodePassCode: function(passCode){
        var content = passCode + "h5$s7df9sdf9ss9r8gs#{}|:~$",
            md5 = crypto.createHash('md5');
        return (md5.update(content), md5.digest('hex')); 
    },
    encodeSign: function(){

    }
};


exports.verify = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    validator.handleEvent(req, res).then(function () {
        //快速查询订单已接入（腾讯）风控
        if ("h5SearchOrder" === req.body.mode && !req.body.verify_valid) {
            var data = {
                code: 1001,
                message: "验证码校验失败！",
                data: null
            };
            return tools.rendJSON(req, res, data);
        }
        var now = new Date().getTime();
        if (!req.session.sendCode) {
            req.session.sendCode = {};
        }
        if (!req.session.sendCode.lastTime || now - req.session.sendCode.lastTime > 1 * 1000) {
            req.session.sendCode.lastTime = now;
            var data = {
                mobile: req.body.mobile,
                mode: req.body.mode,
                clientIp: tools.getClientIp(req),
                //passCode: req.body.passCode?validator.encodePassCode(req.body.passCode):'',
                passCode: req.body.passCode||'',
                appIdentifier:req.body.appIdentifier||""
            };
            if (req.body.isIndiana) {
                data.tosmsapp = 'com.weimob.indiana';
            }
            user_ctr.sendCode(data, function (err, result) {
                if (err) {
                    console.log(err);
                } else {
                    delete result.traces;
                    result.sign = "";
                    if (0 == result.code) {
                        var token = [data.mobile, data.mode, data.clientIp, (now + 3 * 60 * 1e3).toString(32), "6dget1o"],
                            md5 = crypto.createHash('md5'),
                            sign = (md5.update(token.join("-")), md5.digest('hex').slice(0, 5));
                        //
                        result.sign = sign + token[3];
                    } else if ("200002" == result.code) {
                        return validator.init({
                            type: parseInt(result.data.check_type),
                            clientIp: res.locals.config.clientIp
                        }, function (thirdValidation) {
                            result.thirdValidation = thirdValidation;
                            tools.rendJSON(req, res, result);
                        });
                    } else {

                    }
                    tools.rendJSON(req, res, result || {});
                }
            });
        } else {
            req.session.sendCode.lastTime = now;
            var msgObj = {
                message: "请求过频，请稍候"
            }
            tools.rendJSON(req, res, msgObj);
        }
    });
}