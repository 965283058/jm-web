var tools=              require("../utils/tools"),
    Helper =            require("../utils/helper");

//客服验证
exports.index = function (req, res) {
	if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var code = req.body.code,
        result = null;
    if (req.session.user.verifyPicCode == code) {
        req.session.webim = null;
        result = {
            code: 0,
            message: "success"
        };
    } else {
        result = {
            code: 1,
            message: "failed"
        };
    }
    tools.rendJSON(req, res, result || {});
}