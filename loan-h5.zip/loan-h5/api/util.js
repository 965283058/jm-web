"use strict";

var config=             require('../utils/config'),
    user_ctr=           require('../controllers/user'),

    webim_ctr=          require('../controllers/webIm'),
	tools=              require("../utils/tools"),
	crypto=             require('crypto'),
    verifyCodeHelper=   require("../utils/verifyCodeHelper"),
    geetest=            require('geetest')(config.geetestKeys.private, config.geetestKeys.public),
    QQVcode_utl=        require("../utils/qqVcode"),
    admin=              require("../controllers/admin"),
    user_ctr=           require("../controllers/user"),
    Helper=				require("../utils/helper"),
    Vcode=              require("../models/vcode"),
    redisHelper=        require("../models/redisHelper"),
    vcode_utl=          require("../utils/vcode");
    //Promise=            require("promise");


function encrypt(str, secret) {
    var cipher = crypto.createCipher('aes192', secret);
    var enc = cipher.update(str,'utf8','hex');
    enc += cipher.final('hex');
    return enc;
}
function decrypt(str, secret) {
    var decipher = crypto.createDecipher('aes192', secret);
    var dec = decipher.update(str,'hex','utf8');
    dec += decipher.final('utf8');
    return dec;
}

/**
    校验第三方风控
 */
var validator= {
    handleEvent: function(req, res, next){
        var query= req.body|| {},
            mode= query.mode;
        if("h5NewLogin"=== mode){
            var _validate= query.validate;
            if(_validate){
                return validator[{"geetest": "fkv_jiyan", "qq": "fkv_qq"}[_validate.type] ](req, res, next);
            }else{
                next();
            }
        }else if("h5SearchOrder"=== mode){
            return validator.fkv_tencent(req, res, next);
        }else{
            req.body.verify_valid= true;
            next();
        }
    },
    fkv_tencent: function(req, res, next){
        var query= req.body|| {},
            ticket= query.data.ticket,
            csnonce= query.data.csnonce;
        req.body.verify_valid= false;
        if(ticket){
            var args= {
                ticket: ticket,
                csnonce: csnonce,
                userIp: tools.getClientIp(req)
            };
            verifyCodeHelper.checkVcode(args, function(err, result){
                if(0=== result.code){
                    req.body.verify_valid= true;
                    next();
                }else{
                    var data= {
                        code:1001,
                        message: "验证码校验失败！",
                        data:null
                    };
                    return tools.rendJSON(req, res, data);
                }
            });
        }else{
            next();
        }
    },
    fkv_jiyan: function(req, res, next){
        var query= req.body,
            _validate = query.validate;
        if(_validate){
            var args= {
                challenge: _validate.geetest_challenge,
                validate: _validate.geetest_validate,
                seccode: _validate.geetest_seccode
            };
            geetest.validate(args, function(err, result)  {
                if(err|| !result){
                    req.body.verify_valid= false;
                     var data= {
                        code:1001,
                        message: "风控验证码校验失败！",
                        data:null
                    };
                    req.body.passCode= "";
                    return tools.rendJSON(req, res, data);
                }else{
                    req.body.verify_valid= true;
                    req.body.passCode = validator.encodePassCode(req.body.passCode);
                    next();
                }
            })
        }else{
            next();
        }
    },
    fkv_qq: function(req, res, next){
        var query= req.body,
            _validate = query.validate;
        if(_validate){
            var args= {
                cip: res.locals.config.clientIp,
                businessId: parseInt(config.env.slice(0, 2), 32),
                ticket: _validate.ticket
            };
            QQVcode_utl.checkVcode(args, function(err, result){
                if(err){
                    req.body.verify_valid= false;
                    var data= {
                        code:1001,
                        message: "风控验证码校验失败！",
                        data:null
                    };
                    req.body.passCode= "";
                    return tools.rendJSON(req, res, data);
                }else{
                    req.body.verify_valid= true;
                    req.body.passCode = validator.encodePassCode(req.body.passCode);
                    next();
                }
            });
        }else{
            next();
        }
    },
    init: function(args, fn){
        if(1== args.type){
        //极验
            geetest.register(function(err, challenge){
                var data= {
                    type:       "geetest",
                    err:        err,
                    challenge:  challenge
                };
                fn(data);
            });
        }else{
            var _args= {
                cip: args.clientIp,
                businessId: parseInt(config.env.slice(0, 2)+ "02", 32)
            };
            QQVcode_utl.createVcode(_args, function(err, result){
                var data= {
                    type:   "qq",
                    err:    err,
                    url:    result.url
                };
                fn(data);
            });
        }
    },
    encodePassCode: function(passCode){
        var content = passCode + "h5$s7df9sdf9ss9r8gs#{}|:~$",
            md5 = crypto.createHash('md5');
        return (md5.update(content), md5.digest('hex')); 
    },
    encodeSign: function(){

    }
};



exports.verifyMobilePartner = function (req, res) {
	if (!Helper.isPost(req, res)) {
		return res.end('only POST is accepted');
	}
    var query=  req.body,
        mobile= query.phone,
        _decrypt= query.decrypt,
        args=   {
            mobile:     mobile,
            is_send_code:    0,
            clientIp: tools.getClientIp(req)
        },
        partnerData= {

        }; //最终返回给web的数据

    if(1== _decrypt){
        validator.fkv_qq(req, res, function(){
            var verify_valid= req.body.verify_valid,
                result= {code: 0, data: {type: "decrypt", edata: "", message: null} };

            try{
                result.data.edata= JSON.parse( decrypt(query.edata, "sdf234df") );
            }catch(e){
                result.code= 1001;
                result.message= "未知错误，请稍候重试。";
            }
            return tools.rendJSON(req, res, result );
        });
    }



    function getQQValidate(){
        return new Promise(function(resolve, reject){
            validator.init({type: 2, clientIp: res.locals.config.clientIp}, function(thirdValidation){
                resolve(thirdValidation);
            });
        });
    }
    new Promise(function(resolve, reject){
        user_ctr.checkMobile2(args, function(err, result) {
            if(err){
                reject(err);
            }else if(0!= result.code){
                reject(new Error(result.message) );
            }else{
                partnerData.base= {
                    wid: result.data.wid,
                    mode: result.data.mode
                };
                resolve(result.data);
            }
        });
    }).then(function(data){
        //当前手机号，如果已经注册，则查询他的店铺信息
        if("register"!==data.mode){
            partnerData.type= "encrypt";
            return Promise.all([getShopInfo({wid: data.wid}), getQQValidate() ]).then(function(datas){
                partnerData.thirdValidation= datas[1];
                return datas[0];
            });
        }else{
            return data;
        }
    }).then(function(data){
        //当前手机号，如果已经有师傅，则查询师傅的店铺信息
        //自己的店铺信息
        partnerData.self= {
            shop_id: data.shop_id,
            shop_key: data.nickname,
            shop_nickname: data.nickname
        };
        if(parseInt(data.master_shop_id) ){
            return getShopInfo({shop_id: data.master_shop_id});
        }else{
            return null;
        }
    }).then(function(data){
        //合伙人信息
        data&& (partnerData.partner= {
            shop_id: data.shop_id,
            title: data.title
        });
        _render(req, res, {code: 0, data: partnerData, message: ""});
    }).catch(function(e){
        if(partnerData.base){
            _render(req, res, {code: 100, data: partnerData, message: e});
        }else{
            _render(req, res, {code: 1001, data: null, message: e.toString()});
        }
    });

    function _render(req, res, result){
        if(1001!== result.code&& "register"!== result.data.base.mode){
            result.data= {
                type: "encrypt",
                edata: encrypt(JSON.stringify(result.data), "sdf234df"),
                thirdValidation: result.data.thirdValidation
            }
        }
        tools.rendJSON(req, res, result);
    }
}

/*  */
exports.checkQCode = function (req, res) {
	if (!Helper.isPost(req, res)) {
		return res.end('only POST is accepted');
	}
    var query= req.body,
        args= {
            cip: res.locals.config.clientIp,
            businessId: parseInt(config.env.slice(0, 2), 32),
            ticket: query.ticket
        };
    QQVcode_utl.checkVcode(args, function(err, result){
        if(err){
            result= {
                code: 100,
                message: "unknow err"
            };
        }else{
            var content = query.vcode + "h5$s7df9sdf9ss9r8gs#{}|:~$";
            var md5 = crypto.createHash('md5');
            md5.update(content);
            result.vvcode = md5.digest('hex');
        }
        return tools.rendJSON(req, res, result);
    });
}



exports.statis = function (req, res) {
	if (!Helper.isGet(req, res)) {
		return res.end('only GET is accepted');
	}
	var pathParams = req.pathParams;
    switch (pathParams[0]) {
        case "get":
            statisGet();
            break;
        case "add":
        	statisAdd();
        	break;
        default:
        	res.end('404');
    }

    function statisGet () {
    	validKey001(req, res).then(function(){
    		var query= req.query,
        		sign= query.sign,
        		key= query.key;
    		var val= {
        		key: key,
        		sum: 0
    		};
    		admin.getVal(val, function(err, result){
        		var _result= {};
        		if(err){
            		_result= {
                		code: 1000,
                		data: result,
                		message: err
            		};
        		}else{
            		_result= {
                		code: 0,
                		data: result,
                		message: "success"
            		};
        		}
        		tools.rendJSON(req, res, _result);
    		});
    	}).catch(function (err) {		
			tools.rendJSON(req, res, {code:1000, data: null, message: err});		
		});
    }

    function statisAdd () {
    	var query= req.query,
        	sign= query.sign,
        	key= query.key;
    	var val= {
        	key: key,
        	sum: 0
    	};
    	validKey001(req, res).then(function(){
        	admin.getVal(val, function(err, result){
            	if(err){
                	reject(err);
            	}else{
                	var sum= (parseInt(result.sum)||0) +1;
                	resolve(sum);
            	}
        	});
    	}).then(function(sum){
        	val.sum= sum;
        	admin.setVal(val, function(err, result){
            	tools.rendJSON(req, res, {code:0, data: val, message: "sucess" });
        	});
    	}).catch(function(err){
        	tools.rendJSON(req, res, {code:1000, data: null, message: err});
    	});
    }
}

function validKey001(req, res){
	return new Promise(function(resolve, reject) {
		var query= req.query,
        	sign= query.sign,
        	key= query.key;
    	if(!sign || !key){
    		reject("sign or key is empty");
        	//return tools.rendJSON(req, res, {code:1000, data: null, message: "sign or key is empty"});
    	}else{
        	var content= key+ "key001394jdsfkdsf",
            	md5= crypto.createHash('md5'),
            	_sign= (md5.update(content),  md5.digest('hex')).slice(0, 5);
        	if(_sign!== sign){
        		reject("sign or key is wrong");
            	//tools.rendJSON(req, res, {code: 1000, data: null, message: "sign or key is wrong"});
        	}else{
        		resolve();
            	//next();
        	}
    	}
	});
}

/**
    上传图片
 */
exports.uploadimage = function (req, res) {
	if (!Helper.isPost(req, res)) {
		return res.end('only POST is accepted');
	}
	user_ctr.uploadImage({
        uploadimage: req.body.imgfile
    }, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, {code: 1000, message: "上传失败", data: null});
        } else {
            tools.rendJSON(req, res, result || {});
        }
    });
}

/************************************************************
    node 系统配置文件
************************************************************/
exports.admin = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var pathParams = req.pathParams;
    switch (pathParams[0]) {
        case "login":
            adminLogin(req, res);
            break;
        default:
            res.end(404);
    }
}

function adminLogin (req, res) {
    var query= req.body,
        typeId= query.typeId,
        args= {
            mobile: query.mobile,
            mode: query.mode,
            code: query.vcode,
            pwd: query.pwd
        };
    //验证验证码，正确后登录
    var msg= null;
    if("13658900050"!== args.mobile){
        msg= "请输入qq的手机号";
    }else if(!/^\d{4,6}$/.test(args.code) ){
        msg= "请输入验证码";
    }else if("anjey_md_admin"!== args.pwd){
         msg= "密码错误";
    }
    if(msg){
        return tools.rendJSON(req, res, {code:1000, message: msg});
    }
    user_ctr.checkCode(args, function (err, result) {
        if(err){
            tools.rendJSON(req, res, {code:1001, message: "checkcode 异常"});
        }else if(0!= result.code){
             tools.rendJSON(req, res, {code:1002, message: "验证码错误"});
        }else{
            //获取配置，并保存admin session
            req.session.admin= {
                phone:"13658900050",
                vcode: "xxxx",
                pwd: "vv***vvv",
                isAdminLogin: 1
            };
            req.session.save();
            tools.rendJSON(req, res, {code:0, data:null, message:"登录成功" });
        }
    });
}

exports.sendCode= function(req, res){
    var query= req.body,
        remark= query.mode,
        args= {
            phone: query.phone//
        },
        vkey= query.vkey,
        passCode= query.passCode,
        passCode_arr= passCode.split("-"),
        _passCode= null,
        _result= null;
     //
    if(!remark in config.sms|| !vkey){
        _result= {code: 1010, message: "mode或者vkey 错误", data: null};
    }
    _passCode= vcode_utl.encodePassCode(args.phone, config.sms[remark], vkey, passCode_arr[0], passCode_arr[1]);
    if(!vcode_utl.checkEqual(_passCode, passCode) ){
        _result= {code: 1012, message: "passCode异常", data: null};
    }
    //
    if(_result){
        return tools.rendJSON(req, res, _result);
    }
    //
    var _vcode= new Vcode(config.sms[remark], config.env);
    //
    new Promise(function(resolve, reject){
        if(passCode_arr[0]>1&& passCode_arr[0]<5){
            if(req.body.validate==''){
                _result= {code: 1003, message: "非法请求[no validate]"};
                reject();
            }else{
                resolve(req.body.validate);
            }
        }else{
            resolve(req.body.validate);
        }
    }).then(function(validate){
        
        if(validate != ''){
            return new Promise(function(resolve, reject){
                validator[{"geetest": "fkv_jiyan", "qq": "fkv_qq"}[validate.type] ](req, res, function(){
                    resolve();
                });
            });
        }else{
            return 1;
        }
    }).then(function(){
        _vcode.sendCode(args, function(err, result){
            tools.rendJSON(req, res, result); 
        });
    }).catch(function(err){
        tools.rendJSON(req, res, _result);
    });
}
exports.checkCode= function(req, res){
    var query= req.body,
        remark= query.mode,
        args= {
            phone: query.phone,//"13636607550"
            vcode: query.vcode
        },
        vkey= query.vkey,
        passCode= query.passCode,
        passCode_arr= passCode.split("-"),
        _passCode= null,
        _result= null;
    //
    if(!remark in config.sms|| !vkey){
        _result= {code: 1010, message: "mode或者vkey 错误", data: null};
    }
    _passCode= vcode_utl.encodePassCode(args.phone, config.sms[remark], vkey, passCode_arr[0], passCode_arr[1]);
    if(!vcode_utl.checkEqual(_passCode, passCode) ){
        _result= {code: 1012, message: "passCode异常", data: null};
    }
    //
    if(_result){
        return tools.rendJSON(req, res, _result);
    }
    //
    var _vcode= new Vcode(config.sms[remark], config.env);
    _vcode.checkCode(args, function(err, result){
       tools.rendJSON(req, res, result);
    });
}

exports.getKey= function(req, res){
    var query= req.body,
        type= query.type,
        rdbk= query.rdbk,
        adminRdbk= "admin-1000-all";
    switch(type){
        case "sms":
            rdbk= "sms-intpay.addfriend-"+ rdbk;
        break;
        case "all":
            rdbk= adminRdbk;
        break;
        default:
            rdbk= 0;
            //
        break;
    }
    //
    redisHelper.acquire(function(err, client){
        new Promise(function(resolve, reject){
            var user= req.session.user;
            //
            if(!rdbk|| !user || !user.wid){
                return reject();
            }else if( "13636607550"== user.mobile){
                return resolve();
             }else if("all"=== type&& "13636607550"!== user.mobile){
                return reject();
            }
            client.get(adminRdbk, function(err, result){
                if(err||! result){
                    reject();
                }else if((result= JSON.stringify(result), result.indexOf(user.mobile)<0 ) ){
                    reject();
                }else{
                    resolve();
                }
            });
        }).then(function(){
            client.get(rdbk, function(err, result){
                if(err){
                    tools.rendJSON(req, res, {code: 1000, data: null, message: "未知异常"});
                }else{
                    var passCode= vcode_utl.encodePassCode(rdbk, "rdbk.ops", "rdbk.ops", "0", Date.now() );
                    tools.rendJSON(req, res, {code: 0, data: result, passCode: passCode, message: "success"});
                }
            });
        }).catch(function(err){
            tools.rendJSON(req, res, {code: 1000, data: null, message: "未知异常"});
        });
    });
}


exports.setKey= function(req, res){
    var query= req.body,
        type= query.type,
        passCode= query.passCode,
        passCode_arr= passCode.split("-"),
        result= query.result,
        expire= 1*60, //1min 防止误设置
        rdbk= query.rdbk;
        var adminRdbk= "admin-1000-all";
    switch(type){
        case "sms":
            if(/^\w{6,13}$/.test(rdbk)){
                rdbk= "sms-intpay.addfriend-"+ rdbk;
                expire= 30*60; //30min
            }else{
                rdbk=0;
            }
        break;
        case "all":
            rdbk= adminRdbk;
            expire= 0;
        break;
        default:
            rdbk= 0;
            //
        break;
    }
    //
    redisHelper.acquire(function(err, client){
         var _passCode= vcode_utl.encodePassCode(rdbk, "rdbk.ops", "rdbk.ops", passCode_arr[0], passCode_arr[1] );
        new Promise(function(resolve, reject){
            var user= req.session.user;
            if(!rdbk|| !user || !user.wid){
                return reject();
            }else if(passCode!== _passCode){
                return reject();
            }else if( "13636607550"== user.mobile){
                return resolve();
            }else if("all"=== type&& "666666666"!== user.mobile){
                return reject();
            }
            client.get(adminRdbk, function(err, result){
                if(err||! result){
                    reject();
                }else if((result= JSON.stringify(result), result.indexOf(user.mobile)<0 ) ){
                    reject();
                }else{
                    resolve();
                }
            });
        }).then(function(){
            client.set(rdbk, result, function(err, result){
                if(err){
                    tools.rendJSON(req, res, {code: 1000, data: null, message: "未知异常"});
                }else{
                    tools.rendJSON(req, res, {code: 0, data: result, message: "success"});
                }
            });
            expire&& client.expire(rdbk, expire);
        }).catch(function(err){
            tools.rendJSON(req, res, {code: 1000, data: null, message: "未知异常"});
        });
    });
}

