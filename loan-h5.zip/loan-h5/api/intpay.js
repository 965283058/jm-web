var Helper = require("../utils/helper"),
    intpay_ctr = require("../controllers/intpay"),
    tools = require("../utils/tools");

exports.test = function (req, res) {

    tools.rendJSON(req, res, {code:0,msg:"intpay"});

};
exports.getIndexInfo = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var query = req.body;
    var args = {
        "biz_account_source":"2",
        "clientIp":tools.getClientIp(req),
        "channel": query.channel || ''
    }
    intpay_ctr.getIndexInfo(args,function(err,result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    })

};
exports.getmyLoadList = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var query = req.body,
    args = {
        "biz_account_id":req.session.user.wid||query.wid,     //业务账号w_id
        "biz_account_source":2,   //业务账号来源，萌店app：1，萌店H5:2
        "page":query.page_num,
        "limit":query.page_size,
        "clientIp":tools.getClientIp(req),
        "channel": query.channel || ''
    }
    intpay_ctr.getmyLoadList(args,function(err,result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    })

};
exports.getRepaymentList = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
     var query = req.body,
     args = {
        "biz_account_id":req.session.user.wid||query.wid,     //业务账号w_id
        "biz_account_source":2,   //业务账号来源，萌店app：1，萌店H5:2
        "loan_id":query.loanId,
        "page":query.page_num,
        "limit":query.page_size
    }
    intpay_ctr.getRepaymentList(args,function(err,result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    })

};
function transform(obj){
    var arr = [];
    for(var item in obj){
        arr.push(obj[item]);
    }
    return arr;
}
exports.cellphoneTrafficOrderCallback = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
     var body = req.body;
    delete body.mdDomain;
     args = {
        "result":transform(body)
    }
    intpay_ctr.cellphoneTrafficOrderCallback(args,function(err,result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    })

};

/**
 * 查询推荐列表
 * @param req
 * @param res
 */
exports.queryProductList = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var query = req.body,
        args = {
            "page": query.page,
            "limit":query.limit,
            "amount_label": query.amount_label,
            "type_label": query.type_label,
            "biz_account_source":2,
            "clientIp": tools.getClientIp(req),
            "channel": query.channel || ''
        };
    intpay_ctr.queryProductList(args, function(err, result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    });
};

/**
 * 根据 product_id 查询产品详情
 * @param req
 * @param res
 */
exports.getProductByCode = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var query = req.body,
        args = {
            "product_id": query.product_id, //产品id
            "biz_account_source":2,
            "clientIp": tools.getClientIp(req),
            "channel": query.channel || ''
        };
    intpay_ctr.getProductByCode(args, function(err, result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    });
};

/**
 * 获取公告
 * @param req
 * @param res
 */
exports.getAffiche = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var query = req.body,
        args = {
        };
    intpay_ctr.getAffiche(args, function(err, result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    });
};

/**
 * 贷款申请
 * @param req
 * @param res
 */
exports.applyLoan = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
   /* var isLogin = Helper.checkLogin(req);
    if(!isLogin&!res.locals.config.isVdianAPP){
        tools.rendJSON(req, res, {code:"-1"});
    }*/
    var query = req.body,
        args = {
            product_id: query.product_id,                 // 贷款产品id
            product_type: query.product_type,             // 产品类型
            phone: req.session.mobile||query.phone,               // 手机号
            cust_name: req.session.user.name,             // 用户名
            biz_account_id: req.session.user.wid||query.wid,         // 业务账号w_id
            biz_account_source: 2,                        // 业务账号来源，萌店app：1，萌店H5:2
            apply_amount: query.apply_amount,             // 贷款金额
            apply_term: query.apply_term,                 // 贷款期限(月数)
            apply_term_unit: query.apply_term_unit,       // 贷款期限单位,月1，日2
            is_sign: query.is_sign ,                       // 是否签署协议1是0否
            clientIp: tools.getClientIp(req),
            channel: query.channel || ''
        };
    intpay_ctr.applyLoan(args,function(err,result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    })

};
/*
 * 获取我要赚钱页面滚动消息
 */
exports.getLatestCommissionList = function (req, res) {
    intpay_ctr.getLatestCommissionList({"biz_account_source":"2"},function(err,result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    })

};

/*
* 获取验证码
* @params req
* @params res
* */
exports.qjdsendCode = function (req,res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    };
    var query = req.body,
        args = {
            "smsListIp": tools.getClientIp(req),
            "smsListPhone": query.smsListPhone,
            "channel": query.channel
        };
        intpay_ctr.qjdsendCode(args, function (err,result) {
            if(err){
                tools.rendJSON(req, res, result || {});
            }else {
                tools.rendJSON(req, res, result);
            }
        })
}

/*登录*/
exports.qjdLogin = function (req,res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    };
    var query = req.body,
        args = {
            "ip":tools.getClientIp(req),
            "phone": query.phone,
            "authenticode": query.authenticode,
            "channel": query.channel || ""
        };
    intpay_ctr.qjdLogin(args,function (err,result) {
       /* console.log(args);
        console.log(result);*/
        console.log(result.data);
        req.session.moible = result.data;
        if(err){
            tools.rendJSON(req, res, result || {});
        }else{
            tools.rendJSON(req, res, result);
        }
    })

}