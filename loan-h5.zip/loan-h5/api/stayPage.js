var Helper = require("../utils/helper"),
    tools = require("../utils/tools");

//分享赚页面停留check打点
exports.check = function (req, res) {
    if (!Helper.isPost(req, res)) {
        return res.end('only POST is accepted');
    }
    var ua = req.headers["user-agent"] + "@HTML5";
    var isWeixin = !!/micromessenger/gi.test(ua),
        isQQ = !!/QQ/gi.test(ua) && !isWeixin;
    var business = req.body;
    if (isQQ) {
        business.open_id = req.session.qq && req.session.qq.openid
    } else if (isWeixin) {
        business.open_id = req.session.wechat && req.session.wechat.openid;
    }
    //
    tools.rendJSON(req, res, {});
}