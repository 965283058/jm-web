/************************************
QQ类
************************************/

var qq = require('../models/qq');
var QQ= new qq();


exports.getAccessTokenByCode= function(args, fn){
    QQ.getAccessTokenByCode(args, function(err, result){
        fn(err, result);
    });
};

exports.getOpenIdByAccessToken= function(args, fn){
    QQ.getOpenIdByAccessToken(args, function(err, result){
        fn(err, result);
    });
};
