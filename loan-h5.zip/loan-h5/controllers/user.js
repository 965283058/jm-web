/************************************
controller User
**************************************/
var User = require('../models/user'),
    Tuan = require('../models/migrate/tuan'),
    events = require('events');


var tuan= new Tuan();


exports.add = function(arg, fn){
    var user = new User();
    user.user_id = arg.user_id;
    user.openid = arg.openid;
    user.yunjie_id= arg.yunjie_id;
    user.mobile = arg.mobile;
    user.clientIp= arg.clientIp;
    user.appIdentifier=arg.appIdentifier;
    // 验证手机是否已经被注册

    new Promise(function(resolve, reject){
        User.checkmobilestatus({
            mobile: arg.mobile,
            open_id_type: arg.open_id_type,
            appIdentifier:arg.appIdentifier
        }, function(err, result) {
            if(err|| !result.data){
                reject(err|| "网络异常，请稍候重试");
            }else if(arg.unionid&& result.data.union_id&& (result.data.union_id!== arg.unionid) ){
                reject("该手机号已经在其他微信号中绑定");
            }else{
                resolve(result.data);
            }
        });
    }).then(function(checkData){
        if(1== checkData.is_register){
            return new Promise(function(resolve, reject){
                 user.getUserByMobile(function(err2, result2){
                    if(err2){
                        reject(err2);
                    }else{
                        resolve(result2);
                    }
                 });
            });
        }else{
            for (var key in arg) {
                user[key] = arg[key];
            }
            //微信中的用户，进行手机号绑定
            if(arg.user_id && (-1 != arg.user_id) ){
               return new Promise(function(resolve, reject){
                     var _args = {
                        user_id: arg.user_id,
                        mobile: arg.mobile,
                        bind_mobile: 1,
                        appIdentifier:arg.appIdentifier
                    }
                    user.modify(_args, function(err, result){
                        if(0 == result.code){
                            resolve({code:0, data: user});
                        }else{
                            reject(err);
                        }
                    });
               });
            }else{
                return new Promise(function(resolve, reject){
                    user.add(function(err, result){
                        if(err){
                            reject(err);
                        }else{
                            // result.data映射为对象，便于和登录接口统一。
                            result.data.isAdd= true;
                            resolve(result);
                            user.userid = result.data.user_id;
                            // exports.changetempinfo(user, function(){
                            //     //
                            // });
                        }
                    });
                });
            }
        }
    }).then(function(result){
        fn(null, result);
    }).catch(function(err){
        fn(err);
    });
   
};


exports.getUserById = function(arg, fn, raw){
    var user = new User();
    user.userid = arg.userid;
    user.getUserById(function(err, result) {
        var data, mobile;
        // 格式化数据
        if (!raw) {
            data = result.data || {};
            mobile = data.mobile || '';
            data.mobile = mobile.replace(/(\d{3})\d{3,4}(\d*)/, "$1****$2");
            data.nick_name = data.nick_name || '暂无';
            data.head_img = data.head_img || '/imgs/w_11.jpg';
        }
        fn(err, result);
    });
}

exports.getUserByOpenid = function(arg, fn){
    var user = new User();
    user.openid = arg.openid;
    user.getUserByOpenid(fn);
}

exports.getUserByMobile = function(arg, fn){
    var user = new User();
    user.mobile = arg.mobile;
    user.getUserByMobile(fn);
}

exports.sendCode = function (arg, fn) {
    var user = new User();
    user.mobile = arg.mobile;
    user.mode = arg.mode;
    user.clientIp=  arg.clientIp;
    user.passCode=  arg.passCode;
    user.tosmsapp=  arg.tosmsapp||'';
    user.appIdentifier=  arg.appIdentifier||'';
    user.sendCode(fn);
};
exports.checkCode = function (arg, fn) {
    var user = new User();
    user.mobile = arg.mobile;
    user.mode = arg.mode;
    user.code = arg.code;
    user.clientIp= arg.clientIp;
    user.appIdentifier=  arg.appIdentifier||'';
    user.checkCode(fn);
}

exports.modify = function (arg, fn) {
    var user = new User();
    // 修改手机号时，须判断手机号是否被注册
    if (arg.mobile) {
        user.mobile = arg.mobile;
        user.checkMobileUnique(function(err, result) {
            if (result.data == 1) { // 已注册
                result.code = 1;
                result.message = "手机号："+ arg.mobile + " 已经被注册！";
                fn(err, result);
            } else { // 未注册
                user.modify(arg, fn);
            }
        });
    } else {
        user.modify(arg, fn);
    }
};

exports.uploadImage = function (arg, fn) {
    var user = new User();
    user.uploadImage(arg, fn);
};

exports.getWXUserInfo = function(args, _fn){
    //兼容user对象
    function fn(err, user){
        user.userid= user.userid|| user.user_id;
        if("object"== typeof user.userid){
            user= user.userid;
        }
        _fn(err, user);
    }
    var tmpUser = {
        _step: 0,
        _wxUser: {ready: false},
        _vdUser: {ready: false},
        _wpUser: {ready: false},
        _newUser: {ready: false},
        _wxErr: null,
        _vdErr: null,
        _wpErr: null,
        _newErr: null
    }
    Object.defineProperties(tmpUser, {
        step: {
            get: function(){
                return this._step;
            },
            set: function(v){
                this._step = v;
            }
        },
        wxUser: {
            get: function(){
                return this._wxUser;
            },
            set: function(v){
                this._wxUser = v;
                this._wxUser.ready = true;
            }
        },
        vdUser: {
            get: function(){
                return this._vdUser;
            },
            set: function(v){
                this._vdUser = v;
                this._vdUser.ready = true;
                if(this._wpUser.ready){
                    this._vdUser.subscribe = this._wpUser.Subscribe||0;
                    fn(this._vdErr, this._vdUser);
                }
            }
        },
        wpUser: {
            get: function(){
                return this._wpUser;
            },
            set: function(v){
                this._wpUser = v;
                this._wpUser.ready = true;
                if(this._vdUser.ready){
                    this._vdUser.subscribe = this._wpUser.Subscribe;
                    fn(this._vdErr, this._vdUser);
                }
                if(this._newUser.ready){
                    this.newUser = this._newUser;
                }
            }
        },
        newUser: {
            get: function(){
                return this._newUser;
            },
            set: function(v){
                this._newUser = v;
                this._newUser.ready = true;
               if(this._wpUser.ready){
                  
                    this._newUser.add(function(err, result){
                       if(0 == result.code){
                            var __user= result.data;
                                __user.userid= __user.userid|| __user.user_id;
                                __user.username= tmpUser._wpUser.Nickname;
                                __user.nick_name= tmpUser._wpUser.Nickname;
                                __user.head_img= tmpUser._wpUser.Headimgurl;
                                __user.subscribe= tmpUser._wpUser.Subscribe;
                            tmpUser._newUser= __user;
                       }
                       //fn(err, user);
                       tmpUser.vdErr = err;
                       tmpUser.vdUser = tmpUser._newUser;
                    });
               }
            }
        }
    });

    var emitter = new events.EventEmitter();
    //oAuth方式获取code后，通过code获取access_token, openid等一系列信息
    User.getWXAccessToken(args, function(err, result){
        if(result.openid){
            tmpUser.step = 1;
            emitter.emit("getWPUserByOpenid", result.openid);
            emitter.emit("getUserByOpenid", result.openid);
        }else{
            fn(err, result);
        }
    });
    //
    emitter.on("getUserByOpenid", function(openid){
        var user = new User();
        user.openid = openid;
        user.yunjie_id = args.yunjie_id;
        user.getUserByOpenid(function(err, result){
            if(err){
                fn(err, result);
            }else{
                if(result.userid){
                    result.openid = result.openid||openid;
                    //fn(null, result);
                    tmpUser.vdErr = err;
                    tmpUser.vdUser = result;
                }else{
                    tmpUser.step = 2;
                    emitter.emit("add", user);
                }
            }
        });
    });
    //
    emitter.on("getWPUserByOpenid", function(openid){
        User.getWPUserByOpenid({openid: openid}, function(err, result){
            if(err){
                tmpUser.wpErr = err;
                tmpUser.wpUser = {};
            }else{
                tmpUser.wpUser = result.Data;
            }
        });
    });
    //通过openid 添加用户
    emitter.on("add", function(user){
        tmpUser.newUser = user;
    });

};


exports.getWXopenId= function(args, fn){
     User.getWXAccessToken(args, function(err, result){
        if(result.openid){

        }else{

        }
        fn(err, result);
    });
}


exports.getWXUserInfoByOpenid = function(args, fn){
    var shop = new Shop({shop_id:9});
    //var emitter = new events.EventEmitter();
    var _args = {
        access_token: null,
        openid: args.openid
    };
    shop.getAccessToken(function(err, result){
        _args.access_token = result;
        User.getWXUserInfoByOpenid(_args, fn);
    });
    
}

exports.getWXUserInfoByOpenid2 = function(args, fn){
    User.getWXUserInfoByOpenid2(args, fn);
}

exports.getWXAccessToken = function(args, fn){
    User.getWXAccessToken(args, function(err, result){
        if(err){
            fn(err, result);
        }else{
            if(result.openid){
                fn(err, result);
            }else{
                fn(err, result);
            }
        }
    });
}

exports.getAccessToken = function(args, fn){
    var emitter = new events.EventEmitter();
    //
    emitter.on("refreshAccessToken", function(args){
        User.refreshAccessToken(args, function(err, result){
            fn(err, result);
            if(err){
                fn(err, result);
            }else{
                User.setAccessToken(result, function(){
                    console.log("refresh success");
                });
            }
        });
    });
    
    User.getAccessToken(args, function(err, result){
        if(err){
            fn(err, result);
        }else{
            var now = new Date();
            var exTime = result.expires_date;
            //过期
            if(exTime<now){
                emitter.emit("refreshAccessToken", result);
            }else{
                fn(err, result);
            }
        }
    });

    
}

exports.getFavoriteList = function (args, fn) {
    User.getFavoriteList(args, function(err, result) {
        var pageInfo = result.data.page_info || {},
            data= [];

        if (args.type == 'shop') {
            data = result.data.datalist || [];
            data = formatFavoriteShopData(data);
        } else {
            data = result.data.data || [];
            data = formatFavoriteGoodsData(data);
        }

        fn(err, {
            code: result.code,
            message: result.message,
            data: data,
            page: pageInfo.current_page || 0,
            total: pageInfo.total_num || result.data.total_results||0
        });
    });
};


function formatFavoriteGoodsData(originalData) {
    var data = [],
        goods = null,
        PATH_GOODS_DETAIL2,
        iswp= false, //供货商商品
        vid= 0,
        aid= 0,
        gid= 0;
    for (var i = 0, len = originalData.length; i < len; i++) {
        goods = originalData[i].goods_detail;
        iswp= 1== originalData[i].is_direct_collection_goods; //没有分享人信息即 vid＝0
        if(goods.wk_itemid){
            //上架商品
            aid= 0
            vid= goods.shop_id|| originalData[i].shop_id;
            gid= originalData[i].goods_id;
        }else{
            //供货商商品
            var aid_gid= originalData[i].goods_id.split("_");
            aid= aid_gid[0];
            gid= aid_gid.pop();
            if(originalData[i].shop_id== aid){
                vid= 0;
            }else{
                vid= originalData[i].shop_id;
            }
        }
        data.push({
            shopId: vid,
            aid: aid,
            gid: gid,
            url: "/buyer/goods/detail",
            iswp: iswp,
            img: goods.index_image,
            doubleEleven:originalData[i].goods_detail.doubleEleven,
            title: goods.title,
            is_lose:originalData[i].goods_detail.is_lose,
            price: parseFloat(goods.sale_price).toFixed(2),
            haitaoTag: goods_ctr.createHaitaoTag(goods),
            gtag: goods_ctr.createGoodsTag(goods),
            sellType: parseInt(goods.sellType)||1,
            activityTagOnGoodsImage: goods.activityTagOnGoodsImage
        });
    }
    return data;
}



//合并临时用户身份
exports.changetempinfo = function(args, fn){

    var _args = {
        user_id: args.userid||args.user_id,
        openid: args.openid,
        yunjie_id: args.yunjie_id
    };
    User.changetempinfo(_args, function(err, result){
        //console.log("同步结果" + JSON.stringify(result) );
    });
}

//
exports.getWPUserByOpenid = function(args, fn){
    var _args = {
        openid: args.openid
    };
    User.getWPUserByOpenid(_args, function(err, result){
        fn(err, result);
    });
}

//查验用户是否已注册并返回验证码 请使用 checkMobile2
exports.checkMobile = function(args, fn){
    User.checkMobile(args, function(err, result){
        fn(err, result);
    });
}

//查验用户是否已注册并返回验证码
exports.checkMobile2 = function(args, fn){
    User.checkMobile2(args, function(err, result){
        fn(err, result);
    });
}

//请使用 register2
exports.loginAndRegister = function(args, fn){
    User.loginAndRegister(args, function(err, result){
        fn(err, result);
    });
}

//
exports.register2 = function(args, fn){
    User.register2(args, function(err, result){
        fn(err, result);
    });
}

//获取验证码图片
exports.getCaptcha = function(args, fn){
    User.getCaptcha(args, function(err, result){
        fn(err, result);
    });
}


exports.getShopInfoById= function(args, fn){
    User.getShopInfoById(args, function(err, result){
        fn(err, result);
    });
}

exports.v3Login= function(args, fn){
    User.v3Login(args, function(err, result){
        fn(err, result);
    });
}

exports.wechatQrCreate= function(args){
    return new Promise(function(resolve, reject){
        User.wechatQrCreate(args, function(err, result){
            if(err){
                reject(err);
            }else{
                resolve(result);
            }
        });
    });
}

exports.loginMsg= function(args, fn){
    tuan.loginMsg(args, fn);
}