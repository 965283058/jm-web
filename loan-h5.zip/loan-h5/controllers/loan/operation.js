var redisHelper = require("../../models/redisHelper"),
    Image = require("../../models/migrate/image"),
    Helper = require("../../utils/helper"),
	config = require("../../utils/config"),
    co = require('co'),
    OSS = require('ali-oss')

//用于给运营配置的页面
exports.config = function (req, res) {
	if (config.preview) {
    	redisHelper.acquire(function(err, client){
        	client.get("operation-data-remark", function(err, result){
            	res.render('loan/operation/config', {
            		title: '运营配置',
            		pageName: 'operationConfig',
            		remark: result
            	});
        	});
    	});
    } else {
    	res.render("404", {
            title: "error",
            pageName: "error",
            error: "不可访问"
        });
    }
}

exports.appVenueEntrance = function (req, res) {
    var isLogin = Helper.checkLogin(req);
    if (isLogin) {
        var allow = false;
        var mobiles = [18521762192,13636607550,15601951900,15900402956,15900402956,13917538244,13818511151,13524554145,15821348751,15921448954];
        for (var i = 0; i < mobiles.length; i++) {
            if (req.session.user.mobile == mobiles[i]) {
                allow = true;
                break;
            }
        }
        if (allow) {
             res.render('loan/operation/appVenueEntrance', {
                title: 'APP内嵌会场入口配置',
                pageName: 'operationAppVenueEntrance'
            });
        } else { 
           res.end('无权操作！')
        }
    } else {
        res.redirect("/buyer/user/login?referrer="+ encodeURIComponent(req.originalUrl) );
    }
}

exports.uploadImage = function (req, res) {
    var isLogin = Helper.checkLogin(req);
    if (isLogin) {
        var allow = false;
        var mobiles = [18521762192,13636607550,15601951900,15900402956,15900402956,13917538244,13818511151,13524554145,15821348751,15921448954];
        for (var i = 0; i < mobiles.length; i++) {
            if (req.session.user.mobile == mobiles[i]) {
                allow = true;
                break;
            }
        }
        if (allow) {
            var method = req.method;
            switch (method) {
                case "GET":
                    GET();
                    break;
                case "POST":
                    POST();
                break;
                default:
                    GET();
            }
        } else {
            res.end('无权操作！');
        }
    } else {
        res.redirect("/buyer/user/login");
    }

    function GET () {
        res.end('无效请求');
    }

    function POST () {
        var img = new Image();
        img.upload(req, function (err, result) {
            if (err) {
                res.end(err);
            } else {
                if (result.code == 0) {
                    uploadToOSS(result.data);
                    redisHelper.acquire(function(err, client){
                        var version = new Date().getTime();
                        client.set("app-venue-entrance", version);
                    });
                }
                var headers = {
                    'Content-Type': 'text/html',
                    'charset': 'utf-8'
                };
                res.writeHead(200, headers);
                res.end(result.message);    
            }           
        }); 
    }
    //将图片上传至OSS
    function uploadToOSS (data) {
        var client = new OSS(config.ossConfig);
        co(function* () {
            var key = 'activity/2016-1111-venue/appVenueEntrance-'+data.seq;
            var result = yield client.put(key, data.file);
        }).catch(function (err) {
            console.log(err);
        });
    }
}