var Helper = require("../../utils/helper");
function getClientIp(req) {
    var ipAddress;
    var forwardedIpsStr = req.header('x-forwarded-for');
    if (forwardedIpsStr) {
        var forwardedIps = forwardedIpsStr.split(',');
        ipAddress = forwardedIps[0];
    }
    if (!ipAddress) {
        ipAddress = req.connection.remoteAddress;
    }
    return ipAddress;
};
/*趣借了 首页*/
exports.index = function (req, res) {    
    // var isLogin = Helper.checkLogin(req);
    // if(!isLogin&!res.locals.config.isVdianAPP){
    //     res.redirect("/loan/intpay/login?referrer="+ encodeURIComponent(req.originalUrl));
    // }
    var channel = req.query.channel || req.session.channel || "";
    if(channel != ""){
        req.session.channel = channel;
    }
    var clientIp = getClientIp(req);
    res.render("loan/intpay/index", {
        title: "趣借了",
        pageName: "intpayIndex",
        channel:channel,
        clientIp: clientIp
    });
}

/*趣借了  产品说明*/
exports.productDetails = function (req, res) {
    var product_id=req.query.product_id;
    var isPLogin = req.session.moible || ""
    /*if(isPLogin != ""){
        res.redirect("/");
    }*/
   
    var channel = req.query.channel || req.session.channel || "";
    if(channel != ""){
        req.session.channel = channel;
    }
    var clientIp = getClientIp(req)
    res.render("loan/intpay/productDetails", {
        title: "产品详情",
        pageName: "intpayProductDetails",
        product_id:product_id,
        channel:channel,
        clientIp: clientIp,
        isPLogin: isPLogin
    });
}
/*趣借了   推荐产品*/
exports.recommendList = function (req, res) {
    var money=req.query.money;
    var term=req.query.term;
    //  var isLogin = Helper.checkLogin(req);
    // if(!isLogin&!res.locals.config.isVdianAPP){
    //     res.redirect("/loan/intpay/login?referrer="+ encodeURIComponent(req.originalUrl));
    // }
    res.render("loan/intpay/recommendList", {
        title: "推荐产品",
        pageName: "intpayRecommendList",
        money:money,
        term:term
    });
}
/*趣借了   新手指南*/
exports.noviceGuide = function (req, res) {
    res.render("loan/intpay/noviceGuide", {
        title: "新手指南",
        pageName: "intpayNoviceGuide"
    });
}
/*趣借了  声明*/
exports.declaration = function (req, res) {
    res.render("loan/intpay/declaration", {
        title: "声明",
        pageName: "intpayDeclaration"
    });
}
/*趣借了  公告*/
exports.announcement = function (req, res) {
    res.render("loan/intpay/announcement", {
        title: "公告",
        pageName: "announcement"
    });
}
/*趣借了  还款信息*/
exports.repaymentList = function (req, res) {
    var isLogin = Helper.checkLogin(req);
    if(!isLogin&!res.locals.config.isVdianAPP){
        res.redirect("/loan/intpay/login?referrer="+ encodeURIComponent(req.originalUrl));
    }
    var _loanId=  req.query.loanId;
    res.render("loan/intpay/repaymentList", {
        title: "还款信息",
        pageName: "repaymentList",
        loanId:_loanId
    });
}
/*/!*趣借了  登录*!/
exports.login = function (req, res) {
    var referrer=req.query.referrer||"/loan/intpay/index";
    var isLogin = Helper.checkLogin(req);
    if(isLogin){
        res.redirect("./index");
    }
    res.render("loan/intpay/login", {
        title: "登录",
        pageName: "intpayLogin",
        referrer:referrer
    });
}*/

/*趣借了 搜索*/
exports.loanSearch = function (req,res) {
    var money=req.query.money,
        term=req.query.term,
        type_label = req.query.type_label || 0,
        amount_label = req.query.amount_label || 0,
        amount_label_name = req.query.amount_label_name || '';
    var channel = req.query.channel || req.session.channel || "";
    if(channel != ""){
        req.session.channel = channel;
    }
    var clientIp = getClientIp(req)
    res.render("loan/intpay/loanSearch",{
        title: amount_label_name?amount_label_name:"贷款搜索",
        pageName: "intpayLoanSearch",
        money:money,
        term:term,
        type_label:type_label,
        amount_label:amount_label,
        channel:channel,
        clientIp: clientIp
    })
}
/*趣借了 我的贷款*/
exports.myLoan = function (req,res) {
   /* var isLogin = Helper.checkLogin(req);
    if(!isLogin&!res.locals.config.isVdianAPP){
        res.redirect("/loan/intpay/login?referrer="+ encodeURIComponent(req.originalUrl));
    }*/
    res.render("loan/intpay/myLoan",{
        title: "我的贷款",
        pageName: "intpayMyLoan"
    })
}





