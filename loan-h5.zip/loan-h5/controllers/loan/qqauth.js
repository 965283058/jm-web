var QQ_util= require("../../utils/QQ"),
    config = require('../../utils/config'),
    qq_ctr = require('../qq');//用于红包的QQ登录和获取accessToken和openId
/**
    qq授权回调页面，返回code 参数
    a)统一跳转地址 /loan/qqauth?qurl=ORIGINALURL&code=CODE
    b)code -> token -> openid -> session.qq
    c)重定向到 ORIGINALURL
*/
exports.index = function (req, res) {
    var query= req.query,
        code= query.code,
        qurl= query.qurl,
        state= "",
        redirect_uri = encodeURIComponent(QQ_util.getRedirectUrl(req, res, null, qurl) );
    if(!qurl){
        return res.end("--N/A--");
    }
    //授权回来的页面
    var _tokenArgs={
        client_id: config.walletQQ.appId,
        client_secret: config.walletQQ.appKey,
        code: code,
        redirect_uri: redirect_uri
    };
    qq_ctr.getAccessTokenByCode(_tokenArgs, function(err, json){
        req.session.qq= {
            openid: 0,
            t: +new Date()
        };
        if(!json.error){
            var _openIdArgs= {
                access_token: json.access_token
            };
            qq_ctr.getOpenIdByAccessToken(_openIdArgs,function(err2, json){
                if(!json.error){
                    req.session.qq.openid= json.openid
                }
                req.session.save();
                return res.redirect(qurl);
            });
        }else{
            req.session.save();
            return res.redirect(qurl);
        }
    });
};