
/************************************
controller Location
************************************/
var Location = require('../models/location');

/************************************

************************************/
exports.geocoder = function(args, fn){
	var location = new Location(args);
	location.geocoder(function(err, result){
        var addressComponent = result.address_component;
		location = new Location({
			nation: result.ad_info ? result.ad_info.nation : '',
			province: result.ad_info ? result.ad_info.province : '',
			city: result.ad_info ? result.ad_info.city : '',
			district: result.ad_info ? result.ad_info.district : '',
            address: addressComponent ? (addressComponent.street + addressComponent.street_number) : result.address
		});
		
		delete location.key;
		fn(err, {code:0, data:location, message:"success"});
	});
}