/************************************
controller WebIm
**************************************/
var WebIm = require('../models/webIm');


//获取环信公用密码
exports.getPubKey = function(fn){
	var webim = new WebIm();
    webim.getPubKey(function(err, result){
        fn(err, result);
    });
}

//获取用户信息，如果不存在则注册用户
exports.registerGetUserEx = function(args, fn){
	var webim = new WebIm();
	webim.registerGetUserEx(args, function(err, result){
		fn(err, result);
	});
}
//获取用户信息，如果不存在则注册临时用户
exports.registerGetTempUserEx = function(args, fn){
	var webim = new WebIm();
	webim.registerGetTempUserEx(args, function(err, result){
		fn(err, result);
	});
}
//根据业务id获取用户信息
exports.getUserInfoFromBiz = function(args, fn){
	var webim = new WebIm();
	webim.getUserInfoFromBiz(args, function(err, result){
		fn(err, result);
	});
}
//添加临时会话
exports.addTempChat = function(args, fn){
	var webim = new WebIm();
	webim.addTempChat(args, function(err, result){
		fn(err, result);
	});
}
//上传图片
exports.uploadImage = function(args, fn){
	var webim = new WebIm();
	webim.uploadImage(args, function(err, result){
		fn(err, result);
	});
}
//获取开场语
exports.getStartSentence = function(args, fn){
	var webim = new WebIm();
	webim.getStartSentence(args, function(err, result){
		fn(err, result);
	});
}
//获取供应商imucId，此接口会自动判断供货商PC在线还是手机在线
exports.getSupplier = function (args, fn) {
	var webim = new WebIm();
	webim.getSupplier(args, function (err, result) {
		fn(err, result);
	});
}

exports.applyFriend= function(args, fn){
	var webim = new WebIm();
	webim.applyFriend(args, function(err, result){
		fn(err, result);
	});
};

exports.addFriendWithShopId= function(args, fn){
	var webim = new WebIm();
	webim.addFriendWithShopId(args, function(err, result){
		fn(err, result);
	});	
};

exports.getGroup= function(args, fn){
	var webim = new WebIm();
	webim.getGroup(args, function(err, result){
		fn(err, result);
	});
};

exports.confirmAddFriendWithShopId= function(args, fn){
	var webim = new WebIm();
	webim.confirmAddFriendWithShopId(args, function(err, result){
		fn(err, result);
	});
};

exports.requestCusService = function (args, fn) {
	var webim = new WebIm();
	webim.requestCusService(args, function (err, result) {
		fn(err, result);
	});
}

exports.getImucIdsByMerchantId = function (args, fn) {
	var webim = new WebIm();
	webim.getImucIdsByMerchantId(args, function (err, result) {
		fn(err, result);
	});
}

exports.getLineQueueStatus = function (args, fn) {
	var webim = new WebIm();
	webim.getLineQueueStatus(args, function (err, result) {
		fn(err, result);
	});
}

exports.getTransferStatus = function (args, fn) {
	var webim = new WebIm();
	webim.getTransferStatus(args, function (err, result) {
		fn(err, result);
	});
}