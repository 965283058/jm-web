var LamaVote = require('../models/lamavote');


exports.getVoteList= function(args, fn){
	LamaVote.getVoteList(args, function(err, result){
		fn(err, result);
	});
};

exports.getVoteAdd= function(args, fn){
	LamaVote.getVoteAdd(args, function(err, result){
		fn(err, result);
	});
};
exports.getCheckVote= function(args, fn){
	LamaVote.getCheckVote(args, function(err, result){
		fn(err, result);
	});
};
