/************************************
controller User
**************************************/
var Admin = require('../models/admin'),
    events = require('events');

/************************************

************************************/

exports.setSwthConfig= function(cfg, fn){
	Admin.setSwthConfig(cfg, function(err, result){
		fn(err, result);
	});
}

exports.getSwthConfig= function(cfg, fn){
	Admin.getSwthConfig(cfg, function(err, result){
		fn(err, result);
	});
}

exports.setVal= function(cfg, fn){
	Admin.setVal(cfg, function(err, result){
		fn(err, result);
	});
}

exports.getVal= function(cfg, fn){
	Admin.getVal(cfg, function(err, result){
		fn(err, result);
	});
}