/************************************
 controller intpay
 **************************************/
var Intpay = require('../models/intpay'),
    async = require("async");


exports.getIndexInfo = function(args, fn){
    Intpay.getIndexInfo(args, function(err, result){
        fn(err, result);
    });
}
exports.getmyLoadList = function(args, fn){
    Intpay.getmyLoadList(args, function(err, result){
        fn(err, result);
    });
}
exports.getRepaymentList = function(args, fn){
    Intpay.getRepaymentList(args, function(err, result){
        fn(err, result);
    });
}
exports.cellphoneTrafficOrderCallback = function(args, fn){
    Intpay.cellphoneTrafficOrderCallback(args, function(err, result){
        fn(err, result);
    });
}
exports.queryProductList = function(args, fn){
    Intpay.queryProductList(args, function(err, result){
        fn(err, result);
    });
}
exports.getProductByCode = function(args, fn){
    Intpay.getProductByCode(args, function(err, result){
        fn(err, result);
    });
}
exports.getAffiche = function(args, fn){
    intpay.getAffiche(args, function(err, result){
        fn(err, result);
    });
}
exports.applyLoan = function(args, fn){
    Intpay.applyLoan(args, function(err, result){
        fn(err, result);
    });
}
exports.getLatestCommissionList = function(args, fn){
    Intpay.getLatestCommissionList(args, function(err, result){
        fn(err, result);
    });
}
exports.integralDraw = function (args,fn) {
    Intpay.integralDraw(args,function (err,result) {
        fn(err,result)
    })
};
exports.qjdLogin = function (args,fn) {
    Intpay.qjdLogin(args,function (err,result) {
        fn(err,result)
    })
};
exports.qjdsendCode = function (args,fn) {
    Intpay.qjdsendCode(args,function (err,result) {
        fn(err,result)
    })
}
