"use strict";
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var partials = require('express-partials');
var session = require('express-session');
var mcStore = require('./utils/connect-ocs')(session); 
var config = require('./utils/config'); 
var flash = require('connect-flash');
var tools = require("./utils/tools");
var crypto = require('crypto');
var supUrl = require("./utils/supUrl");
//
var routes = require('./routes/index');
var api = require("./routes/api");
var util = require('./routes/util');
var vd = require('./routes/vd');
var admin = require('./routes/admin');
var guid= require('./utils/guid');
var logger = require("./utils/logger");
var mduc = require('./utils/mduc');
var domain = require('./utils/domain');
var debug = require('debug')('app-start');
var atenv = "";
//新模块（可迁移）
var migrate_index = require("./routes/migrate/index");
var migrate_api = require("./routes/migrate/api");

var ips = tools.getServerIp();
atenv = [parseInt(config.env.slice(0, 2), 32), config.port.toString().slice(-2), ips.internal.match(/\w+\.\w+$/) ].join(".");
var app = express();
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(partials());

app.use(logger.useLog("connect"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public'), {
    etag: true,
    maxAge: 1000*60*60,
    setHeaders: function (res, path, stat){
        res.set({
            "x-powered-by": "Qufu",
            "At-e": atenv
        });
    }
}));
app.use(flash());
app.use(function(req, res, next){
    //for migrate
    function encodePassCode(passCode){
        var content = passCode + "h5$s7df9sdf9ss9r8gs#{}|:~$",
            md5 = crypto.createHash('md5');
        return (md5.update(content), md5.digest('hex')); 
    };
    //
    let key= "cm.sid",
        domain= "",
        domain2= "";
    if(req.headers["wx-app"]){
        let wxToken= req.headers["wx-token"];
        let wxCode= wxToken.slice(0, 10);
        let sid= wxToken.substring(10);
        //
        res.cookie= function(_key, _val, _cookieData){
            res.set({
                "wx-token": req.cookies["cm.sid"]
            });
        }
    }else if(/intpayment/i.test(req.hostname) ){
        key= "intpayment.sid";
        domain= "";
        req.body.mdDomain= "http://"+ req.hostname; //趣借了分享域名
    }
    //for migrate
    let cmsid= req.cookies[key];
    req.cookies["cur.sid"]= encodePassCode(cmsid + "sid").slice(0, 10)+ encodeURIComponent(cmsid);
    //
    session({
        key: key,
        secret: config.db.COOKIE_SECRET,
        cookie: {
            httpOnly: true,
            //secure: true,
            domain: domain,
            //path: "/buyer/",
            maxAge: new Date(Date.now()+7*24*60*60*1000 )
        },
        store: new mcStore({
            prefix:"cm_sessions_"
            //PORT: config.db.PORT,
            //HOST: config.db.HOST,
            //USERNAME: config.db.USERNAME,
            //PASSWORD: config.db.PASSWORD
        }),
        resave: true,
        saveUninitialized: true
    })(req, res, next);
});
app.listen(config.port);
console.log('[%s] [port:%s] [env:%s] start', new Date(), config.port, config.env);

app.use(function(req, res, next){
    var ua = req.headers["user-agent"] + ";@HTML5";
    res.locals.config = {
        version:Math.random(),//+Math.random(),
        shopInfo: {},
        ua: ua,
        platform: ua.match(/iphone|ipad|ipod|android|windows|linux|unix|mac|HTML5/i).toString(),
        isWeixin: !!/micromessenger/gi.test(ua),
        isVdianAPP: !!/vdian|vapp|mdapp/gi.test(ua),
        isMobile: !!/mobile/gi.test(ua),
        wxConfig: null,
        url: [req.protocol, "://", req.headers.host, req.originalUrl].join(""),
        baseUrl:[req.protocol, "://", req.headers.host].join(""),
        widget: {
            home_menu:{
                btn_home: true,
                btn_partner: true,
                btn_shopcart: true,
                btn_center: true
            }
        },
        clientIp: tools.getClientIp(req),
        env: config.env,
        qcAdmin: config.walletQQ.qcAdmin,
        vapp: {},
        venv: {},
        mdDomain: req.body.mdDomain||config.mdDomain2_1,
        curSid: req.cookies["cur.sid"], //for migrate
        domain2: config.domain2
    };
    res.set({
        "x-powered-by": "Qujie",
        "At-e": atenv
    });

    // 页面初始化提示信息，用于显示后端提示信息。
    res.locals.message = '';
    /**
     * 设置提示信息到session中
     * @param value 信息值(必填)
     * @param key {String} 信息键(可选)，默认以请求url的pathname去斜杠为下划线 + _message后缀。例如：/buyer/user/login --> _buyer_user_login_message。
     *            如果手动输入pathname也会按上述规则解析。
     */
    req.setMessage = function (value, key) {
        if (value) {
            key = key || req._parsedUrl.pathname;
            key = key.split('/').join('_') + '_message';
            req.session.message[key] = value;
        }
    };
    /**
     * 读取提示信息到res.locals的message属性中
     * @param key {String} 信息键(可选)，@see req.setMessage
     */
    req.getMessage = function (key) {
        key = key || req._parsedUrl.pathname;
        key = key.split('/').join('_') + '_message';
        var message = req.session.message[key] || '';
        if (message) {
            delete req.session.message[key];
        }
        res.locals.message = message;
    };
    //初始化默认user信息，生成uuid
    if(req.session.user){
        //
    }else{
        req.session.user= {
            id: -1,
            yunjie_id: "yunjie-"+ guid()
        };
    }
    //
    if(res.locals.config.isVdianAPP){
        if( (!parseInt(res.locals.config.vapp.wid)&& parseInt(req.session.user.wid)&& !/\/api/.test(req.path) )
            || (parseInt(res.locals.config.vapp.wid)&& parseInt(res.locals.config.vapp.wid)!= parseInt(req.session.user.wid) )
         ){
            //清掉所有老用户信息
            req.session.user= {
                id: -1,
                yunjie_id: "yunjie-"+ guid()
            };
        }
    }
    //
    if(req.session.wechat){
        req.session.wechat.list= req.session.wechat.list||{}; //后期可以把这个兼容去掉
        req.session.wechat.current= req.session.wechat.current||{};
    }else{
        req.session.wechat= {
            openid:     "",
            current:    {},
            list:       {}
        };
    }
    //client
    if(req.session.client&& req.session.client.guid){

    }else{
        req.session.client= {guid: guid()};
    }
    // 某些变量仅暂时可用, 不可扩展新的字段到req.session
    ["shopInfo", "urlInfo", "sendCode", "activity", "indiana", "webim", "qq", "admin", "message", "user2"].forEach(function(v){
        if( !(v in req.session) ){
            req.session[v]= {};
        }
    });
   /* Object.seal(req.session);*/
    next();
});

app.use(domain.checkHost, mduc.init() );


app.use(routes);
app.use(util);
//app.use(loan);
//新模块路由
app.use(migrate_api);
app.use(migrate_index);

//
if(('development'=== config.env)|| (1=== process.env.VD_ADMIN) ){
    app.use(admin);
}
app.use(function(req, res){
     res.render('404', {
        pageName: "err",
        title: "错误",
        message: 404,
        error: 404
     });
});
//development error handler
//will print stacktrace
if ('development'=== config.env|| "pl"=== config.env) {
    app.use(function (err, req, res, next) {
        logger.error(err.stack);
        res.render('404', {
            pageName: "err",
            title: "错误",
            message: err,
            error: err
        });
    });
} else {
    //production error handler
    //no stacktraces leaked to user
    app.use(function (err, req, res, next) {
        logger.error(err.stack);
        res.render('404', {
            pageName: "err",
            title: "错误",
            message: null,
            error: null
        });
    });
}
//
process.on('uncaughtException', function (err) {
    logger.error("global exception \n"+ err.stack);
});

module.exports = app;