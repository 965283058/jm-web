
注意事项(未区分主次和类别)
1) 理论上所有view页面链接都需要调用 supUrl方法，以添加公共的参数，如下：
	//javascript 片段
	APP.urls = {
		list_page: '<%- vdUrl.parse("/buyer/goods/list").toString({cat_id: "{cat_id}", cat_name: "{cat_name}"}) %>'
	};
	//html 片段
	<a id="btn_partner" href="<%= 'partnerInvite' == pageName?'javascript:;': vdUrl.parse('/vd/activity/partnerInvite').toString({vid: shopInfo.shop_id, pop_id: activeId, channelInfo: "blank", encrypt: encrypt}) %>"><i>&nbsp;</i><label>成为合伙人</label></a>
2) 所有路由均需调用统计模块，参考/routes/luckyRoller-cmd.js catchRender 方法
3) 所有css sprite 图片均需保留相应的psd源文件，方便后期维护修改，psd源文件所在目录为 %svnpath%/cloudMall/doc
4) 非特殊需求，尽量不要加js库到/public/lib_cmd,也不支持随意应用第三方js文件，一切以原生为主
5) 所有方法均需注释
6) error的传递过程 proxy->models->controllers->routes 视情况，尽量在routes中处理
7) 编写公共模块、文件、方法要做到命名规范，具有普遍的适用性和可扩展性，并做到最小依赖
8) 变动以下文件需慎重
	a) /utils/*
	b) /luckyRoller-cmd.js
	c) /views/header.ejs, /views/widget_footer.ejs
	d) /public/lib_cmd/*, /public/js_cmd/main-cmd.js/public/js_cmd/main-cmd.js， /public/js_cmd/touchAPP-cmd.js /public/css/common.css, /pubic/css/reset.css
	e)
	f)
9) css 命名 AAA-BBB中划线链接多单词，不允许属性值写在同一行
10) js 文件命名 AAA_BBB
11) 新建分支，命名规范 v-x.y.z-name, x、y、z表示版本号，name可以使用当前分支的特性，如下：
		%svnpath%/cloudMall/branches/v-1.0.0-zhuanchang, %svnpath%/cloudMall/tags/v-1.0.0-zhuanchang
12) 不允trunk上开发，不允许tags下修改，提交前先update，每天做到同步trunk到当前开发的分支
13) express全局变量 req.session.user需慎重处理
14) 页面常用的js插件：lib_cmd/iTemplate-cmd, lib_cmd/myDialog（所有弹窗都要使用文件提供的方案）, lib_cmd/swipe, lib_cmd/iScroll, lib_cmd
15)注意页面布局，参考/views/buyer/user/center.ejs
	a) 主体结构是 data-role="container", 然后分三个区域 data-role="header"， data-role="body"， data-role="footer"
	b)
	<body>
		<div data-role="container" class="body <%= pageName %>">
	    	<header data-role="header">
	    		...
	    	</header>
	    	<section data-role="body" class="section-body">
	    		...
	    	</section>
	    	<div data-role="footer">
	    		...
	    	</div>
	    </div>
	</body>
***************************************************
APP 3.0.0
***************************************************
开发人员
	intpay
	alex.xu
	rock.zhang
新增功能
	APP专场页面
	商品详情UI，及参加活动
	强账号
	海淘商品
	维权
注意事项
	a) 代理模块
		新增 APILEVEL，以判断接口的重要性，设置相应的超时时间
	b)

***************************************************
TODO
***************************************************
	日志服务器
	routes模块梳理
	静态文件cdn
	svn向git迁移