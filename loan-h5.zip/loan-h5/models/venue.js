var redisHelper = require("./redisHelper");
function Venue() {}
Venue.getCouponTimes = function (args, fn) {
    var initData = [
        
    ].toString();
    redisHelper.acquire(function(err, client){
        client.get('venue-couponTimes-'+args.id, function (err, result) {
            if (result == null) {
                client.set('venue-couponTimes-'+args.id, initData);
            }
            var res = result||initData;
            fn(err, res.split(','));
        })
    })
}

Venue.setCouponTimes = function (args, fn) {
    redisHelper.acquire(function(err, client){
        client.set('venue-couponTimes-'+args.id, args.times, function (err, result) {
            fn(err, result);
        })
    })
}

module.exports = Venue;