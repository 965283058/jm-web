/************************************
QQ类
************************************/
var proxy = require("../utils/proxy"),
	config = require('../utils/config'),
	querystring = require("querystring");

function qq(){

}
qq.prototype = {
	getAccessTokenByCode: function(args, fn){
		var _args = {
	            grant_type: args.grant_type || '1',
	            client_id: args.client_id || config.walletQQ.appId, 								//APP ID
	            client_secret: args.client_secret || config.walletQQ.appKey, 	//APP KEY
	            code: args.code || '',
	            redirect_uri: args.redirect_uri || ''
	        },
	        _param=getParamByJson(_args);

		proxy.invoke({
            data:{},
            protocol:"https",
            host:"graph.qq.com",
            port:443,
            type:'jsonp',
            path:"/oauth2.0/token?"+_param,
            method:"GET"
        }, function(err, result){
        	fn(err, callbackParamProcessor(result));
		});
	},
	//获取用户open id信息
	getOpenIdByAccessToken: function(args,fn){
		var _args= {
				access_token: args.access_token || ''
			},
	        _param=getParamByJson(_args);

		proxy.invoke({
            data:{},
            protocol:"https",
            host:"graph.qq.com",
            port:443,
            type:'jsonp',
            path:"/oauth2.0/me?"+_param,
            method:"GET"
        }, function(err, result){
        	fn(err, callbackParamProcessor(result));
		});
	}
}

//拼接链接参数
function getParamByJson(json){
	if(!json) return '';
	var _paramArr=[];
	for(var key in json)
		_paramArr.push(key+'='+json[key]);
	return _paramArr.join('&');
}

//返回值处理
function callbackParamProcessor(param){
	if(/^access_token/i.test(param)){
		return querystring.parse(param);
	}else{
		return JSON.parse((param.match(/{.+}/g))[0]);
	}
}

module.exports = qq;