/************************************
环信类
************************************/
var proxy = require("../utils/proxy"),
    config = require("../utils/config");

function WebIm(){
	
}

WebIm.prototype = {
	getPubKey: function(fn){
        proxy.invoke({
            host: config.im.host,
            port: config.im.port,
            data:{
            
            },
            contentType: "application/json;charset=UTF-8",
            path:"/imuc-api/user/getPubKey",
            method:"POST"
        }, function(err, result){
            fn(err, result);
        });
    },
    registerGetUserEx: function(args, fn){
        proxy.invoke({
            host: config.im.host,
            port: config.im.port,
            data: args,
            contentType: "application/json;charset=UTF-8",
            path:"/imuc-api/user/registerGetUserEx",
            method:"POST"
        }, function(err, result){
            fn(err, result);
        });
    },
    registerGetTempUserEx: function(args, fn){
        proxy.invoke({
            host: config.im.host,
            port: config.im.port,
            data: args,
            contentType: "application/json;charset=UTF-8",
            path:"/imuc-api/user/registerGetTempUserEx",
            method:"POST"
        }, function(err, result){
            fn(err, result);
        });
    },
    getUserInfoFromBiz: function(args, fn){
        proxy.invoke({
            host: config.im.host,
            port: config.im.port,
            data: args,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-api/user/getUserInfoFromBiz",
            method: "POST"
        }, function(err, result){
            fn(err, result);
        });
    },
    addTempChat: function(args, fn){
        proxy.invoke({
            host: config.im.host,
            port: config.im.port,
            data: args,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-api/user/addTempChat",
            method: "POST"
        }, function(err, result){
            fn(err, result);
        });
    },
    uploadImage: function(args, fn){
        proxy.invoke({
            data: args,
            contentType: "application/json;charset=UTF-8",
            path: "/uploadimage/base64UploadImage",
            method: "POST"
        }, function (err, result) {
            fn(err, result);
        });
    },
    getStartSentence: function(args, fn){
        proxy.invoke({
            host: config.im.host,
            port: config.im.port,
            data: args,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-api/user/getStartSentence",
            method: "POST"
        }, function(err, result){
            fn(err, result);
        });
    },
    getSupplier: function (args, fn) {
        proxy.invoke({
            host: config.im.host,
            port: config.im.port,
            data: args,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-api/user/registerGetSupplerCusService",
            method: "POST"
        }, function(err, result){
            fn(err, result);
        });
    },
	addFriendWithShopId:function(args,fn){
        proxy.invoke({
            data: {
                submitShopId:args.submitShopId,
                targetShopId:args.targetShopId,
                relationType:0
            },
            host: config.im.host,
            port: config.im.port,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-api/user/addFriendWithShopId",
            method: "POST"
        }, function (err, result) {
            fn(err, result);
        });
    },
    applyFriend:function(args,fn){
        proxy.invoke({
            data: {
                applyShopId:args.applyShopId,
                targetPhone:args.targetPhone,
                relationType:0
            },
            host: config.im.host,
            port: config.im.port,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-api/user/applyFriend",
            method: "POST"
        }, function (err, result) {
            fn(err, result);

        });
    },
    getGroup:function(args,fn){
        proxy.invoke({
            data: {
              groupId:args.groupId,
              submitId:args.submitId     
            },
            host: config.im.host,
            port: config.im.port,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-api/imucGroup/getGroup",
            method: "POST"
        }, function (err, result) {
            fn(err, result);
        });
    },
    confirmAddFriendWithShopId:function(args,fn){
        proxy.invoke({
            data: {
              applyShopId:args.applyShopId,
              submitshopId:args.submitshopId,
              relationType:0,
              isAgree:args.isAgree     
            },
            host: config.im.host,
            port: config.im.port,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-api/user/confirmAddFriendWithShopId",
            method: "POST"
        }, function (err, result) {
            fn(err, result);

        });
    },
    requestCusService: function (args, fn) {
        proxy.invoke({
            data: args,
            host: config.im.host,
            port: config.im.port2,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-cus-web/cus-api/requestCusService",
            method: "POST"
        }, function (err, result) {
            fn(err, result);
        });
    },
    getImucIdsByMerchantId: function (args, fn) {
        proxy.invoke({
            data: args,
            host: config.im.host,
            port: config.im.port2,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-cus-web/cus-api/getImucIdsByMerchantId",
            method: "POST"
        }, function (err, result) {
            fn(err, result);
        });
    },
    getLineQueueStatus: function (args, fn) {
        proxy.invoke({
            data: args,
            host: config.im.host,
            port: config.im.port2,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-cus-web/cus-api/getLineQueueStatus",
            method: "POST"
        }, function (err, result) {
            fn(err, result);
        });
    },
    getTransferStatus: function (args, fn) {
        proxy.invoke({
            data: args,
            host: config.im.host,
            port: config.im.port2,
            contentType: "application/json;charset=UTF-8",
            path: "/imuc-cus-web/cus-api/getTransferStatus",
            method: "POST"
        }, function (err, result) {
            fn(err, result);
        });
    }
}

module.exports = WebIm;