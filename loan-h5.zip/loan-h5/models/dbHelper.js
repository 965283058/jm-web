var config = require("../utils/config"),
	logger = require("../utils/logger"),
	ALY = require('aliyun-sdk'),
	PORT = config.db.PORT,
	HOST = config.db.HOST,
	USERNAME = config.db.USERNAME,
	PASSWORD = config.db.PASSWORD;

var memcached = ALY.MEMCACHED.createClient(PORT, HOST, {
  username: USERNAME,
  password: PASSWORD
});

memcached.on('error', function(err) {
  console.log('memached error', err);
  logger.error(err);
});

var ocs = {
	get: function(id, fn){
		console.log("--get--"+id);
		memcached.get.apply(memcached, arguments);
	},
	set: function(id, v, fn){
		console.log("--set--"+id);
		memcached.set.apply(memcached, arguments);
	},
	add: function(){
		memcached.add.apply(memcached, arguments);
	},
	replace: function(){
		memcached.replace.apply(memcached, arguments);
	},
	end: function(){
		memcached.end.apply(memcached, arguments);
	}
}

module.exports = ocs;
