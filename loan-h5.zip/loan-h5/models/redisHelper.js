var config= 		require("../utils/config"),
	logger= 		require("../utils/logger"),
	redis=			require("redis"),
	PORT= 			config.rdb.PORT,
	HOST= 			config.rdb.HOST,
	USERNAME= 		config.rdb.USERNAME,
	PASSWORD= 		config.rdb.PASSWORD;

var generic_pool = require('generic-pool'),
	rdpool= null;  
  
  
function createRedisPool(poolname, poolport, poolhost, poolpwd) {
    return generic_pool.Pool({
        name: poolname,
        create: function (callback) {
			var client = redis.createClient(poolport, poolhost,{});
			client.auth(poolpwd, function(err, res){
				console.log("Connect Redis " + res);
			});
			client.on("error", function (err) {
				console.log("Error " + err);
			});
            callback(null, client);
        },
        destroy: function (client) {
            client.quit();
        },
        max: 5,
        min: 1,
        idleTimeoutMillis: 30000,
        log: false
    });
}
rdpool= createRedisPool("rdb", PORT, HOST, PASSWORD);

module.exports= {
	acquire: function(fn, unRelease, level){
		rdpool.acquire(function(err, client){
			fn(err, client);
			if(unRelease){
				//
			}else{
				rdpool.release(client);
			}
		}, level||0);
	}
};
