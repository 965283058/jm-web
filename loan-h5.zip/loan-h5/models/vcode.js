/*!
	发送验证码模块
	@data 2016-11-26
	@method intpay
*/
"use strict";
var proxy = require("../utils/proxy"),
	redisHelper= require("./redisHelper"),
	config = require('../utils/config');
	//logger = require('../utils/logger');
//
const content= "{code}（验证码，30分钟内有效），{title}，请勿将验证码泄漏给其他人。";
const titles= {
	"v2_addFri": "该手机号正在进行添加好友请求验证"
};


class Vcode {
	constructor(remark){
		if(!remark|| !/^\w{3,10}\.\w{3,10}$/i.test(remark)){
			console.log("unknow remark");
			throw new Error("unknow remark");
		}
		this.remark= remark;
	}
	
	sendCode(args, fn){
		if(!args.phone|| !/^\d{8,11}$/.test(args.phone) ){
			return fn(null, {code: 1000, message: "手机号格式不正确"});
		}
		var that= this,
			code= args.code|| Math.random().toString().slice(-4),
			count=0,
			now= Date.now(),
			ago_30min= now- 18*1e5,
			times= [],
			rdbk= `sms-${that.remark}-${args.phone}`,
			codeStr= `${count}-${code}-`;
		//
		var _result= {
    		code: 0,
    		message: "",
    		data: ""
    	};
		//保存数据，并发送验证码
		new Promise(function(resolve, reject){
			//查询上次发送情况
			redisHelper.acquire(function(err, client){
				client.get(rdbk, function(err, result){
					if(err){
						_result.code= 1001;
						_result.message= "rdb异常";
                        reject(err);
					}else if(!result){
						//近期没有发送过
						resolve();
					}else{
						times= result.split("-").slice(2);
						times= times.reduce(function(a1, a2, a3){
							if(a2&& a2>ago_30min){
								a1.push(a2);
							}
							return a1;
						}, []);
						//
						var countDown= 0;
						if(times.length>=5){
							_result.code= 1000;
							_result.message= "您在30min内请求超过5次了,请稍候重试";
							reject();
						}else if(times.length && (countDown= now- times[times.length-1], countDown< 6e4)  ){
							_result.code= 1000;
							_result.message= "请在"+ (60- parseInt(countDown/1e3) )+"秒后再发送";
							reject();
						}else{
							resolve();
						}
					}
				});
			});

		}).then(function(){
			return new Promise(function(resolve, reject){
				proxy.invoke({
					data:{
						phone: args.phone,
						content: content.replace(/{(code|title)}/g, function($1, $2){
							if("code"=== $2){
								return code;
							}else{
								return titles.v2_addFri;
							}
						}),
						remark: that.remark,
						extention: ""
					},
					host: config.sms.host,
					path:"/service/sms/sms.send",
			       	method:"POST"
			    }, function(err, result){
					if(err|| !result|| 0!=result.status){
						_result.code= 1000;
						_result.message= "发送验证码失败，请稍候重试"+ (result.message||"");
						reject();
					}else{
						resolve();
					}
				});
			});
		}).then(function(){
			redisHelper.acquire(function(err, client){
				times.push(now);
				codeStr+= times.join("-");
                client.set(rdbk, codeStr, function(err, result2){
                    if(err){
                    	_result.code= 1001;
						_result.message= "rdb异常";
                        reject(err);
                    }else{
                    	_result.code= 0;
						_result.message= "验证码发送成功";
                        fn(err, _result);
                    }
                });
                client.expire(rdbk, 30*60); //cache 30 minutes
            });
		}).catch(function(err){
			fn(err, _result);
		});
	}
	/**
		@method checkCode
		@params {Object, Function}
		@return {Void}
		@api public

		@date 2016-11-26
		@author intpay
	*/
	checkCode(args, fn){
		if(!args.phone|| !/^\d{8,11}$/.test(args.phone) ){
			return fn(null, {code: 1000, message: "手机号格式不正确"});
		}
		var rdbk= `sms-${this.remark}-${args.phone}`,
			count=0,
			now= Date.now(),
			ago_30min= now- 18*1e5,
			times= null,
			codeStr_arr= null,
			codeStr= null;
		var _result= {
    		code: 0,
    		message: "",
    		data: ""
    	};
		//验证
		new Promise(function(resolve, reject){
			redisHelper.acquire(function(err, client){
				client.get(rdbk, function(err, result){
					if(err){
						_result.code= 1001;
						_result.message= "rdb异常";
						reject(err);
					}else{
						codeStr_arr= result.split("-");
						resolve();
					}
				});
			});
		}).then(function(){
			if(codeStr_arr[0]>=3){
				_result.code= 1000;
				_result.message= "验证次数超过3次，请重新发送验证码";
			}else if(args.vcode!== codeStr_arr[1]){
				_result.code= 1001;
				_result.message= "验证码不正确";
			}else if(codeStr_arr.slice(-1)< ago_30min ){
				_result.code= 1002;
				_result.message= "验证码已过期，请重新发送";
			}else{
				_result.code= 0;
				_result.message= "验证通过";
			}
			codeStr_arr[0]= 1+(parseInt(codeStr_arr[0])|| 0);
			//
			codeStr= codeStr_arr.join("-");
			redisHelper.acquire(function(err, client){
	            client.set(rdbk, codeStr, function(err, result2){
	                if(err){
	                	_result.code= 1001;
						_result.message= "rdb异常";
	                    reject(err);
	                }else{
	                    fn(err, _result);
	                }
	            });
	            client.expire(rdbk, 30*60); //cache 30 minutes
	        });
		}).catch(function(err){
			fn(err, _result);
		});
	}
}


module.exports = Vcode;