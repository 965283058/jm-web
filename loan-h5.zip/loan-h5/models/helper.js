/************************************
通用帮助类
************************************/
var proxy = require("../utils/proxy");


function Helper(){
	
}

Helper.prototype = {

}

module.exports = Helper;