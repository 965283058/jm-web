/**=====================
modules Shop
=====================**/
var proxy = require("../utils/proxy"),
	dbHelper = require("./dbHelper"),
	events = require('events'),
	config = require('../utils/config'),
	logger = require('../utils/logger');


function Admin(){

}

config.prefix_admin_swth= "cm_admin_swth_";
config.prefix_val= "cm_val_";//

/*
	typeId: 001:swth
*/
Admin.setSwthConfig= function(cfg, fn){
	dbHelper.set(config.prefix_admin_swth+ cfg.typeId+ config.env, JSON.stringify(cfg), function(err, result){
		if(err || !result){
			logger.error(err);
		}else{

		}
		fn(err, result);
	});
}

Admin.getSwthConfig= function(cfg, fn){
	dbHelper.get(config.prefix_admin_swth+ cfg.typeId+ config.env, function(err, result){
		if(err|| !result){
			fn(err, {});
			logger.error(err);
		}else{
			var data = JSON.parse(result);
			fn(err, data);
		}
	});
}

Admin.setVal= function(cfg, fn){
	dbHelper.set(config.prefix_val+ cfg.key+ config.env, JSON.stringify(cfg), function(err, result){
		if(err|| !result){
			fn(err, {});
			logger.error(err);
		}else{
			var data = JSON.parse(result);
			fn(err, data);
		}
	});
}
Admin.getVal= function(cfg, fn){
	dbHelper.get(config.prefix_val+ cfg.key+ config.env, function(err, result){
		if(err|| !result){
			fn(err, {});
			logger.error(err);
		}else{
			var data = JSON.parse(result);
			fn(err, data);
		}
	});
}


module.exports = Admin;