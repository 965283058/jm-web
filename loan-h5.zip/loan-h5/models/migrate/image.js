var formidable = require('formidable'),
    path = require('path'),
    fs = require('fs');

function Image (args) {
	if (!args) {
		args = {};
	}
	this.uploadDir = args.uploadDir || path.join(__dirname, '../../public/imgs/upload/');
  this.filePath = '';
  this.type = '';
}
Image.prototype = {
	upload: function (req, fn) {
		  var self = this;
		  var form = new formidable.IncomingForm();   //创建上传表单
      form.encoding = 'utf-8';		//设置编辑
    	form.uploadDir = self.uploadDir	 //设置上传目录
    	form.keepExtensions = true;	 //保留后缀
    	form.maxFieldsSize = 2 * 1024 * 1024;   //文件大小
    	form.multiples = true; //多文件时用true可以使回调函数中的files成数组

    	var hasWrong = 0;

    	form.on('file', function (name, file) {
    		var extName = '';  //后缀名
     		switch (file.type) {
      			case 'image/pjpeg':
        			extName = 'jpg';
        			break;
      			case 'image/jpeg':
        			extName = 'jpg';
        			break;		 
      			case 'image/png':
       				extName = 'png';
        			break;
      			case 'image/x-png':
        			extName = 'png';
        			break; 
   			}
   			if (extName.length == 0) {
   				hasWrong = 1;
   				fs.unlink(file.path, function (err) {
  					console.log('deleted!');
  				});
   			} else {
   				var avatarName = new Date().getTime() + '_' + Math.round(Math.random()*1000) + '.' + extName;
   				var newPath = form.uploadDir + avatarName;
          self.filePath = newPath;
          self.type = extName;
  				fs.rename(file.path, newPath);  //重命名
   			}
    	});

    	form.on('progress', function(bytesReceived, bytesExpected) {
			   console.log(bytesReceived + '/' + bytesExpected);
      });

    	form.parse(req, function (err, fields, files) {
    		if (err) {
    			fn(err, null);
    		} else {
          var result = {};
    			if (hasWrong == 1) {
            result.code = 1000;
            result.message = '有错误格式的图片或空值!';
    				fn(null, result);
    			} else {
            result.code = 0;
            result.message = '图片上传成功!';
            result.data = {
              seq: fields.seq,
              file: self.filePath,
              type: self.type
            }
    				fn(null, result);
    			}
    		}
    	});
	}
}

module.exports = Image;