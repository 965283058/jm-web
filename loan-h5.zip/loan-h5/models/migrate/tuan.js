var proxy = require("../../utils/proxy"),
	http = require("http"),
    config = require('../../utils/config');

function Tuan () {

}
Tuan.prototype = {
	checkNewGroup: function (args, fn) {
		proxy.invoke({
			data: args,
			path: "/order/checkNewBuyerJoinGroup",
			method: "POST"
		}, function (err, result) {
			fn(err, result);
		});
	},
	hotRecommend: function (args, fn) {
		proxy.invoke({
			data: args,
			host: config.recommend.host7,
			port: config.recommend.port7,
			path: '/front_page_hr',
			method: "POST"
		}, function (err, result) {
			fn(err, result);
		});
	},
//	根据商品id找商品详情
	getGoodsDetailById: function (args, fn) {
		proxy.invoke({
			data: args,
			path: "/intpayApp/batchGetProductDetail",
			method: "POST"
		}, function (err, result) {
			//console.log(result)
			fn(err, result);
		});
	},
//	新手专享
	getNewComerList: function (args, fn) {
		proxy.invoke({
			data: args,
			host: config.pintuanSecond.host,
			port: config.pintuanSecond.port,
			path: "/intpayApp/getPintuanProductList",
			method: "POST",
		}, function (err, result) {
			fn(err, result);
		});
	},
	//检测用户有否团免券
	checkFreeTicket: function (args, fn) {
		proxy.invoke({
			host: config.pintuanSecond.host2,
			port: config.pintuanSecond.port2,
			path: config.couponPrefix + '/coupon/h5/hasfree?wid=' + args.wid
		}, function (err, result) {
			fn(err, result);
		});
	},
	//获取粉丝列表接口
	getFansList: function (args, fn) {
		proxy.invoke({
			host: config.pintuanSecond.host3,
			port: config.pintuanSecond.port3,
			path: config.couponPrefix2 + '/mtz/h5/myfans?wid=' + args.wid + '&unionId=' + args.unionId  + '&pageNo=' + args.pageNo + '&pageSize=' + args.pageSize
		}, function (err, result) {
			// console.log(result);
			fn(err, result);
		});
	},

	//获取萌团长页面数据
	getLeaderList:function(args,fn){
		proxy.invoke({
			host: config.pintuanSecond.host3,
			port: config.pintuanSecond.port3,
			path:config.couponPrefix2 + '/mtz/h5/mymtz?wid='+args.wid+'&unionId='+args.unionId
		}, function (err, result) {
			fn(err, result);
		});
	},
  
    //获取二维码接口
    getQrcode:function(args,fn){
    	proxy.invoke({
			host: config.pintuanSecond.host3,
			port: config.pintuanSecond.port3,
			path:config.couponPrefix2 + '/mtz/h5/qrcode?wid='+args.wid+'&unionId='+args.unionId
		}, function (err, result) {
			fn(err, result);
		});
    },

	/**
	 * @method 分享语接口
	 * @author Henry(617822642@qq.com)
	 */
	sharequote: function (args, fn) {
		proxy.invoke({
			data: args,
			protocol: "http",
			host: config.pintuanSecond.host,
			port: config.pintuanSecond.port,
			path: "/intpayApp/pintuan/sharequote",
			method: "POST",
			contentType: "application/json;charset=UTF-8"
		}, function (err, result) {
			fn(err, result);
		})
	},

	/*累计奖金*/
	mymtz: function (args, fn) {
		proxy.invoke({
			host: config.pintuanSecond.host3,
			port: config.pintuanSecond.port3,
			path: config.couponPrefix2 + "/mtz/h5/mymtz?wid=" + args.wid + "&unionId=" + args.unionId
		}, function (err, result) {
			fn(err, result);
		});
	},

	/*奖金记录（萌团长账单）*/
	getBonusRecord:function(args,fn){
		proxy.invoke({
			host: config.api.host,
			port: config.api.port,
			data: args,
			path: "/finance/billLists",
			method: "POST"
		}, function (err, result) {
			fn(err, result);
		});
	},

	/*提现记录*/
	getBonusWithdraw:function(args,fn){
		proxy.invoke({
			host: config.api.host,
			port: config.api.port,
			data: args,
			path: "/finance/withdrawalsLists",
			method: "POST"
		}, function (err, result) {
			fn(err, result);
		});
	},
   /*萌团长模式  ????未使用*/
	getHeadmode:function(args,fn){
		proxy.invoke({
			host: config.api.host,
			port: config.api.port,
			path:'/intpay-mtz-web/mtz/h5/mymtz?wid='+args.wid+'&unionId='+args.unionid
		}, function (err, result) {
			fn(err, result);
		});
	},
	/**
	 * 获取参团页“看过的人”
	 * @author Henry(jiabin.chen@weimob.com)
	 */
	browsers: function (args, fn) {
		proxy.invoke({
			host: config.coupon2.host2,
			port: config.coupon2.port2,
			// data: args,
			// method: "POST",
			path: config.couponPrefix2 + '/mtz/h5/browsers' + formate(args)
		}, function (err, result) {
			fn(err, result);
		})
	},

	/**
	 * 建立粉丝关系
	 * @author Henry(jiabin.chen@weimob.com)
	 */
	pageview: function (args, fn) {
		proxy.invoke({
			data: args,
			host: config.coupon2.host2,
			port: config.coupon2.port2,
			method: "POST",
			contentType: "application/json;charset=UTF-8",
			path: config.couponPrefix2 + "/mtz/h5/pageview"
		}, function (err, result) {
			fn(err, result);
		})
	},
	/**
	 * unionid wid 绑定关系通知
	 * @author eric(eric@weimob.com)
	 */
	loginMsg: function (args, fn) {
		proxy.invoke({
			data: args,
			host: config.coupon2.host2,
			port: config.coupon2.port2,
			method: "POST",
			contentType: "application/json;charset=UTF-8",
			path: config.couponPrefix2 + "/mtz/h5/login"
		}, function (err, result) {
			fn(err, result);
		})
	},
	/*
	**获取分享活动信息(中奖名单分享，一元团中奖名单订单详情团结果页分享)
	*/
	getShareActivityInfo:function(args,fn){
		args.applicationName = 'intpay.node-web';
        args.serviceName = 'com.weimob.intpay.groupon.service.GrouponInfoService';
        args.methodName = 'getShareActivityInfo';
		proxy.invoke({
			data: args,
			protocol: "http",
			host: config.soaProxy.host,
			port: config.soaProxy.port,
			path: "/soa-proxy",
			method:"POST",
			keyValue: true
		}, function (err, result) {
			fn(err, result);
		});
	},

	/*拼团详情*/
	getPinTuanDetail: function (args,fn) {
		args.applicationName = 'intpay.node-web';
        args.serviceName = 'com.weimob.intpay.groupon.service.GrouponInfoService';
        args.methodName = 'grouponIsShare';
		proxy.invoke({
			data: args,
			protocol: "http",
			host: config.soaProxy.host,
			port: config.soaProxy.port,
			path: "/soa-proxy",
			method:"POST",
			keyValue: true
		}, function (err, result) {
			fn(err, result);
		});
	},
	/*获得首页悬浮广告位*/
	getSuspendAdBanner:function(args,fn){
		proxy.invoke({
			data: args,
			host: config.pintuanSecond.host,
			port: config.pintuanSecond.port,
			path: "/intpayApp/getAppRightBottomFloat",
			method:"POST"
		}, function (err, result) {
			fn(err, result);
		});
	},
	getactivityforappdoubleone:function(args,fn){      //获取双十一大促预热入口 接口
		proxy.invoke({
			data: args,
			protocol: "http",
			host: config.coupon2.host,
			port: config.coupon2.port,
			path: config.couponPrefix+"/coupon/getactivityforappdoubleone",
			method:"POST",
			keyValue: true
		}, function (err, result) {
			fn(err, result);
		});
	},
	/***
		团商品活动提醒
		@params 
	**/
	userGoodsRemind:function(args,fn){
		proxy.invoke({
			data: args,
			protocol: "http",
			host: config.pintuanSecond.host,
			port: config.pintuanSecond.port,
			path: '/intpayApp/v1/userGoodsRemind',
			method:"POST"
		}, function (err, result) {
			fn(err, result);
		});
	}
	
}

function formate(args) {
	var _args = "";
	for (name in args) {
		_args += "&" + name + "=" + args[name];
	};
	return _args.replace(/\&?/, "?");
}

module.exports = Tuan;