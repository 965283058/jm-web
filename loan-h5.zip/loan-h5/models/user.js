"use strict";
/************************************
用户类
************************************/
var proxy = require("../utils/proxy"),
    dbHelper = require("./dbHelper"),
    config = require('../utils/config'),
    logger = require('../utils/logger'),
    debug= require("debug")("model-user"),
    co= require("co");

    config.prefix_user = "cm_user_";

function User(){
	this.userid = null;
	this.username = null;
	this.nick_name = null;
	this.openid = null;
	this.password = null;
	this.mobile = null;
    this.code = null; // 手机验证码
    this.qq_num = null;
    this.head_img = null;
    this.yunjie_id = null;
    this.bind_mobile= null;
    this.ctime= null;
    this.mode = null;//
    this.clientIp= null; //风控
    this.tosmsapp= null; 
    this.appIdentifier=null;//区分应用：趣借了node-Intpay
}

User.prototype = {
	add: function(fn){
		proxy.invoke({
			data:{
				username: this.username,
				nick_name: this.nick_name,
				openid: this.openid,
				password: this.password,
				mobile: this.mobile,
				qq_num: this.qq_num,
                head_img: this.head_img,
                yunjie_id: this.yunjie_id,
                clientIp: this.clientIp,
                appIdentifier:this.appIdentifier
			},
            path: "/user/adduserinfo",
	       	method:"POST"
	    	}, function(err, result){
				fn(err, result);
			}
		);
	},
    getUserById: function (fn) {
        proxy.invoke({
                data: {
                    user_id: this.userid
                },
                path: "/user/getuserbyid",
                method: "POST"
            }, function (err, result) {
                fn(err, result);
            }
        );
    },
	getUserByOpenid: function(fn){
		proxy.invoke({
			data:{
				openid: this.openid
			},
			path:"/user/getuserbyopenid",
	       	method:"POST"
	    	}, function(err, result){
                if(result.data && result.data.user_id){
                    var user = new User(), _user = result.data;
                    user.userid = _user.user_id;
                    user.username = _user.username;
                    user.nick_name = _user.nick_name;
                    user.openid = _user.openid|| _user.vd_openid;
                    user.password = _user.password;
                    user.mobile = _user.mobile;
                    user.code = _user.code;
                    user.head_img = _user.head_img;
                    user.qq_num = _user.qq_num;
                    user.bind_mobile= _user.bind_mobile;
                    user.ctime= _user.ctime;
                    user.wid= _user.wid;
                    fn(err, user);
                }else{
                    fn(err, result);
                }
			}
		);
	},
	getUserByMobile: function(fn){
        proxy.invoke({
            data:       {
                method: "uc.user.getUserInfoByMobile",
                params: {
                    mobile:this.mobile
                },
                appIdentifier:this.appIdentifier
            },
            protocol:   "http",
            host:       config.mduc.host,
            port:       config.mduc.port,
            path:       "/api",
            method:     "POST",
            contentType: "application/json;charset=UTF-8"
        }, function (err, result) {
            fn(err, {
                code:result.code,
                message: result.message,
                data: result.data.user_info
            });
        });
	},
    // 验证手机是否已经被注册
    checkMobileUnique: function (fn) {
        proxy.invoke({
                data: {
                    mobile: this.mobile
                },
                path: "/user/checkmobileunique",
                method: "POST"
            }, function (err, result) {
                fn(err, result);
            }
        );
    },
    // 获取验证码
    sendCode: function (fn) {
        proxy.invoke({
                data: {
                    mobile: this.mobile,
                    mode: this.mode,
                    clientIp: this.clientIp || '',
                    passCode: this.passCode || '',
                    tosmsapp:this.tosmsapp||'',
                    appIdentifier:this.appIdentifier||''                    
                },
                path: "/v2/account/sendCode",
                method: "POST"
            }, function (err, result) {
                fn(err, result);
            }
        );
    },
    //验证验证码
    checkCode: function (fn) {
        proxy.invoke({
            data: {
                mobile: this.mobile,
                mode: this.mode,
                code: this.code,
                clientIp: this.clientIp || '',
                appIdentifier:this.appIdentifier||''    
            },
            path: "/v2/account/checkCode",
            method: "POST"
            }, function (err, result) {
                fn(err, result);
            }
        );
    },
    // 更新买家信息
    modify: function (args, fn) {
        var user= args;
        if("object"== typeof args.user_id){
            user= args.user_id;
            user.mobile= args.mobile;
            user.bind_mobile= args.bind_mobile;
            appIdentifier=args.appIdentifier;
        }
        proxy.invoke({
                data: user,
                path: "/user/saveuser",
                method: "POST"
            }, function (err, result) {
                fn(err, result);
            }
        );
    },
	del: function(){

	},
    // 上传头像
    uploadImage: function(args, fn){
        proxy.invoke({
                data: args,
                path: "/upload/baseupload",
                method: "POST"
            }, function (err, result) {
                fn(err, result);
            }
        );
	}
}

User.login = function(){

}

User.logout = function(){

}

// 获取收藏的商品/店铺
User.getFavoriteList = function (args, fn) {
    var is_temp = (-1 == args.user_id),
        _data = {
            user_id: is_temp ? args.yunjie_id : args.user_id,
            page: args.page,
            is_temp: 0,
            //for goods
            //baseAppType: "H5",
            //scenarios: 2 //只显示直销
        };
    proxy.invoke({
        data: _data,
        path: (args.type == 'shop') ? "/collect/shopList" : "/collect/goodsList",
        method: "POST"
    }, function (err, result) {
        fn(err, result);
    });
};

User.getAccessToken = function(args, fn){
    var self = this;
    if(!args.openid){
        return fn({message:"can't find openid"}, null);
    }
    dbHelper.get(config.prefix_user+args.openid, function(err, result){
        if(err || !result){
            fn(err||{expires_date:0});
            logger.error(err);
        }else{
            var data = JSON.parse(result)||{expires_date:0};
            if(data.expires_date && (new Date().getTime() < data.expires_date) ){
                fn(err, data);
                return;
            }
            fn(err, data);
        }
    });
}

User.getWXAccessToken = function(args, fn){
    proxy.invoke({
            data:{},
            protocol:"https",
            host:"api.weixin.qq.com",
            port:443,
            path:"/sns/oauth2/access_token?appid="+args.AppID+"&secret="+args.AppSecret+"&code="+args.CODE+"&grant_type=authorization_code",
            method:"GET"
        }, function(err, result){
            /**
               "access_token":"ACCESS_TOKEN",
               "expires_in":7200,
               "refresh_token":"REFRESH_TOKEN",
               "openid":"OPENID",
               "scope":"SCOPE"
            **/
           fn(err, result);
           User.setAccessToken({
                userid:null,
                openid: result.openid,
                scope: result.scope,
                access_token: result.access_token,
                refresh_token: result.refresh_token,
                expires_in: result.expires_in,
                expires_date: new Date().getTime() + (result.expires_in - 60*10 )*1000,
                AppID: args.AppID,
                AppSecret: args.AppSecret
           }, function(){

           });
        }
    );
}

//
User.getWXUserInfoByOpenid = function(args, fn){
     proxy.invoke({
            data:{},
            protocol:"https",
            host:"api.weixin.qq.com",
            port:443,
            path:"/cgi-bin/user/info?access_token="+args.access_token+"&openid="+args.openid+"&lang=zh_CN",
            method:"GET"
        }, function(err, result){
            fn(err, result);
        }
    );
}

User.getWXUserInfoByOpenid2 = function(args, fn){
    proxy.invoke({
            data:{},
            protocol:"https",
            host:"api.weixin.qq.com",
            port:443,
            path:"/sns/userinfo?access_token="+ args.access_token+"&openid="+ args.openid+"&lang=zh_CN",
            method:"GET"
        }, function(err, result){
            fn(err, result);
        }
    );
}

User.setAccessToken = function(args, fn){
    var data = {
            userid: args.shop_id,
            openid: args.openid,
            access_token: args.access_token,
            refresh_token: args.refresh_token,
            expires_in: args.expires_in,
            expires_date: args.expires_date,
            AppID: args.AppID,
            AppSecret: args.AppSecret
        };
    dbHelper.set(config.prefix_user+args.openid, JSON.stringify(data), function(err, result){
        if(err || !result){
            fn(err, result);
            logger.error(err);
            return;
        }else{
            fn(err, JSON.parse(result));
        }
    });
}

User.refreshAccessToken = function(args, fn){
     proxy.invoke({
            data:{},
            protocol:"https",
            host:"api.weixin.qq.com",
            port:443,
            path:"/sns/oauth2/refresh_token?appid="+args.AppID+"&grant_type=refresh_token&refresh_token="+args.refresh_token,
            method:"GET"
       }, function(err, result){
            fn(err, result);
            User.setAccessToken({
                userid:null,
                openid: result.openid,
                scope: result.scope,
                access_token: result.access_token,
                refresh_token: result.refresh_token,
                expires_in: result.expires_in,
                expires_date: new Date().getTime() + (result.expires_in - 60*10 )*1000,
                AppID: args.AppID,
                AppSecret: args.AppSecret
            }, function(){

            });
        }
    );
}

//合并临时用户身份
User.changetempinfo = function(args, fn){
    var _args = {
        user_id: args.user_id,
        user_type: args.openid?1:2, //1: openid, 2: yunjie_id
        temp_id: args.openid||args.yunjie_id
    }
    proxy.invoke({
            data: _args,
            path: "/user/changetempinfo",
            method: "POST"
        }, function (err, result) {
            fn(err, result);
        }
    );
}

//获取旺铺用户身份
 User.getWPUserByOpenid = function(args, fn){
    var _args = {
        "AId": config.weichat.aid,
        "Identity": args.openid,
        "FansFields":"*"
    };
    proxy.invoke({
            data: _args,
            host:config.wp.wechatUc.host,
            port:config.wp.wechatUc.port,
            path: "/UC/API/WeimobUser/GetSingleFans/get?" + JSON.stringify(_args),
            method: "GET"
        }, function (err, result) {
            fn(err, result);
        }
    );
 }

 //查验用户是否已注册并返回验证码  使用v2版本后，已废弃, to checkMobile2
 User.checkMobile = function(args, fn){
    proxy.invoke({
        data: args,
        Apiclient: "vd-pc", //用于去掉必传参数_sign_
        path: "/account/checkMobile",
        method: "POST"
    }, function(err, result){
        fn(err, result);
    });
 }


//查验用户是否已注册并返回验证码 使用v2版本
 User.checkMobile2 = function(args, fn){
    proxy.invoke({
        data: args,
        Apiclient: "vd-pc", //用于去掉必传参数_sign_
        path: "/v2/account/checkMobile",
        method: "POST"
    }, function(err, result){
        fn(err, result);
    });
 }

//登录或注册 使用v2版本后， 已废弃，to register2
User.loginAndRegister = function(args, fn){
    proxy.invoke({
        data: args,
        Apiclient: "vd-pc",
        path: "/account/login",
        method: "POST"
    }, function(err, result){
        fn(err, result);
    });
}

//注册
User.register2 = function(args, fn){
    proxy.invoke({
        data: args,
        Apiclient: "vd-pc",
        path: "/v2/account/register",
        method: "POST"
    }, function(err, result){
        fn(err, result);
    });
}

//获取验证码图片
User.getCaptcha = function(args, fn){
    proxy.invoke({
        data: args,
        path: "/account/getCaptcha",
        method: "POST"
    }, function(err, result){
        fn(err, result);
    });
}

//获取对应的萌店信息
User.getShopInfoById = function(args, fn){
    var _args= {
        wid: args.wid
    };
    proxy.invoke({
        data: _args,
        path: "/user/getshopbywid",
        method: "POST"
    }, function(err, result){
        fn(err, result);
    });
}

User.v3Login= function(args, fn){
    var _args= {
        mobile:                 args.mobile,
        code:                   args.code,
        //third_type: ,
        //third_uuid: ,
        channel:                args.channel|| "",
        invite_wid:             args.invite_wid,
        invite_shop_id:         args.invite_shop_id,
        client_id:              args.client_id,
        nick_name:              args.nick_name,
        clientIp:               args.clientIp
    };
    proxy.invoke({
        data: _args,
        path: "/v3/account/login",
         method: "POST"
    }, function(err, result){
        fn(err, result);
    });
}

User.wechatQrCreate= function(args, fn){
    proxy.invoke({
        data:       {
            method: "wechat.account.genQRCode",
            params: {
                open_id: "-1",
                app_id: args.appId,
                scene_id: args.sceneId
            }
        },
        protocol:   "http",
        host:       config.mduc.host,
        port:       config.mduc.port,
        path:       "/api",
        method:     "POST",
        contentType: "application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    });
}
/*User.wechatQrCreate= function(args, fn){
    if(!args.appId|| !args.sceneId){
        return fn(new TypeError("appId or sceneId is empty") );
    }
    let key = `1001_wechat_${args.appId}_${args.sceneId}_`;
    //
    co(function*(){
        let r1= yield getMcQrTicket(key);
        debug("%j", r1[1]);
        if(r1[1]){
            return fn(null, r1[1]);
        }
        let r2= yield getWechatToken();
        if(!r2[1]){
            return fn("get token failed");
        }
        let r3= yield getWechatQrTicket(r2[1]);
        debug("---r3--- %j", r3[1]);
        if(r3[1]){
            setMcTicket(key, r3[1]);
        }
    });

    //
    function getMcQrTicket(key){
        return new Promise(function(resolve, reject){
            dbHelper.get(key, function(err, result){
                if(err || !result){
                   resolve([err] );
                }else{
                    let data = JSON.parse(result)||{expires_date:0};
                    if(data.expires_date && (new Date().getTime() < data.expires_date) ){
                       resolve([new Error("expired!")] );
                    }else{
                        resolve([,data]);
                    }
                }
            });
        });
    }
    function getWechatToken(){
        return new Promise(function(resolve, reject){
            proxy.invoke({
                data:       {
                    method: "wechat.account.getToken",
                    params: {
                        account_app_id: args.appId
                    }
                },
                protocol:   "http",
                host:       config.mduc.host,
                port:       config.mduc.port,
                path:       "/api",
                method:     "POST",
                contentType: "application/json;charset=UTF-8"
            }, function (err, result) {
                if(err|| 0!= result.code){
                    resolve([err]);
                }else{
                    let access_token= result.data;
                    resolve([,access_token]);
                    
                }
            });
        });
    }
    //
    function getWechatQrTicket(access_token){
        console.log(access_token);
        return new Promise(function(resolve, reject){
            proxy.invoke({
                data:{
                    "expire_seconds": 604800,
                    "action_name": "QR_SCENE",
                    "action_info": {
                        "scene": {
                            "scene_id": args.sceneId
                        }
                    }
                },
                protocol:"https",
                host:"api.weixin.qq.com",
                port:443,
                path:"/cgi-bin/qrcode/create?access_token="+ access_token,
                method:"GET"
            }, function(err, result){
                if(err){
                    resolve([err]);
                }else{
                    resolve([,result]);
                }
            });
        });
    }
    //
    function setMcTicket(key, val){
        dbHelper.set(key, JSON.stringify(val), function(err, result){
            //
        });
    }
}*/

/**
 * @method 查询 openid 是否已关注
 * @authod Henry(jiabin.chen@weimob.com)
 */
User.isSubscribed = function (args,fn) {
    proxy.invoke({
        data:{
            method:"uc.user.isSubscribed",
            params:args
        },
        protocol:"http",
        host:config.mduc.host,
        port:config.mduc.port,
        path:"/api",
        method:"POST",
        contentType:"application/json;charset=UTF-8"
    },function(err,result){
        fn(err,result)
    })
}

 // 检查手机号的注册状态
User.checkmobilestatus= function(args, fn){
     proxy.invoke({
            data: {
                mobile: args.mobile,
                open_id_type: args.open_id_type,
                appIdentifier:args.appIdentifier
            },
            path: "/user/checkmobilestatus",
            method: "POST"
        }, function (err, result) {
            fn(err, result);
        }
    );
}

module.exports = User;