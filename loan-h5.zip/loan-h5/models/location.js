/************************************
坐标类
************************************/
var proxy = require("../utils/proxy"),
	config = require("../utils/config"),
	qs = require('querystring'),
	http = require("http");

function Location(location_args){
	location_args = location_args||{};
	this.key = location_args.key||config.qqLbs.key;
	this.lat = location_args.lat; //39.984154
	this.lng = location_args.lng; //116.307490
	this.nation = location_args.nation;
	this.province = location_args.province;
	this.city = location_args.city;
	this.district = location_args.district;
	this.address = location_args.address;
}

Location.prototype = {
	geocoder: function(fn){
		var args = {
				location:"39.984154,116.307490",
				key: this.key,
				get_poi:1
			};

		http.get("http://apis.map.qq.com/ws/geocoder/v1/?location="+this.lat+","+this.lng+"&key="+this.key+"&get_poi=1", function(res) {
			var body = "";
			res.
			on('data',function(d){
				body += d;
			}).
			on('end', function(){
				try{
					body = JSON.parse(body);
				}catch(e){
					body = {"code":"500000","message":"JSON.parse error","data":[]};
				}finally{
					fn(null, body.result||{});
				}
			}).
			on("close", function(e){
	            
	        }).
	        on("abort", function(){
	            fn({code:2000, message:"timeout or cancel"});
	        });
		}).on('error', function(e) {
		  
		});
	}
}

module.exports = Location;