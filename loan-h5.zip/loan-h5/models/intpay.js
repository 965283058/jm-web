var proxy = require("../utils/proxy"),
	http = require("http"),
    config = require('../utils/config');

function Intpay () {

}
Intpay.getIndexInfo= function (args, fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/loan-manager/intpay/loan/queryHomeInfo",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    });
}
Intpay.getmyLoadList = function (args, fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/getLoanList",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        
        fn(err, result);
    });
};
Intpay.getRepaymentList =  function (args, fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/getLoanRepayList",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    });
}
Intpay.cellphoneTrafficOrderCallback =  function (args, fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/cellphoneTrafficOrderCallback",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    });
}
Intpay.queryProductList = function (args, fn) {
    // console.log('---/models/intpay/queryProductList---');
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/loan-manager/intpay/loan/queryProductList",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    });
}
Intpay.getProductByCode = function (args, fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/loan-manager/intpay/loan/getProductByCode",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    })
}
Intpay.getAffiche = function (args, fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/getAffiche",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    })
}
Intpay.applyLoan = function (args, fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/loan-manager/intpay/loan/apply/applyLoan",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    })
}
/**
 * 我要赚钱页面获取滚动消息与规则
 * @param args 请求参数
 * @param fn   回调函数
 *  args={
     *   biz_acount_source:"" ,  // 业务账号来源，萌店app：1，萌店H5:2
     *   }
 * 接口返回数据格式说明
 *    result={
                code:0,//返回码，成功为0
                msg:0,//返回信息，成功为操作成功
                data:{
                    max_traffic_info: 200M,//一级客户首次登陆成功最高可以抽取的流量数
                    level_1_commission_info: 5元,//一级客户首次贷款成功奖励金额
                    level_2_commission_info: 5元,//二级客户首次贷款成功奖励金额
                    commission_list:[//收入播报列表,每次从服务端获取100条数据
                        {
                            mobile:"13217281812",            //客户手机号
                            amount:"5",         //客户该次获得的佣金金额
                        }
                    ]
                }
            }
 */
Intpay.getLatestCommissionList= function (args, fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/commission/getLatestCommissionList",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    });
}

/*
* 积分大转盘奖品渲染
* @param args 请求参数
* @param fn 回调
* */
Intpay.integralDraw = function (args,fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/score/getTurntableList",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    })
}
/*
 * 积分大转盘奖品抽奖
 * @param args 请求参数
 * @param fn 回调
 * */
Intpay.luckDraw = function (args,fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/lottery/draw",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    })
}
/*
 * 流量抽取详情
 * @param args 请求参数
 * @param fn 回调
 * */
Intpay.flowDetail = function (args,fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/getCellphoneTrafficExtractDetail",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    })
}
/*
 * 现金提取详情
 * @param args 请求参数
 * @param fn 回调
 * */
Intpay.cashDetail = function (args,fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/cash/commWithdrawDetail",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    })
}
/*
 * 流量大转盘奖品渲染
 * @param args 请求参数
 * @param fn 回调
 * */
Intpay.flowRender = function (args,fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/finance/intpay/extractCellphoneTraffic",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    })
}
/*登录接口*/
Intpay.qjdLogin = function (args,fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/loan-manager/intpay/loan/consumer/login",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        console.log(result);
        fn(err, result);
    })
}
/*发送验证码接口*/
Intpay.qjdsendCode = function (args,fn) {
    proxy.invoke({
        data: args,
        host: config.intpay.host,
        port: config.intpay.port,
        path: "/loan-manager/intpay/loan/sms/getAuthenticode",
        method: "POST",
        contentType:"application/json;charset=UTF-8"
    }, function (err, result) {
        fn(err, result);
    })
}
module.exports = Intpay;
