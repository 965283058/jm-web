var express = require("express"),
	router = express.Router();

/**
 * 罗列所有api{api名:api文件加载路径}
 */
var apiList = {
	stayPage: "../../api/stayPage",
	intpay: "../../api/intpay",

	util: "../../api/util",
	//verify: "../../api/verify",
	verifyIm: "../../api/verifyIm",
	webim: "../../api/webim",

}

/**
 * 加载所有罗列的api
 */
var apis = {};

for (var i in apiList) {
 	var m = require(apiList[i]);
 	apis[i] = m;
}

/**
 * 映射url
 * url模式：/api/api/action[/***]
 */
router.use(function (req, res, next) {
	var paths = req.path.split('/');
	if (paths[0] === "" && paths[1] === "api") {
		//取出api/action以及后面的其余路径
		var len = paths.length,
			api = paths[2] || 'index';
			action = paths[3] || 'index';
			targetApi = null,
			pathParams = [];
		for (var i = 0; i < len - 4; i++) {
			pathParams[i] = paths[i+4];
		}
		req.pathParams = pathParams;
		//匹配
		for (var i in apis) {
			if (api === i) {
				targetApi = apis[i];
				break;
			}
		}
		if (targetApi && targetApi[action]) {
			req.frommigrate= 1;
			targetApi[action].call(null, req, res);
		} else {
			next();
		}
	} else {
		next();
	}
});

module.exports = router;