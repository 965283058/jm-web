var express = require("express"),
	router = express.Router();

/**
 * 罗列所有控制器{控制器名:控制器文件加载路径}
 */
var controllers = {};

controllers['loan'] = {
	intpay: "../../controllers/loan/intpay",
	index: "../../controllers/loan/index",
	qqauth: "../../controllers/loan/qqauth"
}

/**
 * 加载所有罗列的控制器
 */
var ctrls = {};

for (var i in controllers) {
	ctrls[i] = {};
	for (var j in controllers[i]) {
		var m = require(controllers[i][j]);
		ctrls[i][j] = m;
	}
}

/**
 * 映射url
 * url模式：/loan/controller/action[/***]
 */
router.use(function (req, res, next) {
	var paths = req.path.split('/');
	
	//是否匹配前面的固定路径，可自定义
	if (paths[0] === "" && paths[1] === 'loan') {
		//取出controller/action以及后面的其余路径
		var len = paths.length,
			controller = 'intpay',//paths[2] || 'index',
			action = paths[2] || 'index',
			targetCtrl = null,
			pathParams = [];
		for (var i = 0; i < len - 4; i++) {
			pathParams[i] = paths[i+4];
		}
		req.pathParams = pathParams;
		//匹配
		for (var i in ctrls[paths[1]]) {
			if (controller === i) {
				targetCtrl = ctrls[paths[1]][i];
				break;
			}
		}
		//
		if (targetCtrl && targetCtrl[action]) {
			targetCtrl[action].call(null, req, res);
		} else {
			next();
			//handle404(req, res); //无法找到对应的controller/action
		}
	} else {
		next();
	}
});

function handle404 (req, res) {
	res.render('404', {
		title: "找不到页面404",
		pageName: "404"
	});
}

module.exports = router;