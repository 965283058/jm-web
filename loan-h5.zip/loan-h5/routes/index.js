/**

**/
var express = require("express"),
	router = express.Router(),
	    logger = require("../utils/logger"),
    _JSON = require("querystring"),
    crypto = require("crypto"),
    events = require('events'),
    url = require("url"),
    querystring = require("querystring"),
    user_ctr = require("../controllers/user"),
    config = require('../utils/config')


/* 读取店铺信息 */
router.all(/^\/loan\/*?/, catchRender, function(req, res, next) {
    // /api/xxxx格式的path 同样不进行读取店铺信息操作
    // if(/\/loan\/api/i.test(req.originalUrl) ){
    //     return next();
    // }
    var emitter = new events.EventEmitter();
	//初始化用户身份
    emitter.on("initUserInfo", function(){
        emitter.emit("syncAppUI");
        emitter.emit("initShopInfo");
        emitter.emit("initJsTicket");
    });
    //
    (function(){
        var status= {
            shopInfo: false,
            jsTicket: false,
            appLogin: false
        };
        emitter.on("nextStart", function(args){
            status[args.type]= args.value;
            if(status.shopInfo&& status.jsTicket&& status.appLogin){
                next();
            }
        });
    })();
    //获取店铺信息
    emitter.on("initShopInfo", function(){
        if (/^\/buyer/.test(req.path)) {
        res.locals.userInfo = req.session.user;
        //
        /**
            容错说明：
            当详情页为供货商页面的时候（aid不为0，vid=0），之前的逻辑是取vid，当vid为0的时候一直会有店铺不存在，
            解决方案：
            判断aid是否不存在或为0，则调过之前的店铺信息判断
        */
        var vid_no_need= /buyer\/(user|order|webim|vshop)\/.*/.test(req.originalUrl),
            vid_but_incorrect= (/(v|s)id/.test(req.originalUrl) )&& !~~req.query.vid && !~~req.query.sid,
            iswp_and_novid= (/iswp=true/.test(req.originalUrl) )&& !~~req.query.vid && !~~req.query.sid;
        if(vid_no_need|| vid_but_incorrect|| iswp_and_novid){
            req.session.shopInfo= req.session.shopInfo|| {
                shop_id: 0
            };
            return emitter.emit("nextStart", {type: "shopInfo", value: true});
        }
        var shop_id = req.query.vid||req.query.sid||(req.session.shopInfo && req.session.shopInfo.shop_id),//||config.defaultShop.vid,
        args = {
            shop_id: parseInt(shop_id)
        };
        if(!args.shop_id){
            return noShop({});
        }
        //
        res.locals.config.baseUrl = config.share.url.replace(/{vid}/gi, shop_id);
        shop_ctr.getDetail(args, function(err, result){
            if(err || !result.shop_id){
               noShop(result);
            }else{
                delete result.AppID;
                delete result.AppSecret;
                delete result.access_token;
                result.shop_id = args.shop_id;
                req.session.shopInfo = result;
                res.locals.shopInfo = result;
                emitter.emit("nextStart", {type: "shopInfo", value: true});
            }
        });
        } else {
            emitter.emit("nextStart", {type: "shopInfo", value: true});
        }
        //
        function noShop(result){
             var err= '<div class="NaN-shop">\
                    <figure>\
                        <div>'+("103404"=== result._status?'客官，此店涉嫌违规，已被关闭！':'店铺不存在!')+'</div>\
                    </figure>\
                </div>';
            res.render("404", {
                title: "",
                pageName:"error",
                error: err
            });
        }
    });
    //
    emitter.on("initJsTicket", function(){
        if(!res.locals.config.isWeixin){
            emitter.emit("nextStart", {type: "jsTicket", value: true});
        }else{
            var we_cur= req.session.wechat.current,
                args= null;
            if(we_cur&& we_cur.AppID){
                args= {
                    url: [req.protocol, "://", we_cur.domain, req.originalUrl].join(""),
                    AppID: we_cur.AppID,
                    AppSecret: we_cur.AppSecret
                };
                wechat.initJsTicket(args, function(err, result){
                    if(err){

                    }else{
                        res.locals.config.wxConfig= result;
                    }
                    emitter.emit("nextStart", {type: "jsTicket", value: true});
                });
            }else{
                emitter.emit("nextStart", {type: "jsTicket", value: true});
            }
        }
    });
    //同步app登陆信息
    emitter.on("syncAppUI", function(){
        if(res.locals.config.isVdianAPP&& !req.session.user.wid&& res.locals.config.vapp.wid){
            var ui= res.locals.config.vapp,
                args= {
                    mobile: ui.mobile,
                    uuid:   ui.uuid,
                    shop_id: ui.shop_id,
                    wid:    ui.wid,
                    token:  ui.token
                };
            //
            user_ctr.getUserByMobile(args, function(err, result) {
                if (err) {
                    
                } else if (result.code == 0) {
                    // 把当前用户放到session中
                    var yunjie_id= req.session.user.yunjie_id;
                    req.session.user = result.data;
                    req.session.user.id = result.data.user_id;
                    req.session.user.openid = result.data.openid||result.data.vd_openid;
                    req.session.user.shop_id = result.data.shop_id;
                    req.session.user.yunjie_id= yunjie_id;
                }
                emitter.emit("nextStart", {type: "appLogin", value: true});
            });
        }else{
            emitter.emit("nextStart", {type: "appLogin", value: true});
        }
    });
    //入口开始
    emitter.emit("initUserInfo");
});

/**
    a)强制登录
    b)需要限制的页面包括用户，订单，购物车，收藏（ajax）
    c)非限制的页面
        1，登录，登出
        2，执行登录的页面
*/
router.all(/\/buyer\/(user|order|webim)\/.+/, function(req, res, next){
    var reg= /(login|logout|addAction|addfriend|indianaDetail|indianaLotteryDetail)$/;
    if(reg.test(req._parsedUrl.pathname)||  req.session.user.mobile>1000){
        next();
    }else{
        res.redirect("/buyer/user/login?referrer="+ encodeURIComponent(req.originalUrl) );
    }
});

/******************************************************************************************
    pv& uv统计
******************************************************************************************/
function catchRender(req, res, _next){
    //统计
    var render = res.render,
        next = function(){
            res.render = function(view, options, fn){
                options.isLogin= !!(req.session.user.wid&& (""+ req.session.user.wid).length>0);
                //
                if("detail3"===options.pageName || /\/loan\/(tuan|venue|special)/i.test(req.path) ){
                    res.locals.config.mdDomain= config.mdDomain2;
                }
                //
                render.apply(res, arguments);
            }
            _next();
        };
    next();
}

module.exports = router;