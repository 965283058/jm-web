/**
	萌店活动模块
	author:Alex.xu
	email:alex.xu@weimob.com
	date:2015/07/06
**/
var router = require("./router"),
    async = require('async'),
    crypto = require("crypto"),
    config = require('../../utils/config'),
    events = require('events'),

    statistics = require("../../utils/statistics"),
    Statistics2 = require("../../utils/statistics2"),
    //statisticsPartner = require('../../utils/statisticsPartner'),
    tools = require('../../utils/tools'),
    admin_ctr= require("../../controllers/admin"),

    wechat= require("../../utils/wechat").config(shop_ctr),
    verifyCodeHelper= require("../../utils/verifyCodeHelper"),
    Monitor_utl= require("../../utils/monitor"),
    //http = require('http'),
    QQ_util= require("../../utils/QQ"),
    qq_ctr = require('../../controllers/qq'); //用于红包的QQ登录和获取accessToken和openId
    //

/******************************************************************************************/
var key = config.signKey;//'app$584124uyrhgnd*6342{kljnh}'; //密钥
var refreshActivity = true; //是否需要重新获取活动信息
var lastTime = 0; //最近一次获取活动信息的时间
var cacheActivity = {}; //缓存的活动信息
var alreadyCached = false; //是否已经缓存如cacheActivity

var useTecentAPI = config.swth.useTecentAPI; //是否使用腾讯的图形验证码


/******************************************************************************************
    11.11
******************************************************************************************/


/******************************************************************************************
    qq wallet
******************************************************************************************/
/**
    qq检测认证
    a)
 */
router.get("/loan", function(req, res, next){
    res.render("util/qlogin", {
        title: "QQ登录",
        pageName: "qqlogin",
        isLogin: false
    });
});

/**
    qq授权回调页面，返回code 参数
    a)统一跳转地址 /loan/qqauth?qurl=ORIGINALURL&code=CODE
    b)code -> token -> openid -> session.qq
    c)重定向到 ORIGINALURL
*/
router.get("/loan/qqauth", function(req, res, next){
    var query= req.query,
        code= query.code,
        qurl= query.qurl,
        state= "",
        redirect_uri = encodeURIComponent(QQ_util.getRedirectUrl(req, res, next, qurl) );
    if(!qurl){
        return res.end("--N/A--");
    }
    //授权回来的页面
    var _tokenArgs={
        client_id: config.walletQQ.appId,
        client_secret: config.walletQQ.appKey,
        code: code,
        redirect_uri: redirect_uri
    };
    qq_ctr.getAccessTokenByCode(_tokenArgs, function(err, json){
        req.session.qq= {
            openid: 0,
            t: +new Date()
        };
        if(!json.error){
            var _openIdArgs= {
                access_token: json.access_token
            };
            qq_ctr.getOpenIdByAccessToken(_openIdArgs,function(err2, json){
                if(!json.error){
                    req.session.qq.openid= json.openid
                }
                req.session.save();
                return res.redirect(qurl);
            });
        }else{
            req.session.save();
            return res.redirect(qurl);
        }
    });
});

/**
    领取qq红包页面
    a)
    b)
 */
router.get('/loan/activity/wallet/qq', function(req, res, next){
    var query=req.query,
        //code 为重定向登录页面返回的code信息， auth_code为腾讯直传的code信息，优先拿登录页返回的
        queryCode= query.code || query.auth_code || null,
        //qq后台得到的应用参数和一些硬编码的值
        qqAppData=config.walletQQ;
        //后台需求的参数，暂缺参数openId，accessToken，phone通过前端页面获取和传递
        postParam = {
            pack_id: query.pack_id || null,
            business: query.business || qqAppData.business,
            card_id: qqAppData.cardId,
            state: typeof(query.state || '')=='object'?query.state[0]:query.state,
            signature: query.signature || null
        };

    //操作cookie的方法   
    var cookieAction={
        //设置cookie
        setAuth: function(obj,days,isHttpOnly){
            days=days?days*24*60*60*1000:0;
            isHttpOnly=!!isHttpOnly;
            for(var key in obj)
                if(key && obj[key])
                    res.cookie(key, obj[key], {maxAge:days, path:'/', httpOnly:isHttpOnly});
        },
        //清除Cookie
        clearAuth: function(){
            res.cookie("openId", "", {maxAge:0});
            res.cookie("accessToken", "", {maxAge:0});
        },
        getAuth:function(){
            return {
                openId: req.cookies.openId || null,
                accessToken: req.cookies.accessToken || null
            }
        }
    };
    
    //如果cookie已失效，则清除
    if(req.cookies.openId){
        if('undefined' === (typeof req.cookies.openId)){
            cookieAction.clearAuth();
        }
    }

    /**
        逻辑说明：
        1）判断有无cookie信息，有：免登陆，无：步骤2
        2）判断有无code信息，有：直接根据code拿openid ， 无：页面转向登录页，授权完回来便得到了code信息
    */
    var redirectUrl=encodeURIComponent(config.domain+ "/loan/activity/wallet/qq?"+getParamByJson(postParam));
    //判断有无cookie信息
    if(req.cookies.openId && req.cookies.accessToken){
        _render(true);
    }else{
        //code信息用于获取用户tooken和openid信息，存入cookie
        if(queryCode){
            //获取用户tooken和openid
            var _userCookieData={},//用于保存cookie的数据源
                isSave=false;   //读取完了是否要存入cookie

            //以下为获取token和openid的参数声明
            var _tokenArgs={
                    client_id: qqAppData.appId,
                    client_secret: qqAppData.appKey,
                    code: queryCode,
                    redirect_uri: encodeURIComponent(config.domain+ "/loan/activity/wallet/qq?_wv=1")
                },
                _openIdArgs={};
            async.parallel({
                qqTokenAuthInfo: function(fn){
                    qq_ctr.getAccessTokenByCode(_tokenArgs,function(err,json){
                        if(!json.error){
                            _userCookieData.accessToken = _openIdArgs.access_token = json.access_token; //存入token数据和赋值给openid的参数
                            async.parallel({
                                qqOpenIdAuthInfo: function(fn2){
                                    qq_ctr.getOpenIdByAccessToken(_openIdArgs,function(err2,json){
                                        if(!json.error){
                                            isSave=true;                        //后面用于开启保存
                                            _userCookieData.openId=json.openid; //存入appid数据
                                            fn2(null, null);
                                        }else{
                                            fn2(json.error, null);
                                        }
                                    });
                                }
                            }, function (errCode, result2) {
                                fn(errCode, null);
                            });
                        }else{
                            fn(json.error,null);
                        }
                    });
                }
            }, function (errCode, result) {
                if(errCode){
                    if(/^1000(18|19|20|21|17|16)$/.test(errCode))
                        return res.redirect(getRedirectUrl());
                }else{
                    if(isSave)
                        cookieAction.setAuth(_userCookieData,60, false); //存入cookie
                }
                _render(isSave);
            });
        }else{
            res.redirect(getRedirectUrl());
        }
    }

    //当用户没有授权信息的时候，用于跳转的页面url拼接
    function getRedirectUrl(){
        var _baseUrl='',_param={};
        //以下是登录2.0的页面及参数
        _baseUrl='https://graph.qq.com/oauth2.0/authorize';
        _param={
           display: 'mobile',
           response_type: 'code',
           client_id: qqAppData.appId,
           redirect_uri: redirectUrl,
           scope: 'get_user_info',
           state: 'user_info'
        };
        return _baseUrl+'?'+getParamByJson(_param);
    }

    //拼接链接参数
    function getParamByJson(json){
        if(!json) return '';
        var _paramArr=[];
        for(var key in json)
            _paramArr.push(key+'='+json[key]);
        return _paramArr.join('&');
    }

    //_render(null, null);
    function _render(isConnectErr){
        res.render("loan/activity/wallet/qq",{
            title: "QQ红包",
            pageName: "walletQQ",                   //暂定用于业务判断
            postParam: postParam || {},             //用于后台领券的参数
            qqUser: cookieAction.getAuth(),
            pageData: walletQQPageData.getData('receive'),   //用于页面文案的显示
            isError: !isConnectErr
        });
    }
});

//用于QQ红包的配置页面显示的文案
var walletQQPageData={
    //基类调取页面文案数据的方法，封装状态值和数据
    getData:function(key){
        var _data=this[key];
        return {
            status: !!_data,
            data: _data || {}
        };
    },
    //=====以下为页面显示的静态文案=======
    'receive': {
        title: '恭喜获得萌店跨年红包',
        img: '/imgs/vd_392.png',
        icoName: '萌店',
        price: '20元红包',
        type: '可用于购买萌店平台任意商品',
        date: '有效期至2016-01-15',
        btnName: '立即领取',
        rule: '1. 红包为现金抵用券，每笔订单满128元可用，全场通用；<br/>2. 使用有效期至 2016-01-18，逾期作废；<br/>3. 单笔订单红包不可叠加使用，可与店铺优惠同时使用；<br/>4. 需在萌店APP内使用，红包存放在领取红包的手机号账户卡包内；<br/>5. 对此红包活动，萌店享有法律范围内的解释权。',
        bottomTip: '更多跨年惊喜尽在萌店  GO',
        bottomTipLink: 'https://m-app.vd.cn/open?pkgname=com.hs.yjseller&ckey=CK1295448462798'
    },
    'download':{
        title: '恭喜获得萌店跨年红包',
        img: '/imgs/vd_392.png',
        icoName: '萌店',
        price: '20元红包',
        type: '可用于购买萌店平台任意商品',
        date: '有效期至2016-01-15',
        btnName: '立即使用',
        rule: '1. 红包为现金抵用券，每笔订单满128元可用，全场通用；<br/>2. 使用有效期至 2016-01-18，逾期作废；<br/>3. 单笔订单红包不可叠加使用，可与店铺优惠同时使用；<br/>4. 需在萌店APP内使用，红包存放在领取红包的手机号账户卡包内；<br/>5. 对此红包活动，萌店享有法律范围内的解释权。',
        bottomTip: '更多跨年惊喜尽在萌店  GO',
        bottomTipLink: 'https://m-app.vd.cn/open?pkgname=com.hs.yjseller&ckey=CK1295448462798'
    }
};
/******************************************************************************************
    pv& uv统计
******************************************************************************************/
function catchRender(req, res, _next){
     var render = res.render,
        next = function(){
            res.render = function(view, options, fn){
                options.isLogin= req.session.user.mobile>1000;
                render.apply(res, arguments);
                statistics.invoke(req, res, _next, {
                    phraseType: "pageshow",
                    pageType: options.pageName,
                    productId: options.productId||-1,
                    wp_goodsId: -1,
                    productType: -1,
                    extendKV: options.extendKV
                });
                //
                var _statistics= options.statistics|| {};
                new Statistics2().invoke(req, res, _next, {
                    action: {
                        elementid: "pv",
                        eventtype: "view"
                    },
                    page: {
                        pagename: options.pageName
                    },
                    business: _statistics.business
                });
            }
            _next();
        };
    next();
}

module.exports = router;