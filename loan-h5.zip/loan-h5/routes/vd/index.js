var router=	   		 require("./router");
	//router_activity= require("./activity"),
	//router_special=  require("./special"),
	//router_wallet=	 require("./wallet"),
	//router_indiana= require("./indiana"),
	//router_venue= require("./venue"),
	//router_recommend=require("./recommend");
/*	router_newcomer= require("./newcomer");
	router_hotrecommend= require("./hotrecommend");*/

module.exports= router;