var express = require('express'),
	router = express.Router();

module.exports= router;