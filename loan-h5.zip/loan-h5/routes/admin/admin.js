/**
	买家模块
	author:intpay
	email:eric@weimob.com
	date:2015/01/30
**/
var router = require("./router"),
    logger = require("../../utils/logger"),
    _JSON = require("querystring"),
    crypto = require("crypto"),
    events = require('events'),
    url = require("url"),
    querystring = require("querystring"),
    user_ctr = require("../../controllers/user"),
    User = require("../../models/user"),
    config = require('../../utils/config');



/* 帮助类接口 */
router.all('/admin/:type?', function(req, res, next) {
    var type = req.params.type;
    if("usr" == type){
        var args = {
            user_id : req.body.user_id,
            nick_name : req.body.nick_name,
            mobile : req.body.mobile,
            qq_num: req.body.qq_num,
            bind_mobile : req.body.bind_mobile
        };
        user = new User();
       
        user.modify(args, function(err, result){
            res.end("<div style='color:red;'>"+JSON.stringify(err) +"</div>"+ JSON.stringify(result) );
        });
    }else if(1 == type){
        req.session.user = null;
        res.end("success");
    }else{
        res.render("admin/help", {
            title: "管理员",
            pageName:"help",
            shopInfo: req.session.shopInfo||{},
            userInfo: req.session.user||{}
        });
    }
});

module.exports = router;