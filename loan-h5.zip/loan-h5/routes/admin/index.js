var router= 	  require("./router"),
	router_admin= require("./admin");

module.exports= router;