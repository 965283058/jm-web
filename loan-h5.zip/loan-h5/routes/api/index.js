var router=			require("./router"),
	router_api=		require("./api"),
	router_util=	require("./util"),


	router_activity= require("./venue"),
    router_user = require("./user");

module.exports= router;