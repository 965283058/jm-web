var router=             require('./router'),
    tools = require("../../utils/tools");


router.post('/api/venue/getVenueConfig', function (req, res) {
    //var result = [{id:1,type:1,goods:{id:1,title:"商品1"}},{id:2,type:2,goods:{id:2,title:"商品2"}},
    //    {id:3,type:1},{id:4,type:1},{id:5,type:1},{id:6,type:1},{id:7,type:1},{id:8,type:1}
    //];
    activity_ctr.getVenueList('',function(err, result){
        if(result.code=='0'){
            tools.rendJSON(req, res, result);
        }
    });
})
router.post('/api/venue/getVenueGoods', function (req, res) {
    var args = req.body;
    activity_ctr.getVenueTheme(args,function(err, result){
        if(result.code=='0'){
            tools.rendJSON(req, res, result);
        }
    });
    //tools.rendJSON(req, res, result);
});
module.exports = router;