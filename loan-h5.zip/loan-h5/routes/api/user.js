/**
 * 用户接口模块
 *
 * @file /routes/api/user.js
 * @author Henry(jiabin.chen@weimob.com)
 */

var router = require('./router'),
    // config= require('../../utils/config'),
    tools = require("../../utils/tools");

/*******************************
 获取用户收货地址信息
 ********************************/
router.get('/api/user/getAddressList', function (req, res) {
    var query = req.query,
        addressId = req.query.addressId,
        from = req.query.from,
        userid = req.session.user.id,
        yunjie_id = req.session.user.yunjie_id,
        hasHaitao = req.query.hasHaitao,
        idType = req.query.idType;
    address_ctr.getList({
        user_id: userid,
        yunjie_id: yunjie_id
    }, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result);
        }
    })
})

router.post('/api/user/deleteAddress', function (req, res) {
    address_ctr.delete({
        address_id: req.body.address_id,
        user_id: req.session.user.id,
        yunjie_id: req.session.user.yunjie_id
    }, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result);
        }
    })
})

router.post('/api/user/updateAddress', function (req, res) {
    var query = req.body,
        selectedId = query.selectedId,
        userid = req.session.user.id,
        yunjie_id = req.session.user.yunjie_id;
    address_ctr.update({
        user_id: userid,
        yunjie_id: yunjie_id,
        receiver: query.receiver,
        mobile: query.mobile,
        address_id: parseInt(query.address_id),
        province: query.province,
        city: query.city,
        zone: query.zone,
        address: query.address,
        addressName: query.addressName,
        is_default: query.is_default,
        IDPhotoFront: query.IDPhotoFront,
        IDPhotoBack: query.IDPhotoBack,
        id_num: query.id_num,
        zip_code: query.zip_code
    }, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result);
        }
    })
})

module.exports = router;