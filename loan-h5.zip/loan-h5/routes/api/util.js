"use strict";
/************************************
	通用api
	author:intpay
	email:eric@weimob.com
	date:2016.04.08
************************************/
var router=             require('./router'),
    config=             require('../../utils/config'),
    webim_ctr=          require('../../controllers/webIm'),
	tools=              require("../../utils/tools"),
	crypto=             require('crypto'),
    Statistics2=        require("../../utils/statistics2"),
    verifyCodeHelper=   require("../../utils/verifyCodeHelper"),
    geetest=            require('geetest')(config.geetestKeys.private, config.geetestKeys.public),
    QQVcode_utl=        require("../../utils/qqVcode"),
    admin=              require("../../controllers/admin");


function encrypt(str, secret) {
    var cipher = crypto.createCipher('aes192', secret);
    var enc = cipher.update(str,'utf8','hex');
    enc += cipher.final('hex');
    return enc;
}
function decrypt(str, secret) {
    var decipher = crypto.createDecipher('aes192', secret);
    var dec = decipher.update(str,'hex','utf8');
    dec += decipher.final('utf8');
    return dec;
}

/**
    校验第三方风控
 */
var validator= {
    handleEvent: function(req, res, next){
        var query= req.body|| {},
            mode= query.mode;
        if("h5NewLogin"=== mode){
            var _validate= query.validate;
            if(_validate){
                return validator[{"geetest": "fkv_jiyan", "qq": "fkv_qq"}[_validate.type] ](req, res, next);
            }else{
                next();
            }
        }else if("h5SearchOrder"=== mode){
            return validator.fkv_tencent(req, res, next);
        }else{
            req.body.verify_valid= true;
            next();
        }
    },
    fkv_tencent: function(req, res, next){
        var query= req.body|| {},
            ticket= query.data.ticket,
            csnonce= query.data.csnonce;
        req.body.verify_valid= false;
        if(ticket){
            var args= {
                ticket: ticket,
                csnonce: csnonce,
                userIp: tools.getClientIp(req)
            };
            verifyCodeHelper.checkVcode(args, function(err, result){
                if(0=== result.code){
                    req.body.verify_valid= true;
                    next();
                }else{
                    var data= {
                        code:1001,
                        message: "验证码校验失败！",
                        data:null
                    };
                    return tools.rendJSON(req, res, data);
                }
            });
        }else{
            next();
        }
    },
    fkv_jiyan: function(req, res, next){
        var query= req.body,
            _validate = query.validate;
        if(_validate){
            var args= {
                challenge: _validate.geetest_challenge,
                validate: _validate.geetest_validate,
                seccode: _validate.geetest_seccode
            };
            geetest.validate(args, function(err, result)  {
                if(err|| !result){
                    req.body.verify_valid= false;
                     var data= {
                        code:1001,
                        message: "风控验证码校验失败！",
                        data:null
                    };
                    req.body.passCode= "";
                    return tools.rendJSON(req, res, data);
                }else{
                    req.body.verify_valid= true;
                    req.body.passCode = validator.encodePassCode(req.body.passCode);
                    next();
                }
            })
        }else{
            next();
        }
    },
    fkv_qq: function(req, res, next){
        var query= req.body,
            _validate = query.validate;
        if(_validate){
            var args= {
                cip: res.locals.config.clientIp,
                businessId: parseInt(config.env.slice(0, 2), 32),
                ticket: _validate.ticket
            };
            QQVcode_utl.checkVcode(args, function(err, result){
                if(err){
                    req.body.verify_valid= false;
                    var data= {
                        code:1001,
                        message: "风控验证码校验失败！",
                        data:null
                    };
                    req.body.passCode= "";
                    return tools.rendJSON(req, res, data);
                }else{
                    req.body.verify_valid= true;
                    req.body.passCode = validator.encodePassCode(req.body.passCode);
                    next();
                }
            });
        }else{
            next();
        }
    },
    init: function(args, fn){
        if(1== args.type){
        //极验
            geetest.register(function(err, challenge){
                var data= {
                    type:       "geetest",
                    err:        err,
                    challenge:  challenge
                };
                fn(data);
            });
        }else{
            var _args= {
                cip: args.clientIp,
                businessId: parseInt(config.env.slice(0, 2)+ "02", 32)
            };
            QQVcode_utl.createVcode(_args, function(err, result){
                var data= {
                    type:   "qq",
                    err:    err,
                    url:    result.url
                };
                fn(data);
            });
        }
    },
    encodePassCode: function(passCode){
        var content = passCode + "h5$s7df9sdf9ss9r8gs#{}|:~$",
            md5 = crypto.createHash('md5');
        return (md5.update(content), md5.digest('hex')); 
    },
    encodeSign: function(){

    }
};

/**
    验证手机号萌店注册状态
    这是一个复合型的接口，如果有wid，要查询对应的店铺信息，如果有师傅，查询师傅的店铺信息

    @param {string} mobile
    @return void

    a)暂时只用在邀请合伙人页面
    b)...
*/
router.post("/api/util/verifyMobilePartner", function(req, res, next){
    var query=  req.body,
        mobile= query.phone,
        _decrypt= query.decrypt,
        args=   {
            mobile:     mobile,
            is_send_code:    0,
            clientIp: tools.getClientIp(req)
        },
        partnerData= {

        }; //最终返回给web的数据

    if(1== _decrypt){
        validator.fkv_qq(req, res, function(){
            var verify_valid= req.body.verify_valid,
                result= {code: 0, data: {type: "decrypt", edata: "", message: null} };

            try{
                result.data.edata= JSON.parse( decrypt(query.edata, "sdf234df") );
            }catch(e){
                result.code= 1001;
                result.message= "未知错误，请稍候重试。";
            }
            return tools.rendJSON(req, res, result );
        });
    }

    function getShopInfo(args){
        return new Promise(function(resolve, reject){
            shop_ctr.getDetail(args, function(err, result){
                if(err){
                    return reject(err);
                }
                resolve(result);
            });
        });
    }

    function getQQValidate(){
        return new Promise(function(resolve, reject){
            validator.init({type: 2, clientIp: res.locals.config.clientIp}, function(thirdValidation){
                resolve(thirdValidation);
            });
        });
    }
    new Promise(function(resolve, reject){
        user_ctr.checkMobile2(args, function(err, result) {
            if(err){
                reject(err);
            }else if(0!= result.code){
                reject(new Error(result.message) );
            }else{
                partnerData.base= {
                    wid: result.data.wid,
                    mode: result.data.mode
                };
                resolve(result.data);
            }
        });
    }).then(function(data){
        //当前手机号，如果已经注册，则查询他的店铺信息
        if("register"!==data.mode){
            partnerData.type= "encrypt";
            return Promise.all([getShopInfo({wid: data.wid}), getQQValidate() ]).then(function(datas){
                partnerData.thirdValidation= datas[1];
                return datas[0];
            });
        }else{
            return data;
        }
    }).then(function(data){
        //当前手机号，如果已经有师傅，则查询师傅的店铺信息
        //自己的店铺信息
        partnerData.self= {
            shop_id: data.shop_id,
            shop_key: data.nickname,
            shop_nickname: data.nickname
        };
        if(parseInt(data.master_shop_id) ){
            return getShopInfo({shop_id: data.master_shop_id});
        }else{
            return null;
        }
    }).then(function(data){
        //合伙人信息
        data&& (partnerData.partner= {
            shop_id: data.shop_id,
            title: data.title
        });
        _render(req, res, {code: 0, data: partnerData, message: ""});
    }).catch(function(e){
        if(partnerData.base){
            _render(req, res, {code: 100, data: partnerData, message: e});
        }else{
            _render(req, res, {code: 1001, data: null, message: e.toString()});
        }
    });

    function _render(req, res, result){
        if(1001!== result.code&& "register"!== result.data.base.mode){
            result.data= {
                type: "encrypt",
                edata: encrypt(JSON.stringify(result.data), "sdf234df"),
                thirdValidation: result.data.thirdValidation
            }
        }
        tools.rendJSON(req, res, result);
    }
});

/*  */
router.post('/api/util/checkQCode', function(req, res, next){
    var query= req.body,
        args= {
            cip: res.locals.config.clientIp,
            businessId: parseInt(config.env.slice(0, 2), 32),
            ticket: query.ticket
        };
    QQVcode_utl.checkVcode(args, function(err, result){
        if(err){
            result= {
                code: 100,
                message: "unknow err"
            };
        }else{
            var content = query.vcode + "h5$s7df9sdf9ss9r8gs#{}|:~$";
            var md5 = crypto.createHash('md5');
            md5.update(content);
            result.vvcode = md5.digest('hex');
        }
        return tools.rendJSON(req, res, result);
    });
});

/**
    获取邀请合伙人的链接
 */
router.get('/api/util/partnerInvite', function(req, res, next){
    var shop_id= req.session.shopInfo.shop_id;
    activity_ctr.getActivity(function(err, result){
        if(err){
                reject(err);
        }else if(0!= result.code){
                tools.rendJSON(req, res, {code: 1001, data: null, message: err.toString()});
        }else{
            var activeId= result.data.activeId|| -1;
            //生成用于验证url的签名
            var params = {
                'vid': shop_id.toString(),
                'pop_id': activeId.toString()
            };
            var content = JSON.stringify(params) + config.signKey;
            var md5 = crypto.createHash('md5');
            md5.update(content);
            var secret = md5.digest('hex');
            tools.rendJSON(req, res, {code: 0, data: "vid="+ shop_id+ "&pop_id="+ activeId+ "&encrypt="+secret, message: "success"});
        }
    });
});


/**
    用于统计
    简单的 获取数量
    key= "huodong20150510"
    sign = md5(key+ "key001394jdsfkdsf")
 */
router.get("/api/util/statis/get", validKey001, function(req, res, next){
    var query= req.query,
        sign= query.sign,
        key= query.key;
    var val= {
        key: key,
        sum: 0
    };
    admin.getVal(val, function(err, result){
        var _result= {};
        if(err){
            _result= {
                code: 1000,
                data: result,
                message: err
            };
        }else{
            _result= {
                code: 0,
                data: result,
                message: "success"
            };
        }
        tools.rendJSON(req, res, _result);
    });
});


/**
    用于统计
    数量累加
 */
router.get("/api/util/statis/add", validKey001, function(req, res, next){
    var query= req.query,
        sign= query.sign,
        key= query.key;
    var val= {
        key: key,
        sum: 0
    };
    new Promise(function(resolve, reject){
        admin.getVal(val, function(err, result){
            if(err){
                reject(err);
            }else{
                var sum= (parseInt(result.sum)||0) +1;
                resolve(sum);
            }
        });
    }).then(function(sum){
        val.sum= sum;
        admin.setVal(val, function(err, result){
            tools.rendJSON(req, res, {code:0, data: val, message: "sucess" });
        });
    }).catch(function(err){
        tools.rendJSON(req, res, {code:1000, data: null, message: err});
    });
    
});

function validKey001(req, res, next){
    var query= req.query,
        sign= query.sign,
        key= query.key;
    if(!sign || !key){
        return tools.rendJSON(req, res, {code:1000, data: null, message: "sign or key is empty"});
    }else{
        var content= key+ "key001394jdsfkdsf",
            md5= crypto.createHash('md5'),
            _sign= (md5.update(content),  md5.digest('hex')).slice(0, 5);
        if(_sign!== sign){
            tools.rendJSON(req, res, {code: 1000, data: null, message: "sign or key is wrong"});
        }else{
            next();
        }
    }
}

/**
    上传图片
 */
router.post('/api/utils/uploadimage', function (req, res, next) {
    user_ctr.uploadImage({
        uploadimage: req.body.imgfile
    }, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, {code: 1000, message: "上传失败", data: null});
        } else {
            tools.rendJSON(req, res, result || {});
        }
    });
});
/*领取优惠券*/
router.post("/api/activity/wallet/getcoupons/receive",function(req, res, next){
     var query= req.body,
        phone= query.phone,
        _decrypt= query.decrypt,
        channel_id=query.channel_id;
    var  args= {
            phone: query.phone,
            mobile: query.phone, //兼容
            ip:tools.getClientIp(req),
            mode: "1111-youhuiquan",
            bizType: 1,
            sceneId: 16
        };

    if(1== _decrypt){
        validator.fkv_qq(req, res, function(){
            var verify_valid= req.body.verify_valid;
            if(verify_valid){
                receiveCopuons();
            }
            else{
                return tools.rendJSON(req, res, {code: 0, data: {type: "decrypt", message: "风控校验失败,请稍后重试。"} } );
            }
        });
    }
    else{
         activity_ctr.mobileRiskCheck(args, function(err, result){
            if (err) {
                var result1={code:1000, data:null, message: "风控校验失败,请稍后重试。"}
                return tools.rendJSON(req, res, result1 || {});
            } else {
                result.data= result.data||{};//兼容
                if(result.data.checkLevel==-1){
                    var result1={code:1000, data:null, message: "风控校验失败,请稍后重试。"}
                    return tools.rendJSON(req, res, result1 || {});
                }
                else if(result.data.checkLevel==0){
                   receiveCopuons();
                }
                else{
                    if(result.data.checkLevel>4){
                        var result1={code:1001, data:null, message: "您的账号存在风险,请致电萌店<br>客服 400-090-8822"}
                        return tools.rendJSON(req, res, result1 || {});
                    }
                    else{
                        var type = 1;
                        if(result.data.checkLevel==3||result.data.checkLevel==4){
                            type=2
                        }
                        validator.init({type: type, clientIp: res.locals.config.clientIp}, function(thirdValidation){
                            result= {
                                code:-2,
                                data:{
                                    type: "encrypt",
                                    thirdValidation: thirdValidation
                                },
                                message:"风控校验"
                            }
                            return tools.rendJSON(req, res, result || {});
                        });
                    }
                }
                
            }
        });   
    }
    function receiveCopuons(){
         activity_ctr.receiveCoupons({channel: channel_id, phone: phone}, function(err, result){
            if (err) {
                console.log(err);
            } else {
                return tools.rendJSON(req, res, result || {});
            }
        });  
    }

});

module.exports = router;
//end