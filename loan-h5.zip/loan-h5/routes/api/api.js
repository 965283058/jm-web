/************************************
	接口模块
	author:intpay
	email:eric@weimob.com
	date:2014/12/16
************************************/
var router = require('./router'),
    async = require('async'),
    config= require('../../utils/config'),
    proxy = require("../../utils/proxy"),

    user_ctr = require('../../controllers/user'),

    location_ctr = require('../../controllers/location'),
    webim_ctr = require('../../controllers/webIm'),

	tools = require("../../utils/tools"),
	crypto = require('crypto'),



    statistics = require("../../utils/statistics"),
    Statistics2 = require("../../utils/statistics2"),
    statisticsPartner = require("../../utils/statisticsPartner"),
    verifyCodeHelper= require("../../utils/verifyCodeHelper"),
    geetest = require('geetest')(config.geetestKeys.private, config.geetestKeys.public),
    QQVcode_utl= require("../../utils/qqVcode"),
    mduc = require('../../utils/mduc'),
    redisHelper= require("../../models/redisHelper"),
    url= require('url');


/**
    校验第三方风控
    h5CouponExchange: app 内兑换券
    1010-coupon: 双十大促券
    tuan-coupon: 拼团分享券
 */
var validator= {
    handleEvent: function(req, res, next){
        var query= req.body|| {},
            mode= query.mode;
        if("h5NewLogin"=== mode|| "h5FastLogin"=== mode|| "h5Login"=== mode || "h5CouponExchange"=== mode || "1010-coupon"===mode|| "tuan-coupon"=== mode){
            var _validate= query.validate;
            if(_validate){
                return validator[{"geetest": "fkv_jiyan", "qq": "fkv_qq"}[_validate.type] ](req, res, next);
            }else{
                next();
            }
        }else if("h5SearchOrder"=== mode){
            return validator.fkv_tencent(req, res, next);
        }else{
            req.body.verify_valid= true;
            next();
        }
    },
    fkv_tencent: function(req, res, next){
        var query= req.body|| {},
            ticket= query.data.ticket,
            csnonce= query.data.csnonce;
        req.body.verify_valid= false;
        if(ticket){
            var args= {
                ticket: ticket,
                csnonce: csnonce,
                userIp: tools.getClientIp(req)
            };
            verifyCodeHelper.checkVcode(args, function(err, result){
                if(0=== result.code){
                    req.body.verify_valid= true;
                    next();
                }else{
                    var data= {
                        code:1001,
                        message: "验证码校验失败！",
                        data:null
                    };
                    return tools.rendJSON(req, res, data);
                }
            });
        }else{
            next();
        }
    },
    fkv_jiyan: function(req, res, next){
        var query= req.body,
            _validate = query.validate;
        if(_validate){
            var args= {
                challenge: _validate.geetest_challenge,
                validate: _validate.geetest_validate,
                seccode: _validate.geetest_seccode
            };
            geetest.validate(args, function(err, result)  {
                if(err|| !result){
                    req.body.verify_valid= false;
                     var data= {
                        code:1001,
                        message: "风控验证码校验失败！",
                        data:null
                    };
                    req.body.passCode= "";
                    return tools.rendJSON(req, res, data);
                }else{
                    req.body.verify_valid= true;
                    req.body.passCode = validator.encodePassCode(req.body.passCode);
                    next();
                }
            })
        }else{
            next();
        }
    },
    fkv_qq: function(req, res, next){
        var query= req.body,
            _validate = query.validate;
        if(_validate){
            args= {
                cip: res.locals.config.clientIp,
                businessId: parseInt(config.env.slice(0, 2), 32),
                ticket: _validate.ticket
            };
            QQVcode_utl.checkVcode(args, function(err, result){
                if(err){
                    req.body.verify_valid= false;
                    var data= {
                        code:1001,
                        message: "风控验证码校验失败！",
                        data:null
                    };
                    req.body.passCode= "";
                    return tools.rendJSON(req, res, data);
                }else{
                    req.body.verify_valid= true;
                    req.body.passCode = validator.encodePassCode(req.body.passCode);
                    next();
                }
            });
        }else{
            next();
        }
    },
    init: function(args, fn){
        if(1== args.type){
        //极验
            geetest.register(function(err, challenge){
                var data= {
                    type:       "geetest",
                    err:        err,
                    challenge:  challenge
                };
                fn(data);
            });
        }else{
            var _args= {
                cip: args.clientIp,
                businessId: parseInt(config.env.slice(0, 2)+ "02", 32)
            };
            QQVcode_utl.createVcode(_args, function(err, result){
                var data= {
                    type:   "qq",
                    err:    err,
                    url:    result.url
                };
                fn(data);
            });
        }
    },
    encodePassCode: function(passCode){
        var content = passCode + "h5$s7df9sdf9ss9r8gs#{}|:~$",
            md5 = crypto.createHash('md5');
        return (md5.update(content), md5.digest('hex')); 
    },
    encodeSign: function(){

    }
};



/**
    a)强制登录
    b)需要限制的页面包括用户，订单，购物车，收藏（ajax）
    c)非限制的页面
        1，登录，登出
        2，执行登录的页面
        3，获取运费
*/
router.all(/\/api\/(user|order|shopcart)\/.+/, function(req, res, next){
    var reg= /(login|logout|wpFreight|applogin)$/;
    var _pathname= url.parse( req.originalUrl).pathname;
    if(reg.test(_pathname)|| req.session.user.mobile>1000){
        next();
    }else{
        return tools.rendJSON(req, res,{code:1000, message:"请先登录" });
    }
});
/**
 * 获取积攒中的点赞数量
 */
router.post('/api/getPromotionVoteTheme', function(req, res, next){
    var args = req.body;

    // if(req.session.user.shop_id&& (req.session.user.shop_id=== args.current_shop_id) ){
    //     return tools.rendJSON(req, res, {code:1000, message:"您不能将自己的商品加入购物车哦！", data:[]});
    // }
    console.info(args)
    activity_ctr.getPromotionVoteTheme(args, function(err, data){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, data||{});
        }
    });
});

/* 编辑购物车 作废？ */
router.post('/api/shopcart/edit', function(req, res, next){
    var args = {
        user_id: req.session.user.id,
        yunjie_id: req.session.user.yunjie_id,
        cart_data: req.body.data,
        productId: req.body.productId,
        current_shop_id: req.body.current_shop_id
    };

    // if(req.session.user.shop_id&& (req.session.user.shop_id=== args.current_shop_id) ){
    //     return tools.rendJSON(req, res, {code:1000, message:"您不能将自己的商品加入购物车哦！", data:[]});
    // }

    shopcart_ctr.edit(args, function(err, data){
        if(err){
            console.log(err);
        }else{
            if(args.productId){
                statistics.invoke(req, res, next, {
                    phraseType: "cart",
                    pageType: "cart",
                    productId: args.productId,
                    wp_goodsId: req.body.wp_goods_id,
                    productType: req.body.product_type
                });
            }
            tools.rendJSON(req, res, data||{});
        }
    });
});

/* 购物车列表（不包含商品详细信息）作废？ */
router.all('/api/shopcart/detail', function(req, res, next){
    var args = {
        user_id: req.session.user.id,
        yunjie_id: req.session.user.yunjie_id
    };
	shopcart_ctr.getSimpleList(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result||{});
        }
    });
});

/* 购物车列表 包含商品详细 作废？*/
router.all('/api/shopcart/list', function(req, res, next){
    var args = {
        user_id: req.session.user.id,
        yunjie_id: req.session.user.yunjie_id
    };

    shopcart_ctr.getList(args, function(err, result){
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result||{});
        }
    });
});


/* 提交订单前先拆单 --------新接口已改成下面的 cartSplitOrders */  
router.post('/api/order/cartOrders', function(req, res, next){
    var args = {
        goods_data: ("object" == typeof(req.body.goods_data) )?req.body.goods_data: JSON.parse(req.body.goods_data),
        city_id: req.body.city_id,
        current_shop_id: req.body.current_shop_id,
        from_where:req.body.from_where || 0,
        user_id: req.session.user.id
    };
    // if(req.session.user.shop_id&& (req.session.user.shop_id=== args.current_shop_id) ){
    //     return tools.rendJSON(req, res, {code:1000, message:"您不能将自己的商品加入购物车哦！", data:[]});
    // }
    order_ctr.cartOrders(args, function(err, result){
       if(err){
            console.log(err);
       }else{
            tools.rendJSON(req, res, result||{});
       }
    });
});

/* 新拆单接口 -- 提交订单前先拆单*/
router.post('/api/order/cartSplitOrders', function(req, res, next){
    var args = {
        goods_data: ("object" == typeof(req.body.goods_data) )?req.body.goods_data: JSON.parse(req.body.goods_data),
        city_id: req.body.city_id,
        province_id: req.body.province_id,
        area_id: req.body.area_id,
        current_shop_id: req.body.current_shop_id,
        from_where:req.body.from_where || 0,
        wid: req.session.user.wid,
        shop_id:req.session.user.shop_id || ''
        //user_id:req.session.user.id || ''
    },
    rds= ~~req.body.rds; //是否使用rds 缓存数据
    //1, 对goods_data中的share_shop_id做容错 2,直销商品不传share_shop_id
    for (var i = 0, ci; ci= args.goods_data[i]; i++) {
        if (!Number(ci.share_shop_id)|| 2== ci.goods[0].sellType ) {
            ci.share_shop_id = 0;
        }
    }

    if(req.session.user.shop_id&& (req.session.user.shop_id=== args.current_shop_id) ){
        return tools.rendJSON(req, res, {code:1000, message:"您不能将自己的商品加入购物车哦！", data:[]});
    }
    //
    function cacheCheckData(result){
        var user= req.session.user;
        var __checkInfo = {
            goodsList: result.data,
            from: 'detail'
        },
        rdbk= `1000-md-${user.wid}-check`;
        if(__checkInfo.goodsList && 1==__checkInfo.goodsList.length){
            __checkInfo.goodsList=__checkInfo.goodsList[0];
        }else{
             result.pageType= 1; // 1: balanceCenter, 0: orderCheck
        }
        return new Promise(function(resolve, reject){
             redisHelper.acquire(function(err, client){
                client.set(rdbk, JSON.stringify(__checkInfo), function(err, result2){
                    if(err){
                        reject(err);
                    }else{
                        result.rdsOK= result2;
                        resolve(result);
                    }
                });
                client.expire(rdbk, 60*30); //cache 30 minutes
             });
        });
    }
    //
    new Promise(function(resolve, reject){
         order_ctr.cartSplitOrders(args, function(err, result){
            if(err){
                reject(err);
            }else{
                resolve(result);
            }
         });
    }).then(function(result){
        if(rds){
            return cacheCheckData(result);
        }else{
            return result;
        }
    }).then(function(result){
        tools.rendJSON(req, res, result);
    }).catch(function(err){
        tools.rendJSON(req, res, {code: 1000, data: null, message: err});
    });
    // order_ctr.cartSplitOrders(args, function(err, result){
    //    if(err){
    //         console.log(err);
    //    }else{
    //         tools.rendJSON(req, res, result||{});
    //    }
    // });
});

/* 提交订单 */
router.post('/api/order/add', validator.handleEvent, function(req, res, next){
    var args = req.body.data,
        user = req.session.user,
        userId = user.id;

    // args.user_id = userId == -1 ? '' : userId;
    if(userId != -1){
        args.user_id = userId;
    }
    args.yunjie_id = user.yunjie_id;
    args.shop_id = "";//req.session.shopInfo.shop_id; //eric 不能这样用
    args.verify_valid= req.body.verify_valid;
    args.clientIp= tools.getClientIp(req);
    if(res.locals.config.isWeixin){
        var we_cur= req.session.wechat.current;
        args.wechat_id= we_cur.openid;
        args.src_platform_type= 1;
        args.src_platform_id= we_cur.AppID;
    }

    //1, 对goods_data中的share_shop_id做容错 2,直销商品不传share_shop_id
    for (var i = 0, ci; ci= args.order_data[i]; i++) {
        if (!Number(ci.share_shop_id)|| 2== ci.goods[0].sellType ) {
            ci.share_shop_id = 0;
        }
    }
    
    order_ctr.add(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            if (!result.data) { //容错，防止data为null时前端页面报错
                result.data = {};
            }
            tools.rendJSON(req, res, result||{});
            statistics.invoke(req, res, next, {
                phraseType: "order",
                pageType: "order",
                productId: result.data && result.data.payment_no, //兼容
                paymentNo: result.data && result.data.payment_no
            });
        }
    });
    
});


/* 提交订单（直接收款） */
router.post('/api/order/addVirtual', function(req, res, next){
    var args = req.body.data,
        user = req.session.user,
        userId = user.id;

    if(userId != -1){
        args.user_id = userId;
    }
    args.yunjie_id = user.yunjie_id;
    args.clientIp = tools.getClientIp(req);
    if(res.locals.config.isWeixin){
        var we_cur= req.session.wechat.current;
        args.wechat_id= we_cur.openid;
        args.src_platform_type= 1;
        args.src_platform_id= we_cur.AppID;
    }

    order_ctr.addVirtual(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            statistics.invoke(req, res, next, {
                phraseType: "order",
                pageType: "order",
                productId: result.data.payment_no, //兼容
                paymentNo: result.data.payment_no
            });
            tools.rendJSON(req, res, result||{});
        }
    });
});

// 支付方式接口
router.get('/api/order/paymentLists', function (req, res, next) {
    var query= req.query,
        user = req.session.user;
    var param = {
        user_id: user.id,
        yunjie_id: user.yunjie_id,
        global_pay: query.global_pay,
        payment_no: query.payment_no,
        order_no: query.order_no//,
        //sell_shop_id: ""//query.sell_shop_id|| req.session.shopInfo.shop_id //query.sell_shop_id 实际上是买家的id，只是为了兼容
    };
    param.user_id = user.id
    param.yunjie_id = user.yunjie_id;
    param.global_pay = query.global_pay;
    if(query.pay_module){
        param.pay_module = query.pay_module;
    }
    if(/(duobao)/.test(req.hostname)){
        param.appIdentifier='h5.indiana';
    }
    order_ctr.paymentLists(param, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            result.data.pay_data = result.data.pay_data.reduce(function (r, i, s) {
                if ("alipay" == i.pc_type && res.locals.config.isWeixin) {
                    //微信中禁用支付宝
                } else if (/newweipay|weipay_global|cmbcpay/.test(i.pc_type) && (req.query.denyWeixinPay && /\d+/gi.test(req.query.denyWeixinPay) )) {
                    //通过url中标记wp=0记录不能进行微信支付的sid
                } else if (/newweipay|weipay_global|cmbcpay/.test(i.pc_type) && !res.locals.config.isWeixin) {
                    //微信外禁用微支付
                } else if (/newweipay|weipay_global|cmbcpay/.test(i.pc_type) && res.locals.config.isWeixin && !req.session.wechat.openid) {
                    //微信中没有openid禁用微支付
                }else if(/newweipay|weipay_global|cmbcpay/.test(i.pc_type) && res.locals.config.isWeixin&& ("appId" in i)&& i.appId!== req.session.wechat.current.AppID ){
                    //多公众号，过滤微信
                } else {
                    r.push(i);
                }
                return r;
            }, []);
            if(0== query.is_support_bank ){
                result.data.pro_data= [];
            }
            tools.rendJSON(req, res, result || {});
        }
    });
});

// 支付接口
router.post('/api/order/pay', function(req, res, next){
    var args = req.body.data,
        userId = req.session.user.id;

    args.user_id = userId == -1 ? '' : userId;
    args.yunjie_id = req.session.user.yunjie_id;
    args.submit_shop_id = Number(args.shop_id|| req.session.shopInfo.shop_id)||args.shopId||"";
    args.wechat_id = req.session.wechat.openid ||''; // 'oE__0s1tGlKM4QlTgxjtIteEIi5Q';
    //
    if(req.session.user.ctime){
        var t = Number((req.session.user.ctime+"00000").slice(0, 13) ),
            t_str= (t= new Date(t), [t.getFullYear(), ("0"+(t.getMonth()+1)).slice(-2), ("0"+(t.getDate())).slice(-2)]).join("/");
    }else{
        var t_str= "";
    }
    //
    if(/(duobao)/.test(req.hostname)){
        args.appIdentifier='h5.indiana';
    }
    args.product_type= res.locals.config.isMobile? 4: 3;
    args.user_agent= res.locals.config.ua.match(/(.+?)\(/)[1];
    args.user_ip= res.locals.config.clientIp;
    args.register_time= t_str;

    order_ctr.pay(args, function(err, data){
        if(err){
            console.log(err);
        }else{
            statistics.invoke(req, res, next, {
                phraseType: "pay",
                pageType: "pay",
                productId: args.payment_no, //兼容
                paymentNo: args.payment_no
            });
            tools.rendJSON(req, res, data||{});
        }
    });
});

//  协议支付确认支付
router.post('/api/order/surePay', function (req, res, next) {
    var args = req.body.data;

    order_ctr.surePay(args, function (err, data) {
        if (err) {
            console.log(err);
        } else {
            statistics.invoke(req, res, next, {
                phraseType: "pay",
                pageType: "pay",
                productId: args.payment_no, //兼容
                paymentNo: args.payment_no
            });
            tools.rendJSON(req, res, data || {});
        }
    });
});

/* 取消订单 */
router.post('/api/order/cancel', function(req, res, next){
    var id = req.query.id,
        shopId = req.query.shopId,
        userid = req.session.user.id,
        type = req.query.type;

    order_ctr.cancel({
        order_no: id,
        shop_id: shopId,
        type: type,
        user_id: userid
    }, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            statistics.invoke(req, res, next, {
                phraseType: "corder",
                pageType: "corder",
                productId: id, //兼容
                orderNo: id
            });
            tools.rendJSON(req, res, result);
        }
    });
});

/* 删除订单 */
router.post('/api/order/delete', function(req, res, next){
    var id = req.query.id,
        shopId = req.query.shopId,
        userid = req.session.user.id;

    order_ctr.del({
        order_no: id,
        shop_id: shopId,
        user_id: userid
    }, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            statistics.invoke(req, res, next, {
                phraseType: "corder",
                pageType: "corder",
                productId: id, //兼容
                orderNo: id
            });
            tools.rendJSON(req, res, result);
        }
    });
});

/* 提醒发货 */
router.post('/api/order/deliver', function(req, res){
    var query = req.query,
        id = query.id,
        shopId = query.shopId,
        user = req.session.user,
        wpNo = query.wpNo === 'undefined' ? '' : query.wpNo,
        userName = user.nick_name || query.receiverName,
        userMobile = user.mobile || query.receiverMobile,
        type = query.type,
        wpAid = query.wpAid === 'undefined' ? '' : query.wpAid;

    order_ctr.deliver({
        order_no: id,
        type: type, //订单类型
        wpNo: wpNo,
        shop_id: shopId,
        wp_aid: wpAid,
        userName: userName,
        userMobile: userMobile,
        goodsName: query.gnames,
        waitTime: dateDiffDayHourMin(query.payTime, Date.now())
    }, function (err, result) {
        if (err) {
            console.log(err);
        }
        tools.rendJSON(req, res, result);
    });
});

// 计算两日期之间相差的天时分
function dateDiffDayHourMin(d1, d2) {
    if (isNaN(d1) || isNaN(d2)) {
        return '0天0时0分';
    }
    var secDiff = (d2 - d1) / 1000 | 0,
        dayDiff = 0,
        hourDiff = 0,
        minDiff = 0;
    // 天
    dayDiff = secDiff / 86400 | 0;
    secDiff = secDiff - dayDiff * 86400;
    // 时
    hourDiff = secDiff / 3600 | 0;
    secDiff = secDiff - hourDiff * 3600;
    // 分
    minDiff = secDiff / 60 | 0;

    return dayDiff + '天' + hourDiff + '时' + minDiff + '分';
}

/* 确认收货 */
router.post('/api/order/receipt', function(req, res){
    var id = req.query.id,
        shopId = req.query.shopId,
        userid = req.session.user.id;

    order_ctr.receipt({
        order_no: id,
        shop_id: shopId,
        user_id: userid
    }, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});

/**
    订单完善身份信息
 */
router.post('/api/order/identify', function(req, res, next){
    var query= req.body,
        args= {
            order_no:       query.orderNo,
            sell_shop_id:   query.shopId,
            id_num:         query.idNo,
            photo_front:    query.idpic1url,
            photo_back:     query.idpic2url,
            receiver_name:  query.receiver,
            opencrypt:      query.opencrypt,
            needIdentity:   parseInt(query.needIdentity)
        };
    var content = args.order_no+  args.sell_shop_id+ args.needIdentity+ "order-ajfworiw2343",
        md5 = crypto.createHash('md5'),
        opencrypt= (md5.update(content), md5.digest('hex') ).slice(0, 10);
    if(args.opencrypt!== opencrypt){
        var msg = "非法操作";
        if(0=== args.needIdentity){
            msg+= "(不能重复提交)";
        }
        return tools.rendJSON(req, res, {code: 1000, message: msg});
    }
    // if(1== args.needIdentity){
    //     //仅idno
        
    // }else if(2== args.needIdentity){
    //     //仅idpic
        
    // }else if(3== args){
    //     //idno+idpic
    // }
    order_ctr.updateIdentify(args, function(err, result){
        var _data= null;
        if(err){
            _data.code= 1000;
            _data.message= "网络异常，请稍候重试";
        }else{
            _data= result;
        }
        tools.rendJSON(req, res, _data);
    });

});

/**
    页面发送验证码接口
    @param {string} mobile
    @param {string} mode        登录模式
    @param {string} ticket      腾讯web校验 参数
    @param {string} csnonce     腾讯web校验 参数

    使用场景：
    a)登录弹窗      H5FastLogin
    b)登录页面      H5Login
    c)订单查询      h5SearchOrder（i.loan.cn OR i.intpay.com）
    d)编辑手机号    h5EditMobile（？）
    e)高校创业      gaoxiaoChuangye
    f)新版登录      h5NewLogin
    j)...

    业务流程：
    a)服务端针对ip mobile 字段进行风控判断，如果有问题（code= 200002）则不发送验证码，并反馈给web
    b)web显示第三方校验控件（腾讯or极验）,用户进行第三方的web校验，返回一个结果集
    c)在次调用此接口，首先对结果集进行有效性检验，如果通过则进入发送验证码流程，否则(req.body.verify_valid= false)返回error
*/
router.post('/api/verify', validator.handleEvent, function (req, res, next) {
    //快速查询订单已接入（腾讯）风控
    if("h5SearchOrder"=== req.body.mode&& !req.body.verify_valid){
        var data= {
            code:1001,
            message: "验证码校验失败！",
            data:null
        };
        return tools.rendJSON(req, res, data);
    }
    var now = new Date().getTime();
    if (!req.session.sendCode) {
        req.session.sendCode = {};
    }
    if (!req.session.sendCode.lastTime || now - req.session.sendCode.lastTime > 1*1000) {
        req.session.sendCode.lastTime = now;
        var data= {
            mobile:    req.body.mobile,
            mode:      req.body.mode,
            clientIp:  tools.getClientIp(req),
            passCode:  req.body.passCode|| ""
        };
        if(req.body.isIndiana){
            data.tosmsapp = 'com.weimob.indiana';
        }
        user_ctr.sendCode(data, function (err, result) {
            if (err) {
                console.log(err);
            } else {
                delete result.traces;
                // 缓存验证码 @TODO 可以删除了? 20150924
                //req.session.user.verifyCode = result.data.code;
                //req.session.user.verifyCount=6;
                // 客户端删除验证码
                //delete result.data;
                //校验成功的状态sign, 3分钟后过期
                //result.code= 200002;
                result.sign= "";
                if(0== result.code){
                    var token=  [data.mobile, data.mode, data.clientIp, (now+ 3*60*1e3).toString(32), "6dget1o"],
                        md5=    crypto.createHash('md5'),
                        sign=   (md5.update(token.join("-") ), md5.digest('hex').slice(0, 5) );
                    //
                    result.sign= sign+ token[3];
                }else if("200002"== result.code){
                    return validator.init({
                        type: parseInt(result.data.check_type),
                        clientIp: res.locals.config.clientIp 
                    }, function(thirdValidation){
                        result.thirdValidation= thirdValidation;
                        tools.rendJSON(req, res, result);
                    });
                }else{
                    
                }
                tools.rendJSON(req, res, result || {});
            }
        });
    } else {
        req.session.sendCode.lastTime = now;
        var msgObj = {
            message: "请求过频，请稍候"
        }
        tools.rendJSON(req,res,msgObj);
    }
    
});

/* 修改头像 */
router.post('/api/user/modifyLogo', function (req, res) {
    var userid = req.session.user.id;

    user_ctr.uploadImage({
        uploadimage: req.body.imgfile
    }, function (err, result) {
        if (err) {
            console.log(err);
        } else if (result.code == 0) {
            user_ctr.modify({
                user_id: userid,
                head_img: result.data
            }, function (err, result) {
                if (err) {
                    console.log(err);
                } else {
                    tools.rendJSON(req, res, result || {});
                }
            });
        } else {
            tools.rendJSON(req, res, result || {});
        }
    });
});

/* 登录 */
router.post('/api/user/login', function (req, res, next) {
    var query= req.body,
        args= {
            mobile:     query.mobile,
            verifycode: query.verifycode,
            mode:       query.mode,
            clientIp:   tools.getClientIp(req)
        },
        result= null;
    new Promise(function(resolve, reject){
        user_ctr.checkCode({
            mobile:     args.mobile,
            mode:       args.mode,
            code:       args.verifycode,
            clientIp:   args.clientIp
        }, function (err, result2) {
            //return resolve();
            if (err) {
                reject(err);
            } else if (0== result2.code) {
                resolve();
            }else{
                reject(result2.message);
            }
        });
    }).then(function(){
        return new Promise(function(resolve, reject){
             user_ctr.add({
                user_id:    req.session.user.id,
                openid:     req.session.wechat.openid,
                unionid:   req.session.wechat.current.unionid,
                mobile:     args.mobile,
                yunjie_id:  req.session.user.yunjie_id,
                code:       args.verifycode,
                clientIp:   args.clientIp,
                open_id_type: /duobao/i.test(req.hostname)? 300: 100
            }, function(err, result) {
                if (err) {
                    reject(err);
                } else if (result.code == 0) {
                    resolve(result);
                }else{
                    reject(result.message);
                }
            });
        });
    }).then(function(result){
        // 把当前用户放到session中
        var yunjie_id= req.session.user.yunjie_id;
        req.session.user=          result.data;
        req.session.user.id=       result.data.user_id;
        req.session.user.openid=   result.data.openid||result.data.vd_openid;
        req.session.user.shop_id = result.data.shop_id;
        req.session.user.yunjie_id=yunjie_id;
        // 注册成功后跳转到个人信息
        result.data= {
            isAdd:      result.data.isAdd,
            wid:        result.data.wid,
            mobile:     result.data.mobile,
            isSelfShop: false//req.session.shopInfo.user_id=== req.session.user.user_id
        };
        //绑定微信& 同步萌团长数据
        if(res.locals.config.isWeixin){
            var u_uid=  req.session.user.union_id,
                c_uid=  req.session.wechat.current.union_id;
            if(!u_uid){
                mduc.doWXBind(req, res);
            }else if(u_uid!== c_uid){
                return tools.rendJSON(req, res, {code: 1000, message: "unionid 非当前微信unionid" });
            }
            req.session.save();
            tools.rendJSON(req, res, result || {});
        }else{
            req.session.save();
            tools.rendJSON(req, res, result || {});    
        }
        user_ctr.loginMsg({
            wid: req.session.user.wid,
            BaseAppType: "H5",
            wxUnionId: req.session.wechat.current.unionid|| "",
            phone: req.session.user.mobile,
            browser: /micromessenger|qq|HTML5/i.exec(res.locals.config.ua)[0]
        }, function(){

        });
        
        //注册打点
        //if(result.data.isAdd){
            new Statistics2().invoke(req, res, next, {
                action:     {
                    elementid: result.data.isAdd? "h5register": "h5login",
                    eventtype: "tap"
                },
                extend:   {
                    mobile: args.mobile,
                    mode: args.mode
                }
            });
        //}
    }).catch(function(e){
        tools.rendJSON(req, res, {code: 1000, message: e, data: null});
    });
});

/* 登录 */
router.post('/api/user/applogin', checkAPPShopLogin, function (req, res) {
    var query= req.body,
        args= {
            mobile: query.mobile,
            uuid: query.uuid,
            shop_id: query.shop_id,
            wid: query.wid,
            token: query.token
        };
    var activityMum= req.session.activity.mum;
    if (activityMum.status != 0) {
        return tools.rendJSON(req, res, {code:1000, message:"您的账号有误，或者已在其他设备登录。", data: []});
    } else {
        if(!/^\d{5,20}$/.test(args.mobile)){
            return tools.rendJSON(req, res, {code:1000, message:"手机号有误", data: []});
        }
        user_ctr.getUserByMobile(args, function(err, result) {
            if (err) {
                console.log(err);
            } else if (result.code == 0) {
                //var isSelf= new RegExp(result.data.wid+ "$").test(args.wid);
                var isSelf = true;
                if(isSelf){
                    // 把当前用户放到session中
                    var yunjie_id= req.session.user.yunjie_id;
                    req.session.user = result.data;
                    req.session.user.id = result.data.user_id;
                    req.session.user.openid = result.data.openid||result.data.vd_openid;
                    req.session.user.shop_id = result.data.shop_id;
                    req.session.user.yunjie_id= yunjie_id;
                    // 注册成功后跳转到个人信息
                    req.session.save();
                    delete result.data;
                }
                tools.rendJSON(req, res, result || {});
            } else {
                // 设置提示信息
                tools.rendJSON(req, res, result || {});
            }
        });
    }
});

/* 保存(新增/修改)收货地址 */
router.post('/api/user/addressEditAction', function(req, res) {
    var query = req.body,
        selectedId = query.selectedId,
        userid = req.session.user.id,
        yunjie_id = req.session.user.yunjie_id;

    address_ctr.update({
        user_id: userid,
        yunjie_id: yunjie_id,
        receiver: query.receiver,
        mobile: query.mobile,
        address_id: query.id,
        province: query.province,
        city: query.city,
        zone: query.zone,
        address: query.address,
        addressName: query.addressName,
        is_default: query.default,
        id_num: query.idNo,
        IDPhotoFront: query.idpic1url,
        IDPhotoBack: query.idpic2url
    }, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, err || {});
        } else {
            tools.rendJSON(req, res, result || {});
        }
    });
});

/* 订单列表 */
router.post('/api/order/list', function (req, res) {
    var status = req.body.type || '',
        page = req.body.page || 1,
        userid = req.session.user.id,
        yunjie_id = req.session.user.yunjie_id,
        receiverMobile = req.session.user.receiverMobile,
        order_biz_type = req.body.order_biz_type;

    order_ctr.getList({
        status: status,
        page: page,
        user_id: userid,
        yunjie_id: yunjie_id,
        receiver_mobile: receiverMobile,
        order_biz_type: order_biz_type
    }, function (err, result) {
        if (err) {
            console.log(err);
        }
        tools.rendJSON(req, res, result || {});
    });
});

/**
 公用的方法，不做具体的逻辑
 a)三种状态，通过error传递
 -1,不做校验
 0,校验成功
 1,校验失败
 b) 其他地方有同样方法，TODO 合并
 */
function checkAPPShopLogin(req, res, next){
    var query= req.body,
        args= {
            mobile: query.mobile,
            uuid: query.uuid,
            shop_id: query.shop_id,
            wid: query.wid,
            token: query.token
        },
        error= -1;
    //
    if(/^\d{1,20}$/.test(args.shop_id)&& /^\d{1,20}$/.test(args.wid) ){
        //jsapi授权的店铺信息
        shop_ctr.checkAPPShopLogin(args, function(err, result){
            if(!err&& 0=== result.code ){
                error= 0;
            }else{
                error= "1 invalid token";
            }
            if(req.session.activity){

            }else{
                req.session.activity= {};
            }
            req.session.activity.mum= {
                shop_id: args.shop_id,
                wid: args.wid,
                status: error,
                mobile: args.mobile
            }
            next();
        });
    }else{
        next();
    }
}


/*根据坐标信息获取地址详情*/
router.post('/api/location/geocoder', function(req, res){
    var args = {
        lat: req.body.lat,
        lng: req.body.lng
    }
    location_ctr.geocoder(args, function(err, result){
        tools.rendJSON(req, res, result || {});
    });
});

/*添加商品评论*/
router.post('/api/goods/setComments', function(req, res){
    var args = {
       
    }
    goods_ctr.setComments(args, function(err, result){
        console.log(result);
        tools.rendJSON(req, res, result || {});
    });
});



router.get("/api/user/getAccessToken", function(req, res){
    var args = {
        openid:"oE__0s1tGlKM4QlTgxjtIteEIi5Q"
    }
    user_ctr.getAccessToken(args, function(err, result){
        tools.rendJSON(req, res, {access_token:result.access_token});
    });
});

// 添加评价
router.post('/api/appraise/appraiseAdd', function(req, res){
    var args = req.body.data,
        user = req.session.user,
        userId = user.id;

    if(userId != -1){
        args.user_id = userId;
    }
    args.yunjieID = user.yunjie_id;
    args.open_id = user.openid || '';

    order_ctr.addComment(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result||{});
        }  
    });
});

// 获取订单统计
router.post('/api/order/statistics', function (req, res) {
    var user = req.session.user,
        userid = user.id,
        yunjie_id = user.yunjie_id,
        receiverMobile = user.receiverMobile;

    order_ctr.statistics({
        user_id: userid,
        yunjie_id: yunjie_id,
        receiver_mobile: receiverMobile
    }, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result || {});
        }
    });
});

// 获取代销订单运费信息
router.post('/api/order/wpFreight', function(req, res){
    var args = req.body.data;
    //args.shop_id
    args.user_id= req.session.user.id;
    //args._wid_= req.session.user.id;
    order_ctr.wpFreight(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result||{});
        }  
    });
});

// 获取卖家运费信息
router.post('/api/goods/getFreight', function(req, res){
    var args = req.body.data;

    seller_goods_ctr.getFreight(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result||{});
        }  
    });
});

/* 退款上传凭证 */
router.post('/api/order/uploadImg', function (req, res) {
    order_ctr.uploadImage({
        uploadimage: req.body.imgfile
    }, function (err, result) {
        if (err) {
            console.log(err);
        }
        tools.rendJSON(req, res, result);
    });
});

/* 延长自动确认收货时间 */
router.post('/api/order/extendReceipt', function (req, res) {
    var args = req.query;

    order_ctr.extendReceipt({
        shop_id: args.shopId,
        order_no: args.id
    }, function (err, result) {
        if (err) {
            console.log(err);
        }
        tools.rendJSON(req, res, result);
    });
});

// 获取店铺下的商品列表
router.get('/api/goods/list', function (req, res) {
    var args = {
        shop_id: req.session.shopInfo.shop_id,
        cur: req.query.cur
    };
    if(req.query.monthNew == "true"){
        args.put_shelves_date = 1;
    }
    if(req.query.is_recommend == 1){
        args.is_recommend = 1;
    }
    goods_ctr.getList(args, function (err, result) {
        if (err) {
            console.log(err);
        }
        tools.rendJSON(req, res, result);
    });
});

router.get('/api/user/wxinfo', function(req, res){
    user_ctr.getWXUserInfoByOpenid({openid: "ojLyDjnSwYZ2-HHsHhkwIJVBLgJg"}, function(err, result){
        res.end(JSON.stringify(result) );
    });
});

//获取是否已关注
router.all('/api/user/getWPUserByOpenid', function(req, res){
    var args = {
        openid:req.session.user.openid
    }
    if(!args.openid){
        tools.rendJSON(req, res, {});
    }else{
        user_ctr.getWPUserByOpenid(args, function(err, result){
            tools.rendJSON(req, res, result);
        });
    }
});

//分页获取分类id，在分类模板中使用(已弃用)
router.get('/api/goods/getCategories', function(req, res){
    goods_ctr.getCategoriesGoodsMap({
        shop_id: req.session.shopInfo.shop_id,
        category_id: [],
        order_field: "sort,update_time,id",
        order_type: "DESC",
        page_size: req.query.page_size || 100,
        page_num: req.query.page_num,
        is_return_only_category_info: 1
    }, function(err, result){
        if(err){
            console.log(err);
        }
        tools.rendJSON(req, res, result);
    });
});

//根据商品id获取商品信息，在分类模板中使用
router.post('/api/goods/getGoods', function(req, res){
    var args = req.body;
    if(args.category_ids && args.category_ids.length){
        //根据分类id并发请求分页获取商品信息
        var tasks = {};
        for(var i=0; i<args.category_ids.length; i++){
            (function(k){
                tasks[args.category_ids[k]] = function(callback){
                    goods_ctr.getGoodsById({
                        shop_id: req.session.shopInfo.shop_id,
                        category_id: args.category_ids[k],
                        page_size: args.page_size,
                        page_num: args.page_num
                    }, function(err, result){
                        if(err){
                            console.log(err);
                        }
                        else{
                            callback(null, result);
                        }
                    });
                }
            })(i);
        }
        async.parallel(tasks, function(err, result){
            if(err){
                console.log(err);
            }
            tools.rendJSON(req, res, result);
        });
    }
    else{
        //不根据分类id请求，而是根据商品id请求
        goods_ctr.getGoodsById({
            shop_id: req.session.shopInfo.shop_id,
            goods_id: args.goods_id,
            page_size: args.page_size,
            page_num: args.page_num
        }, function(err, result){
            if(err){
                console.log(err);
            }
            tools.rendJSON(req, res, result);
        });
    }
});

//获取环信公用密码
router.post('/api/webim/getPubKey', function(req, res){
    webim_ctr.getPubKey(function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});

//请求客服接口
router.post('/api/webim/requestCusService', function (req, res) {
    var args = req.body.data;
    var shop_id = req.session.user.shop_id;
    args.bizId = shop_id;
    webim_ctr.requestCusService(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});

//获取店铺id与其客服环信id的对应关系表
router.post('/api/webim/getImucIdsByMerchantId', function (req, res) {
    var args = req.body.data;
    webim_ctr.getImucIdsByMerchantId(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});

//排队时留言
router.post('/api/webim/getLineQueueStatus', function (req, res) {
    var args = req.body.data;
    webim_ctr.getLineQueueStatus(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});

//转接时留言
router.post('/api/webim/getTransferStatus', function (req, res) {
    var args = req.body.data;
    webim_ctr.getTransferStatus(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});

//获取用户信息，判断用户为正式用户还是临时用户，如果不存在则注册用户
router.post('/api/webim/registerGet', function(req, res){
    var args = req.body.data;
    var userId = req.session.user.id;
    var yunjieId = req.session.user.yunjie_id;
    var shop_id = req.session.user.shop_id;
    //萌店主
    if(shop_id && shop_id != -1){
        args.bizId = shop_id;
        args.bizType = 1;
        webim_ctr.registerGetUserEx(args, function(err, result){
            if(err){
                console.log(err);
            }else{
                tools.rendJSON(req, res, result);
            }
        });
    }
    //临时买家
    else{
        args.bizId = yunjieId;
        args.bizType = 3;
        webim_ctr.registerGetTempUserEx(args, function(err, result){
            if(err){
                console.log(err);
            }else{
                tools.rendJSON(req, res, result);
            }
        });
    }
});
//获取用户信息，如果不存在则注册用户
router.post('/api/webim/registerGetUserEx', function(req, res){
    var args = req.body.data;
    webim_ctr.registerGetUserEx(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});
//获取用户信息，如果不存在则注册临时用户
router.post('/api/webim/registerGetTempUserEx', function(req, res){
    var args = req.body.data;
    webim_ctr.registerGetTempUserEx(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});
//根据业务id获取用户信息
router.post('/api/webim/getUserInfoFromBiz', function(req, res){
    var args = req.body.data;
    webim_ctr.getUserInfoFromBiz(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});
//添加临时会话
router.post('/api/webim/addTempChat', function(req, res){
    var args = req.body.data;
    webim_ctr.addTempChat(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});
//聊天时上传图片
router.post('/api/webim/uploadImage', function(req, res){
    var args = req.body.data;
    webim_ctr.uploadImage(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});
//获取开场语
router.post('/api/webim/getStartSentence', function(req, res){
    var args = req.body.data;
    webim_ctr.getStartSentence(args, function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});
//获取供应商imucId，此接口会自动判断供货商PC在线还是手机在线
router.post('/api/webim/getSupplier', function (req, res) {
    var args = req.body.data;
    webim_ctr.getSupplier(args, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});


//根据手机号申请好友
router.post('/api/webim/applyFriend', function(req, res, next){
    var query= req.body,
        submitShopId= query.submitShopId,
        
        args= {
          applyShopId:query.applyShopId,
          targetPhone:query.targetPhone,
          relationType:0
        };

    webim_ctr.applyFriend(args, function(err, result){
        var _result= null;
        if(err){
            _result = {
                code: result.code.errcode,
                message: result.code.errmsg,
                data: {}
            }
        }else{
            _result = {
                code: result.code.errcode,
                message: result.code.errmsg,
                data: result.data
            }
        }
        tools.rendJSON(req, res, _result);
    });
});
//通过shopid去添加好友
router.post('/api/webim/addFriendWithShopId', function(req, res, next){
    var query= req.body,
        submitShopId= query.submitShopId,
        targetShopId = query.targetShopId,
        
        args= {
            submitShopId:submitShopId,
            targetShopId:targetShopId,
            relationType:0
        };

    webim_ctr.addFriendWithShopId(args, function(err, result){
        var _result= null;
        if(err){
            _result = {
                code: result.code.errcode,
                message: result.code.errmsg,
                data: {}
            }
        }else{
            _result = {
                code: result.code.errcode,
                message: result.code.errmsg,
                data: result.data
            }
            
        }
        tools.rendJSON(req, res, _result);
    });
});
//验证码检查是否已注册


//专题页面获取商品信息
router.post('/api/topic/getGoods', function(req, res){
    var goodsId = req.body.goodsId,
        shopId = req.body.shopId,
        label = req.body.label,
        scenarios = req.body.scenarios || 2; //默认查询直销商品
    var args = {
        shop_id: shopId,
        id: goodsId,
        label: label,
        scenarios: scenarios
    };
    seller_goods_ctr.getSellerGoods(args, function(err, result){
        if(err){
            console.log(err);
        }
        else{
            tools.rendJSON(req, res, result);
        }
    });
});

//获取供货商店铺商品
router.post('/api/seller/getGoods', function(req, res){
    var aid = req.body.aid,
        page_size = req.body.page_size,
        page_num = req.body.page_num,
        shop_id = req.body.shop_id,
        order_type = req.body.order_type,
        label = req.body.label,
        keyword = req.body.keyword,
        args={
            tag: 1,
            scenarios: parseInt(req.body.scenarios)|| ""
        };
    var classify_id = req.body.classify_id;
    if(!!shop_id){
        args.shop_id = shop_id;
    }
    if(!!aid){
        args.aid = aid;
    }
    if(!!classify_id){
        classify_id = classify_id.split("_").join(",");
        args.classify_id = classify_id;
    }
    if(!!page_size){
        args.page_size =page_size;
    }
    if(!!order_type){
        args.order_type = order_type;
    }
    if(!!page_num){
        args.page_num = page_num;
    }
    if(!!label){
        args.label = label;
    }
    if(!!keyword){
        args.keyword = keyword;
    }
    function   formatDate(nowd)   {
        var   month=nowd.getMonth()+ 1,
        dates=nowd.getDate();
        if(month<10){
            month="0"+month;
        }
        if(dates<10){
            dates="0"+dates;
        }
        return   month+"月"+dates+"日";
    }
    function segmentation(obj){
        var price, valI,valF,fltln,fltint,new_date;
        for(var p_i= 0,i_l = obj.length;p_i<i_l;p_i++){
            price =  obj[p_i].sale_price || 0;
            new_date = obj[p_i].verifyTime;
            price = price.toString();
            fltln = price.split(".");
            valI = fltln[0];
            fltint = fltln[1];
            obj[p_i].verifyTime=formatDate(new Date(new_date*1000));
            obj[p_i].valInt = valI;
            obj[p_i].fltint = fltint;
        }
        return obj;
    }
    seller_goods_ctr.getSellerGoods(args, function(err, result){
        if(err){
            console.log(err);
        }
        else{
            var hotGoods = result.data.goods_lists;
            result.data.goods_lists = segmentation(hotGoods);
            tools.rendJSON(req, res, result);
        }
    });
});

// 萌店指南(app)：板块分类
router.post('/api/handbook/category', function (req, res) {
    var moduleId = req.body.moduleId,
        page = req.body.page || 1;

    article_ctr.getModuleCategories({
        module_id: moduleId,
        page_num: page
    }, function (err, result) {
        if (err) {
            console.log(err);
        }
        tools.rendJSON(req, res, result || {});
    });
});

// 萌店指南(app)：分类列表
router.post('/api/handbook/list', function (req, res) {
    var categoryId = req.body.categoryId,
        page = req.body.page || 1;

    article_ctr.getCategoryList({
        cate_id: categoryId,
        page_num: page
    }, function (err, result) {
        if (err) {
            console.log(err);
        }
        tools.rendJSON(req, res, result || {});
    });
});

//合伙人统计
router.post('/api/statistics/partner', function(req, res){
    var args = req.body;
    statisticsPartner.invoke(args);
});

//获取验证码图片
router.post('/api/getCaptcha', function(req, res){
    var n = Math.random() > 0.5 ? 4 : 5;
    var code = generateCode(n);
    req.session.user.verifyPicCode = code.toLowerCase();

    user_ctr.getCaptcha({
        code: code
    }, function(err, result){
        if(err){
            console.log(err);
        }
        else {
            tools.rendJSON(req,res,result || {});           
        }
    });

    function generateCode(n) {
        var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
        var res = "";
        for(var i = 0; i < n ; i ++) {
            var id = Math.ceil(Math.random()*36) - 1;
            res += chars[id];
        }
        return res;
    }
});

//客服验证
router.post('/api/verifyIm', function (req, res) {
    var code = req.body.code,
        result = null;
    if (req.session.user.verifyPicCode == code) {
        req.session.webim = null;
        result = {
            code: 0,
            message: "success"
        };
    } else {
        result = {
            code: 1,
            message: "failed"
        };
    }
    tools.rendJSON(req, res, result || {});
});


/************************************************************
    辣妈学院
************************************************************/
/**
    a) jsapi 获取店铺信息
    b) 店铺信息验证通过后放到session中
    c) 检查当前店铺的注册情况
 */
router.post("/api/activity/mumCheckRegister", function(req, res, next){
     var query= req.body,
        args= {
            mobile: query.mobile,
            uuid: query.uuid,
            shop_id: query.shop_id,
            wid: query.wid,
            token: query.token
        };
    if(!/^\d{1,20}$/.test(args.wid)){
        return tools.rendJSON(req, res, {code:1000, message:"1 wrong wid", data:[] });
    }
    mum_ctr.checkRegister({
       wid: args.wid
    }, function(err, result){
        if (err) {
            result= {code:1000, message: JSON.stringify(err), data: result }
        }else{
            result= {
                code:0,
                message:"",
                data: {
                    isRegisted: !!(result.data&& (1== result.data.status) )
                }
            };
            //萌店app外打开
            if(!res.locals.config.isVdianAPP){
                result.data._isRegisted= result.isRegisted;
                result.data.isRegisted= false;
            }
        }
        tools.rendJSON(req, res, result);
    });
});
router.post("/api/activity/mumRegister", checkAPPShopLogin, function(req, res, next){
    var activityMum= req.session.activity.mum,
        args= {
            shop_id: activityMum.shop_id,
            wid: activityMum.wid,
            mobile: activityMum.mobile
        };
    if(activityMum.status){
        return tools.rendJSON(req, res, {code:1000, message:"参数错误("+ activityMum.status+ ")", data:null});
    }
    //
    mum_ctr.doRegister(args, function(err, result){
        if(err){
           result= {code:1000, message:"未知异常，请重试", data:null};
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});


router.post("/api/activity/checkvote", function(req, res, next){
    var query= req.body,
        args= {
            mobile: query.mobile,
            uuid: query.uuid,
            shop_id: query.shop_id,
            wid: query.wid,
            token: query.token
        };
    lamavote_ctr.getCheckVote({
        vote_id: args.wid,
        vote_type: 0
    },function(err,result){
        if(err){
            tools.rendJSON(req, res, {code:1000, data:[], message: "unknow exception"});
        }else{
            tools.rendJSON(req, res, result);
        }
    });
});

/**
    h5 领优惠券
 */
router.post("/api/activity/wallet/11/register", mobileRiskCheck, function(req, res, next){
    var query= req.body;
        // args= {
        //     phone: query.phone,
        //     master_wid: query.master_wid,
        //     channel: query.channel
        // };

    var risk= req.session.activity.risk;
    if(1== risk.status){
        //需要图形验证码
        if(risk.showImgCode){
            return tools.rendJSON(req, res, {code: 100, data: risk, message: "您的手机号存在风险，请输入验证码"});
        }
    }
    var args= {
        phone: risk.phone,
        master_wid: risk.master_wid,
        channel: risk.channel,
        subchannel: query.subchannel,
        clientIp: tools.getClientIp(req)
    };
    //最终
    activity_ctr.register(args, function(err, result){
        if (err) {
           
        } else {
            delete req.session.activity.risk; //清除分控校验， 必要性？
        }
        tools.rendJSON(req, res, result|| {});
    });

});

/**
    风控校验
 */
function mobileRiskCheck(req, res, next){
    var query= req.body,
        ticket= query.ticket,   //第一次请求是没有的
        csnonce= query.csnonce, //
        master_wid= query.master_wid,
        channel= query.channel,
        args= {
            phone: query.phone,
            mobile: query.phone, //兼容
            ip: tools.getClientIp(req),
            mode: "1111-youhuiquan"
        };
        //验证码校验, 二次进入
        if(ticket){
            var args= {
                ticket: ticket,
                csnonce: csnonce,
                userIp: tools.getClientIp(req)
            };
            verifyCodeHelper.checkVcode(args, function(err, result){
                //
                if(0!== result.code){
                    return tools.rendJSON(req, res, {code:1000, data:null, message: "验证码错误。"});
                }
                 req.session.activity.risk.status= 0; //相当于关闭
                next();
            });
            return;
        }
        //提示需要验证码校验
        activity_ctr.mobileRiskCheck(args, function(err, result){
            if (err) {
                return tools.rendJSON(req, {code:1000, data:null, message: "风控校验失败,请稍后重试。"});
            } else {
                result.data= result.data||{};//兼容
                //console.log(result);
                if(req.session.activity){

                }else{
                    req.session.activity= {};
                }
                req.session.activity.risk= {
                    status: 1, //是否开启
                    checkLevel: ~~result.data.checkLevel,
                    showImgCode: ~~result.data.showImgCode,
                    phone: args.phone,
                    master_wid: master_wid,
                    channel: channel
                }
                //req.session.activity.risk.showImgCode= 1;
                next();
            }
        });
}

/**
 裂变券领红包
 */
router.post("/api/activity/coupon/risk/management", function(req, res, next){
    var query= req.body,
        phone= query.phone;
    var args= {
        phone: parseInt(query.mobile) || req.session.user.mobile || req.session.user.mobile2,
        mobile: parseInt(query.mobile) || req.session.user.mobile || req.session.user.mobile2, //兼容
        ip: tools.getClientIp(req),
        bizType: 3,
        sceneId: 3,
        mode: "tuan-coupon"
    };

/*
    1、异常等级4以上时，直接拦截不发券
    2、异常等级3~4时，点字验证
    3、异常等级2时滑动图块验证
    4、异常等级0~1时，无需验证
    type == ?(1滑块验证 2点字验证)
*/
    activity_ctr.mobileRiskCheck(args, function(err, result){
        if (err) {
            var result1={
                code:1000,
                data:{
                    checkLevel: 5,
                    mobile: args.mobile
                },
                message: "风控校验失败,请稍后重试。"
            };
            return tools.rendJSON(req, res, result1 || {});
        } else {
            result.data= result.data||{}; // 兼容
            var checkLevel = result.data.checkLevel;
            var passCode= checkLevel+ "-"+ validator.encodePassCode( checkLevel+ (args.phone+ query.tuanCode+ "-lbq") );
            if (checkLevel <= 2) {
                var result = {
                    code:0,
                    data:{
                        checkLevel: checkLevel,
                        mobile: args.mobile,
                        passCode: passCode
                    }
                };
                return tools.rendJSON(req, res, result || {});
            } else{
                if(checkLevel>4){
                    var result1={
                        code:1001,
                        data:{
                            checkLevel: checkLevel,
                            mobile: args.mobile,
                            passCode: passCode
                        }
                    };
                    return tools.rendJSON(req, res, result1 || {});
                } else{
                    // 滑块验证
                    // if (checkLevel == 2) {
                    //     var type = 1;
                    // }
                    // 点字验证
                    if(checkLevel==3||checkLevel==4){
                        type=2
                    }
                    validator.init({type: type, clientIp: res.locals.config.clientIp}, function(thirdValidation){
                        result= {
                            code:-2,
                            data:{
                                type: "encrypt",
                                thirdValidation: thirdValidation,
                                checkLevel: checkLevel,
                                mobile: args.mobile,
                                passCode: passCode
                            }
                        };
                        return tools.rendJSON(req, res, result || {});
                    });
                }
            }

        }
    });
});

// 裂变券红包分享
router.post("/api/activity/coupon/h5/random/share", function(req, res, next){
    var user = req.session.user;
    if (!user.mobile2) {
        user.mobile2 = req.body.phone;
    }
    var args= {
        phone: req.body.phone,
        tuanId: req.body.tuanId,
        riskLevel: req.body.passCode.charAt(0)
    };
    var result= {code: 999, message: "网络异常，请刷新后重试"};
    //
    new Promise(function(resolve, reject){
        var _passCode= args.riskLevel+ "-"+ validator.encodePassCode(args.riskLevel+ args.phone+ req.body.tuanCode+ "-lbq");
        var _tuanCode= validator.encodePassCode(args.tuanId+ "tuan-").substring(0, 5);
        if((args.tuanId>1790000)&& _tuanCode!== req.body.tuanCode){
            result= {code: 1002, message: "非法请求[wrong tuanCode]"};
            reject();
        }else if(_passCode!== req.body.passCode){
            result= {code: 1003, message: "非法请求[wrong passCode]"};
            reject();
        }else if(args.riskLevel>2&& args.riskLevel<5){
            if(!req.body.validate){
                result= {code: 1003, message: "非法请求[no validate]"};
                reject();
            }else{
                resolve(req.body.validate);
            }
        }else{
            resolve(0);
        }
    }).then(function(validate){
        if(validate){
            return new Promise(function(resolve, reject){
                req.body.mode= "tuan-coupon";
                validator.handleEvent(req, res, function(){    
                    var verify_valid= req.body.verify_valid;
                    if(verify_valid){
                        resolve();
                    }
                    else{
                        result= {code: 1002, message: "风控校验失败,请稍后重试。" };
                        reject();
                    }
                });
            });
        }else{
            return 1;
        }
    }).then(function(){
        activity_ctr.getFissionCoupons(args, function (err, result) {
            if(err){
                throw new Error(err);
            }else {
                tools.rendJSON(req, res, result || {});
            }
        });
    }).catch(function(err){
        result.data= err;
        tools.rendJSON(req, res, result);
    });
});



/************************************************************
    高校创业赛
************************************************************/
//网页端注册活动
router.post("/api/activity/schoolRegister", function(req, res, next){
     var query = req.body,
        attached_fields = {
            school: query.school
        },
        args = {
            activeSource: 'gaoxiaochuangyesai',
            mode: 'gaoxiaoChuangye',
            code: query.code,
            mobile: query.mobile,
            name: query.name,
            mdId: query.vid || '',
            attached_fields: JSON.stringify(attached_fields)
        };
        //判断验证码是否正常,如果没有错误则进行注册
        user_ctr.checkCode({
            mobile: args.mobile,
            mode: args.mode,
            code: args.code
        }, function (err, result) {
            if (err) {
                tools.rendJSON(req, res, {code:1000, message:"未知异常，请重试", data:null});
            } else if (result.code != 0) {
                tools.rendJSON(req, res, {code:1000, message:"请输入正确的验证码!", data:null});
            }else{
                doRegAction();
            }
        });

        
});

//是否已经报名高校创业赛
router.post("/api/activity/isSchoolRegister", function(req, res, next){
    var query = req.body,
        args = {
            mobile: query.mobile,
            uuid: query.uuid,
            shop_id: query.shop_id,
            wid: query.wid,
            token: query.token
        };
    if(!/^\d{1,20}$/.test(args.wid)){
        return tools.rendJSON(req, res, {code:1000, message:"1 wrong wid", data:[] });
    }


});



/************************************************************
    node 系统配置文件
************************************************************/
router.post('/api/util/admin/login', function (req, res, next) {
    var query= req.body,
        typeId= query.typeId,
        args= {
            mobile: query.mobile,
            mode: query.mode,
            code: query.vcode,
            pwd: query.pwd
        };
    //验证验证码，正确后登录
    var msg= null;
    if("13636607550"!== args.mobile){
        msg= "请输入管理员intpay的手机号";
    }else if(!/^\d{4,6}$/.test(args.code) ){
        msg= "请输入验证码";
    }else if("anjey_md_admin"!== args.pwd){
         msg= "密码错误";
    }
    if(msg){
        return tools.rendJSON(req, res, {code:1000, message: msg});
    }
    user_ctr.checkCode(args, function (err, result) {
        if(err){
            tools.rendJSON(req, res, {code:1001, message: "checkcode 异常"});
        }else if(0!= result.code){
             tools.rendJSON(req, res, {code:1002, message: "验证码错误"});
        }else{
            //获取配置，并保存admin session
            req.session.admin= {
                phone:"13636607550",
                vcode: "xxxx",
                pwd: "anj**_m*_ad***",
                isAdminLogin: 1
            };
            req.session.save();
            tools.rendJSON(req, res, {code:0, data:null, message:"登录成功" });
        }
    });
    //
});



/* 
    【萌店3.1】新购物车接口 
    ** 实现购物车信息的CRUD 四合一
*/
router.post('/api/shopcart/action', function(req, res, next){
    var args = {
        wid: req.session.user.wid,
        yunjie_id: req.session.user.yunjie_id,
        cart_data: req.body.data,
        current_shop_id: req.body.current_shop_id,
        actionType: req.body.action*1,  // 1: 购物车添加商品  | 2:修改购物车商品  | 3: 删除购物车商品信息 | 其他: 获取购物车信息
        cart_item_id:req.body.cart_item_id
    };
    var statisticsArgs={
        productId: req.body.productId,
        wp_goodsId: req.body.wp_goods_id,
        productType: req.body.product_type
    };

    //用于判断购物车商品是否是自己的商品
    function isSelfShopGoods(){
        if(req.session.user.shop_id&& (req.session.user.shop_id=== args.current_shop_id) ){
            return tools.rendJSON(req, res, {code:1000, message:"您不能将自己的商品加入购物车哦！", data:[]});
        }else{
            return false;
        }
    }

    //限制自己商品不能添加
    // if(1==args.actionType)
    //     isSelfShopGoods();

    //用于数据的记录
    function addStatisticsAction(){
        if(statisticsArgs.productId){
            statistics.invoke(req, res, next, {
                phraseType: "cart",
                pageType: "cart",
                productId: statisticsArgs.productId,
                wp_goodsId: statisticsArgs.wp_goods_id,
                productType: statisticsArgs.product_type
            });
        }
    }

    //actionName ：控制器中对应购物车的方法名    isAddStatistics ： 是否执行添加统计记录
    var actionName='',isAddStatistics=true;

    switch(args.actionType){
        case 1:
            actionName = 'addGoods'; //购物车添加商品
            break;
        case 2:
            actionName = 'editGoods'; //修改购物车商品
            break;
        case 3:
            actionName = 'delGoods'; //删除购物车商品信息
            break;
        default:
            isAddStatistics=false;
            actionName = 'detailGoods'; //获取购物车信息
    }
    shopcart_ctr[actionName](args, function(err, data){
        if(err){
            console.log(err);
        }else{
            if(isAddStatistics)
                addStatisticsAction();
            tools.rendJSON(req, res, data||{});
        }
    });

});

/* 
    【萌店3.2】用于获取商品的活动信息 
    ** 通过传递相应的购物车商品信息，返回相应的商品组的优惠信息
*/
router.post('/api/shopcart/calcPromotion', function(req, res, next){
    var query = req.body,
        args= {
            parameterInput: query.parameterInput//JSON.parse(query.parameterInput)
        };

    shopcart_ctr.calcPromotion(args, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result || {});
        }
    });

});

//领取qq红包页面
router.post('/api/wallet/qq', function(req, res, next){
    var query=req.body,
        args={
            phone: query.mobile || '',
            open_id: req.cookies.openId || '', //query.openId
            card_id: query.card_id || '',
            access_token: req.cookies.accessToken || '',//query.accessToken
            pack_id: query.pack_id || '',
            business: query.business,
            ip: tools.getClientIp(req),
            state: query.state,
            signature: query.signature
        };

    //用于测试输出cookie的信息
    var testArgs=args;
 
    activity_ctr.walletQQ(args,function(err, data){
        if(err){
            console.log(err);
        }else{
            //data.param=testArgs;
            tools.rendJSON(req, res, data || {});
        }
    }); 
    
});

/**

 */
router.post('/api/wallet/addCouponWithPhone', function(req, res, next){
    var query= req.body,
        args= {
            "merchantId": null,
            "phone_no": query.phone,
            "cardStatus": 1,
            "targetCardCode": query.coupon,
            "bizType":"0"
        };
    activity_ctr.addCouponWithPhone(args,function(err, result){
        if(err){
            console.log(err);
        }else{
            tools.rendJSON(req, res, result || {});
        }
    }); 
});
/************************************************************
    运营后台透传接口
************************************************************/
router.post('/api/info/agentBackInfo', function (req, res) {
    var args = req.body;
    activity_ctr.agentBackInfo(args, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result || {});
        }
    });
});

/**************************************************
    页面JS异步打点统计
**************************************************/
router.post('/api/statistics', function (req, res, next) {
    var data = req.body;
    var params = data.params;
    new Statistics2().invoke(req, res, next, {
        business:   params
    });
    return tools.rendJSON(req, res, {code:0, message: "success but 该接口即将作废", data: []});
    //检查必传字段
    // params.cip = params.cip ? params.cip : tools.getClientIp(req);
    // params.StatType = params.StatType ? params.StatType : 'mdpath';
    // params.yunjie_id = params.yunjie_id ? params.yunjie_id : req.session.user.yunjie_id;
    // //
    // var path = raw(params);
    // proxy.invoke({
    //     data:{},
    //     protocol: "http",
    //     host: config.statistics.host,
    //     port: config.statistics.port,
    //     path: "/wm.js?"+path,
    //     method:"GET"
    // }, function (err, result) {
    //     tools.rendJSON(req, res, result || {});
    // });
    // //字典排序
    // function raw (args) {
    //     var keys = Object.keys(args),
    //         newArgs = {},
    //         string = '';
    //     keys = keys.sort();
    //     keys.forEach(function (key) {
    //         newArgs[key] = args[key];
    //     });
    //     for (var k in newArgs) {
    //         string += '&' + k + '=' + newArgs[k];
    //     }
    //     string = string.substr(1);
    //     return string;
    // }
});

/**************************************************
    页面JS异步打点统计
**************************************************/
router.get('/api/statistics2', function (req, res, next) {
    var query=      req.query,
        action=     null,
        page=       null,
        business=   null,
        platform=   null,
        user=       null,
        app=        null,
        extend=     null;
    var ua = req.headers["user-agent"] + "@HTML5";
    var isWeixin = !!/micromessenger/gi.test(ua),
        isQQ = !!/QQ/gi.test(ua) && !isWeixin;
    try{
        action=     JSON.parse(query.action);
        page=       JSON.parse(query.page);
        business=   JSON.parse(query.business);
        platform=   JSON.parse(query.platform);
        user=       JSON.parse(query.user);
        app=        JSON.parse(query.app);
        extend=     JSON.parse(query.extend);
        //根据是否是微信或qq添加用户openid
        if (isWeixin) {
            user.open_id = req.session.wechat && req.session.wechat.openid;
        } else if (isQQ) {
            user.open_id = req.session.qq && req.session.qq.openid;
        } 
    }catch(e){
        return tools.rendJSON(req, res, {code:1000, message: "参数错误", data: e});
    }
    new Statistics2().invoke(req, res, next, {
        action:     action,
        page:       page,
        business:   business,
        platform:   platform,
        user:       user,
        app:        app,
        extend:     extend
    });
    return tools.rendJSON(req, res, {code:0, message: "success", data: []});
});

/*******************************
    异步获取推荐商品
***********************************/
//获取2件推荐的拼团商品
router.post('/api/tuan/getRecommend2', function (req, res) {
    var data = req.body;
    var args = {
        prod_id: data.prod_id,
        wid: res.locals.config.vapp.wid|| "",
        channelId: "h5_pintuan_detail_recom",
        scenarios: parseInt(data.scenarios)||2 //拼团默认直销
    };
    recommend_ctrl.getRecom2(args, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            if (result.code == 0&& result.data.length) {
            //TODO:根据获取到的推荐商品ID获取商品信息
                var args2 = {
                    wp_goods_id: result.data
                };

                activity_ctr.getPintuanGoods(args2, function (err2, result2) {
                    result2.recommendIds= result.data;
                    result2.recom_list_id= result.recom_list_id;
                    result2.strategy_id= result.strategy_id;
                    tools.rendJSON(req, res, result2 || {});                         
                });
            } else {
                tools.rendJSON(req, res, result || {});
            }
        }
    });
});
//获取10件推荐的拼团商品
router.post('/api/tuan/getRecommend10', function (req, res) {
    var data = req.body;
    var args = {
        prod_id: data.prod_id,
        wid: res.locals.config.vapp.wid|| "",
        channelId: 'h5_pintuan_recom',
        scenarios: parseInt(data.scenarios)||2 //拼团默认直销
    };
    recommend_ctrl.getRecom10(args, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            if (result.code == 0&& result.data.length) {
            //TODO:根据获取到的推荐商品ID获取商品信息
                var args2 = {
                    wp_goods_id: result.data
                    // wp_goods_id: ['100507455_302546']
                };
                if(data.topic || data.relationId) {
                    args2.topic = data.topic;
                    args2.relation_id = data.relation_id;
                }
                activity_ctr.getPintuanGoods(args2, function (err2, result2) {
                    result2.recommendIds= result.data;
                    result2.recom_list_id= result.recom_list_id;
                    result2.strategy_id= result.strategy_id;
                    tools.rendJSON(req, res, result2 || {});                         
                });
            } else {
                tools.rendJSON(req, res, result || {});
            }
        }
    });
});
//推荐4件商品，不一定是拼团商品
router.post('/api/recommend/getRecommend4', function (req, res) {
    var data = req.body;
    var args = {
        prod_id: data.prod_id,
        wid: res.locals.config.vapp.wid|| "",
        channelId: "getRecom_4",
        scenarios: parseInt(data.scenarios)||2 //拼团默认直销
    };
    recommend_ctrl.getRecom2(args, function (err, result) { //接口表示getRecom_4不再使用，用getRecom_2
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            if (result.code == 0&& result.data.length) {
                //TODO:根据获取到的推荐商品ID获取商品信息
                //var id = ''; 
                 args2= {
                    searchData: []
                };
                //result.data.push("100507012_50165");
                for(var i = 0; i < 4; i++) {
                    //id += result.data[i][1];
                    //if (i != result.data.length-1) {
                        //id += ',';
                        args2.searchData.push({
                            goods_id: result.data[i],
                            sellType: args.scenarios
                        });
                    //}
                }
                seller_goods_ctr.searchSupplierGoods(args2, function(err2, result2){
                    if(err){
                        console.log(err2);
                    } else {
                        //兼容
                        result2.data.goods_lists= result2.data.goods_list||[];
                        delete result2.data.goods_list;
                        result2.data.goods_lists.forEach(function(v, k){
                            v.pic_url= v.index_image;
                            v.highMarketPrice= v.market_price;
                        });
                        //
                        result2.recommendIds= result.data;
                        result2.recom_list_id= result.recom_list_id;
                        tools.rendJSON(req, res, result2);
                    }
                });
            } else {
                tools.rendJSON(req, res, result || {});
            }
        }
    });
});

//商祥，购物车等商品推荐
router.post('/api/recommend/getRecommendAll', function (req, res, next) {
    var data = req.body;
    var args = {
        paramType: data.paramType,
        prodList: data.prodList,
        shop_id: "",
        channelId: data.channelId,
        pageType: data.pageType|| 3,
        wid: res.locals.config.vapp.wid|| "",
        scenarios: parseInt(data.scenarios)||1
    },
    args2= {};
    recommend_ctrl.getRecomAll(args, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            if (result.code == 0&& result.data.length) {
                //TODO:根据获取到的推荐商品ID获取商品信息
                //var id = ''; 
                args2= {
                    searchData: []
                };
                for(var i = 0; i < result.data.length; i++) {
                    //id += result.data[i][1];
                    //if (i != result.data.length-1) {
                        //id += ',';
                        args2.searchData.push({
                            goods_id: result.data[i][1],
                            sellType: args.scenarios
                        });
                    //}
                }
                seller_goods_ctr.searchSupplierGoods(args2, function(err2, result2){
                    if(err2){
                        tools.rendJSON(req, res, {code:1000, message: JSON.stringify(err2), data:[] });
                    } else {
                        result2.data.goods_ids= result.data;
                        result2.data.recom_list_id= result.recom_list_id;
                        result2.data.strategy_id= result.strategy_id;
                        tools.rendJSON(req, res, result2);
                    }
                });
            } else {
                tools.rendJSON(req, res, result || {});
            }
        }
    });
});
//专场推荐
router.post('/api/recommend/getRecommendSpecial', function (req, res, next) {
    var data = req.body;
    var args = {
        request:{
            specialID:data.specialID
        },
        basic_info:{
            wid:data.wid
        }
    };
    recommend_ctrl.getRecomSpecial(args, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            if (result.code == 0&& result.data.length) {
                var id = [];
                for(var i = 0; i < result.data.length; i++) {
                    id.push(result.data[i][0]);
                }
                var args2 = {
                    route: "/intpayApp/getSpecialInfoForRecommend",
                    special_ids: id
                };
                activity_ctr.agentBackInfo(args2, function(err2, result2){
                    if(err2){
                        tools.rendJSON(req, res, {code:1000, message: JSON.stringify(err2), data:[] });
                    } else {
                        result2.recom_list_id=result.recom_list_id;
                        result2.recom_ids= result.data;
                        tools.rendJSON(req, res, result2);
                    }
                });
            } else {
                tools.rendJSON(req, res, result || {});
            }
        }
    });
});
/*******************************
     获取参团人数
********************************/
router.post('/api/tuan/getMemberNum', function (req, res) {
    var data = req.body;
    var args = {
        ids: data.ids,
        tuanids: data.tuanids
    };
    activity_ctr.getParticipate(args, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});


/*********************
    追加评价
***********************/
router.post('/api/appraise/appendAppraise', function (req, res) {
    var data = req.body.data;
    order_ctr.appendComment(data, function(err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});

/********************************************
    退款校验接口（7天维权期和活动订单校验）
********************************************/
router.post('/api/order/checkRefundPermission', function (req, res) {
    var data = req.body;
    order_ctr.checkRefundPermission(data, function(err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});
/*******************************
购物号
 ********************************/
/***
 * 提交举报信息
 */
router.post('/api/gwh/setreport', function (req, res) {
    var query = req.body,
        args = {
        route: "/intpayApp/gwh/reportMessage",
        report_id: parseInt(query.report_id),
        client_ip: res.locals.config.clientIp,
        mid: parseInt(query.mid),
        description: query.description,
        user_id: parseInt(query.user_id)        // 举报用户id(ok)
    };
    args.token = getMd5(getMd5(args.report_id + args.client_ip + args.mid + args.user_id) + 'Jha,p$zkHtjv');
    activity_ctr.setReportMessage(args, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            tools.rendJSON(req, res, result);
        }
    });
    function getMd5(str){
        var md5 = crypto.createHash('md5');
        md5.update(str);
        var secret = md5.digest('hex');
        return secret;
    }
});

/***
 * 提交举报信息
 */
router.post('/api/gwh/getmsglist', function (req, res) {
    var query = req.body,
        args = {
            route: "/intpayApp/gwh/messageAssemblyList",
            aid: query.aid,
            user_id: query.user_id,
            page: query.page,
            pagesize: 5
        };
    activity_ctr.getGwhMsgList(args, function (err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});

// 获取商品标题和价格
router.post('/api/found/search', function(req, res){
    var goodsId = req.body;
    //var args = {
    //    id: goodsId.id
    //};
    var args = {
        searchData: goodsId.searchData
    };
    seller_goods_ctr.getSellerGoods(args, function(err, result){
        if(err){
            console.log(err);
        }
        else{
            tools.rendJSON(req, res, result);
        }
    });
});
// 获取拼团二期分组
router.post('/api/tuan/getPintuanInfoByGroup',function(req,res)  {   
  	var args = {
        groupId:req.body.groupId,
        page:req.body.page,
        pageSize:req.body.pageSize
	}
    activity_ctr.getPintuanInfoByGroup(args,function(err,result){
      if(err){
            console.log(err);
        }
        else{
            tools.rendJSON(req, res, result||{});
        } 
        
    })
})

// 获取商品标题和价格新
router.post('/api/gwh/getGoodsTopicInfo', function(req, res){
    seller_goods_ctr.getGoodsTopicInfo(req.body, function(err, result){
        if(err){
            tools.rendJSON(req, res, result || {});
        }
        else{
            tools.rendJSON(req, res, result);
        }
    });
});

//获取分享赚专场组件
router.post('/api/fenxiangzhuan/getThemes', function (req, res) {
    var args = req.body;
    activity_ctr.getFenxiangzhuan(args, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});

//获取分享赚专场组件(预览模式)
router.post('/api/fenxiangzhuan/getThemesView', function (req, res) {
    var args = req.body;
    activity_ctr.getFenxiangzhuanView(args, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});

//获取分享赚分享文案
router.post('/api/fenxiangzhuan/getTaskShareInfo', function (req, res) {
    var wid = req.body.wid,
        taskId = req.body.taskId,
        shopId = req.body.shopId;
    var args = {
        parameterInput: '{"taskId": '+taskId+',"wid": '+wid+',"shopId": '+shopId+'}'
    };
    activity_ctr.fxzTaskShareInfo(args, function (err, result) {
        if (err) {
            console.log(err);
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});

//分享赚页面停留check打点
router.post('/api/stayPage/check', function (req, res) {
    var ua = req.headers["user-agent"] + "@HTML5";
    var isWeixin = !!/micromessenger/gi.test(ua),
        isQQ = !!/QQ/gi.test(ua) && !isWeixin;
    var business = req.body;
    if (isQQ) {
        business.open_id = req.session.qq && req.session.qq.openid
    } else if (isWeixin) {
        business.open_id = req.session.wechat && req.session.wechat.openid;
    }
    //
    new Statistics2().invoke(req, res, null, {
        action: {
            elementid: "check",
            eventtype: "view"
        },
        business: business
    });
    //
    tools.rendJSON(req, res, {});
});

//运营后台会员加入群
router.post('/api/special/userJoinGroup',function(req,res){
    var query = req.body,
    args = {
         shopId:query.shopId,
         topicId:query.topicId,
         groupType:query.groupType
    };
    activity_ctr.userJoinGroup(args,function(err,result){
         if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            tools.rendJSON(req, res, result);
            console.log(result);
        }
    });
});
/*********************
    聚宝汇注册
***********************/
router.post('/api/activity/jbh/jbhRegister', function (req, res) {
    var query = req.body;
    var args={wid:query.wid,tel:query.tel};
    activity_ctr.jbhRegister(args, function(err, result) {
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});

/*********************
    聚宝汇保存用户中间键
***********************/
router.post('/api/activity/jbh/jbhUsertoken', function (req, res) {
    var query = req.body;
    var args={wid:query.wid,params:query.params};
    activity_ctr.jbhUsertoken(args, function(err, result) {
        console.log(result)
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});
/*********************
    聚宝汇保存绑卡信息
***********************/
router.post('/api/activity/jbh/jbhbankCardSuccess', function (req, res) {
    var query = req.body;
    var args={wid:query.wid};
    activity_ctr.jbhbankCardSuccess(args, function(err, result) {
        console.log(result)
        if (err) {
            tools.rendJSON(req, res, result || {});
        } else {
            tools.rendJSON(req, res, result);
        }
    });
});
/*********************
    聚宝汇输入手机号领券
***********************/
router.post('/api/activity/jbh/jbhgetcoupons', function (req, res) {
    var query = req.body;
    var _decrypt= query.decrypt;
    var  args= {
            phone: query.phone,
            mobile: query.phone, //兼容
            ip:tools.getClientIp(req),
            mode: "jbhGetCoupons",
            bizType: 3,
            sceneId: 7
        };

    if(1== _decrypt){
        validator.fkv_qq(req, res, function(){
            var verify_valid= req.body.verify_valid;
            if(verify_valid){
                receiveCopuons();
            }
            else{
                return tools.rendJSON(req, res, {returnCode: 0, data: {type: "decrypt", returnMsg: "风控校验失败,请稍后重试。"} } );
            }
        });
    }
    else{
         activity_ctr.mobileRiskCheck(args, function(err, result){
            if (err) {
                // var result1={returnCode:1000, data:null,ip:args.ip, returnMsg: "风控校验失败,请稍后重试。"}
                // return tools.rendJSON(req, res, result1 || {});
                receiveCopuons();
            } else {
                result.data= result.data||{};//兼容
                if(result.data.checkLevel==-1){
                    // var result1={returnCode:1000, data:null,ip:args.ip, returnMsg: "风控校验失败,请稍后重试。"}
                    // return tools.rendJSON(req, res, result1 || {});
                    receiveCopuons();
                }
                else if(result.data.checkLevel==0){
                   receiveCopuons();
                }
                else{
                    if(result.data.checkLevel>4){
                        var result1={returnCode:1001, data:null, returnMsg: "账户异常,优惠券领取失败.<br>如有疑问,请致电：400-090-8822"}
                        return tools.rendJSON(req, res, result1 || {});
                    }
                    else{
                        var type = 1;
                        if(result.data.checkLevel==3||result.data.checkLevel==4){
                            type=2
                        }
                        validator.init({type: type, clientIp: res.locals.config.clientIp}, function(thirdValidation){
                            result= {
                                returnCode:-2,
                                data:{
                                    type: "encrypt",
                                    thirdValidation: thirdValidation
                                },
                                returnMsg:"风控校验"
                            }
                            return tools.rendJSON(req, res, result || {});
                        });
                    }
                }
                
            }
        });   
    }

    function receiveCopuons(){
        activity_ctr.jbhGetCoupons({phone:query.phone,giftBagRuleId:query.giftBagRuleId}, function(err, result) {
            if (err) {
                tools.rendJSON(req, res, result || {});
            } else {
                tools.rendJSON(req, res, result);
            }
        });
    }
});
/**
 * 推荐产品列表
 */
router.get('/api/recommend/getRecommendGoods', function(req, res){
    var query = req.query,
		strategy_id,
		recom_list_id,
        args;

    //console.log(query);

    args = {
        basic_info: {
            wid: query.wid||'',
            channelId: query.channelId || 'h5_front_page_rtr',
            uuid:res.locals.config.venv?res.locals.config.venv.serviceUUID:''
        },
        request: {
            pageId: query.pageId || 1,
            pageSize: parseInt(query.pageSize) || 20
        }
    }


    goods_ctr.getRecommendGoods(args)
        .catch(function(err){
            return tools.rendJSON(req, res, {
                message: 'error on goods_ctr.getRecommendGoods',
                stack: err
            });
        })
        .then(function(resArr){
			if(!resArr.length){
				return {goods_lists:[]}
			}
			strategy_id=resArr.strategy_id
			recom_list_id=resArr.recom_list_id
            var idStr = resArr.map(function(v){
                return v[1];
            }).join(',');
            //console.log(idStr);
            return seller_goods_ctr.deferGetSellerGoods({id: idStr,scenarios:2});
        })
        .catch(function(err){
            return tools.rendJSON(req, res, {
                message: 'error on seller_goods_ctr.deferGetSellerGoods',
                stack: err
            });
        })
        .then(function(data){
            return tools.rendJSON(req, res, [data.goods_lists.map(formatRecommendGoods),recom_list_id,strategy_id]);
        })
        .catch(function(err){
            return tools.rendJSON(req, res, {
                message: 'error on render',
                stack: err
            });
        }).done();
});

/**
 * 相似产品列表
 */
router.get('/api/recommend/getSimilarGoods', function(req, res){
    var query = req.query,
		recom_list_id,
        args;

    args = {
        "basic_info":{
            "wid": query.wid || "",
            "channelId": query.channelId || "find_similarity_recom"
        },
        "request":{
            "paramType": query.paramType || 1,
            "prodList": [query.prodId],
            "pageType": query.pageType || 3
        }
    }

    goods_ctr.getSimilarGoods(args)
        .catch(function(err){
            return tools.rendJSON(req, res, {
                message: 'error on goods_ctr.getSimilarGoods',
                stack: err
            });
        })
        .then(function(resArr){
			recom_list_id=resArr.recom_list_id
            var idStr = resArr.map(function(v){
                return v[1];
            }).join(',');
            //console.log(idStr);
            return seller_goods_ctr.deferGetSellerGoods({id: idStr,scenarios:2});
        })
        .catch(function(err){
            return tools.rendJSON(req, res, {
                message: 'error on seller_goods_ctr.deferGetSellerGoods',
                stack: err
            });
        })
        .then(function(data){
            return tools.rendJSON(req, res, [data.goods_lists.map(formatRecommendGoods),recom_list_id]);
        })
        .catch(function(err){
            return tools.rendJSON(req, res, {
                message: 'error on render',
                stack: err
            });
        }).done();
});

// 新的产品列表页
router.get('/api/recommend/getNewGoods', function(req, res){
    var query = req.query,
        strategy_id,
        recom_list_id,
        args;
        wid= query.qwid,
        page_no = query.page_no,
        version_id = query.version_id

    args = {
        "serviceName":"com.weimob.intpay.smart.cupid.SmartPushService",
        "methodName":"doService",
        "parameterInput":JSON.stringify({"page_size":20,"wid":wid,"page_no":page_no,"version_id":version_id}),
        "applicationName":"intpay.suggest-server"
    }


    goods_ctr.getNewGoods(args)
        .catch(function(err){
            return tools.rendJSON(req, res, {
                message: 'error on goods_ctr.getNewGoods',
                stack: err
            });
        })
        .then(function(resArr){
            strategy_id=resArr.strategy_id;
            recom_list_id=resArr.recom_list_id;
            var idStr = resArr.map(function(v){
                return v[1];
            }).join(',');
          // console.log(idStr);
            return seller_goods_ctr.deferGetSellerGoods({id: idStr,scenarios:2});
        })
        .catch(function(err){
            return tools.rendJSON(req, res, {
                message: 'error on seller_goods_ctr.deferGetSellerGoods',
                stack: err
            });
        })
        .then(function(data){
            return tools.rendJSON(req, res, [data.goods_lists.map(formatRecommendGoods),recom_list_id, strategy_id]);
        })
        .catch(function(err){
            return tools.rendJSON(req, res, {
                message: 'error on render',
                stack: err
            });
        }).done();
});

//APP专享商品二维码
router.post('/api/buySpecialGood',function(req,res){
	goods_ctr.specialGoodCode(req.body,function(err,codeResult){
		if(err|| ~~codeResult.returnCode){
			tools.rendJSON(req,res,{err:true})
            return
		}
		if(req.session.wechat.current.openid){
			goods_ctr.buySpecialGood({
				"app_id":req.session.wechat.current.AppID,
				"open_id":req.session.wechat.current.openid,
				"union_id":req.session.wechat.current.unionid,
				"scene_id":codeResult.responseVo.commandSceneId
			},function(err,result){
				if(err){
                    tools.rendJSON(req,res,{err:true})
				}
				tools.rendJSON(req,res,{
					commandKey:codeResult.responseVo.commandKey,
					url:result.data.url||null,
					pass:true//result.code===0?false:true
				})
			})
		}
		else{
            tools.rendJSON(req,res,{commandKey:codeResult.responseVo.commandKey})
            return
		}
	})
})

/**
 * 大促券
 */
router.post("/api/getCoupon", validator.handleEvent, function (req, res) {
    var query = req.body;
    new Promise(function(resolve, reject){
        // 风控校验
        var pageVcode = query.validate,
            checkData = {
                from: "",
                data: null
            };
        // 防伪变量，保证风控的手机号与领券的手机号一致
        var flag = validator.encodePassCode( (query.mobile||req.session.user.mobile) + "1010-coupon")==query.passcode;
        if (pageVcode) {
            // 用户进行图形验证码的web校验
            checkData = {
                from: "validator",
                data: null
            };
            // 风控手机号与领券手机号不一致，返回状态9002，校验失败
            if (!flag) {
                req.body.verify_valid = false;
            }
            resolve(checkData);
        } else {
            args= {
                mobile: query.mobile || req.session.user.mobile, //兼容
                ip: tools.getClientIp(req),
                bizType: 3,
                sceneId: 4,
                mode: "1010-coupon"
            };
            console.log("riskcheck in:"+JSON.stringify(args));
            activity_ctr.mobileRiskCheck(args, function(err, result){
                console.log("riskcheck out:"+JSON.stringify(result));
                checkData= {
                    from: "mobileRiskCheck",
                    data: {
                        level: err ? 0 : (result.data&&result.data.checkLevel)||9999
                    }
                };
                resolve(checkData);
            });
        }
    }).then(function(checkData){
        if (("mobileRiskCheck"===checkData.from && 1>=checkData.data.level)
            ||("validator"===checkData.from && req.body.verify_valid)){
            // “风险校验通过”或“用户验证码填写正确”，执行领券
            var args = {
                inviteWid: query.mwid || 0,
                invitedWid: query.swid || req.session.user.wid || res.locals.config.vapp.wid || 0,
                invitedPhone: query.mobile || req.session.user.mobile,
                channelSource: query.channelSource || "blank"
            }
            console.log("getCoupon in:"+JSON.stringify(args));
            Activity.getCoupon(args, function (err, result) {
                console.log("getCoupon out:"+JSON.stringify(result));
                tools.rendJSON(req, res, result);
            })
            // tools.rendJSON(req, res, {code:0,message:"success",data:{status:0}});
        } else if ("mobileRiskCheck"===checkData.from && 4>=checkData.data.level) {
            // 初始化验证码
            validator.init({
                type: 3>checkData.data.level ? 1 : 0,
                clientIp: res.locals.config.clientIp 
            }, function(thirdValidation){
                tools.rendJSON(req, res, {
                    code: 9000,
                    message: "您的账号存在风险，需要验证码校验",
                    data: {
                        thirdValidation: thirdValidation,
                        passcode: validator.encodePassCode( (query.mobile || req.session.user.mobile)+ "1010-coupon" )
                    }
                });
            }) 
        } else if ("mobileRiskCheck"===checkData.from && 5<=checkData.data.level) {
            tools.rendJSON(req, res, {
                code: 9001,
                message: "您的账号存在异常",
                data: null
            });
        } else if ("validator"===checkData.from && !req.body.verify_valid) {
            tools.rendJSON(req, res, {
                code: 9002,
                message: "您的校验失败，请稍后再试",
                data: null
            });
        }
    });
})

router.post('/api/venue/vote',function(req,res){
	var args={
		"themeId":req.body.themeId,
		"wid":req.session.user.wid||0,
		"phone":req.session.user.mobile||0
	}
	activity_ctr.killPrice(args, function (err, result) {
		if (err) {
			tools.rendJSON(req, res, result || {});
		} else {
			tools.rendJSON(req, res, result);
		}
	});
})
// 发验证码并调风控
exports.riskVerify = function(req,res){
    var query = req.body,
        mobile = query.mobile;
    /***
    1、异常等级4以上时，不发验证码,提示风险很高
    2、异常等级3~4时，点字验证
    3、异常等级2时滑动图块验证
    4、异常等级0~1时，无需验证正常发验证码
    ***/
    var args= {
        mobile: mobile,
        ip:tools.getClientIp(req),
        bizType: 1,
        sceneId: 18,
        accountType:query.mobile?4:8
    };
    
    activity_ctr.mobileRiskCheck(args,function(err,result){
        result.data= result.data||{};
        var checkLevel = result.data.checkLevel,
            passCode= checkLevel+ "-"+ validator.encodePassCode(checkLevel+ mobile+"-riskVerify"),
            result = {
                code:0,
                data:{
                    checkLevel:checkLevel,
                    passCode:passCode
                },
                message:result.message
            }
        if(err){
            result.data.checkLevel = 5;
            result.message ='你的账号存在风险';
            return tools.rendJSON(req, res, result || {});
        }else{
            
            if (checkLevel <= 1) {
                return tools.rendJSON(req, res, result || {});
            }else{
                if(checkLevel>4){
                    result.data.checkLevel = 5;
                    result.message ='你的账号存在风险';
                    return tools.rendJSON(req, res, result || {});
                } else{
                    var type;
                    //滑块验证
                    if (checkLevel == 2) {
                        type = 1;
                    }
                    //点字验证
                    if(checkLevel==3||checkLevel==4){
                        type=2;
                    }
                    validator.init({type: type, clientIp:res.locals.config.clientIp}, function(thirdValidation){
                        result= {
                            code:0,
                            data:{
                                type: "encrypt",
                                thirdValidation: thirdValidation,
                                checkLevel: checkLevel,
                                passCode:passCode
                            }
                        };
                        return tools.rendJSON(req, res, result || {});
                    });
                }
                

            }
         
        }
        
    })
}
function formatRecommendGoods (item) {

    item.highMarketPrice = seller_goods_ctr.formatNumber(item.highMarketPrice);
    item.sale_price = seller_goods_ctr.formatNumber(item.sale_price);

    return {
        id: item.wp_goods_id,
        title: item.title,
        pic_url: item.pic_url,
        price: item.highMarketPrice || item.sale_price,
        // 这货要区分整数小数部分
        sale_price: ''.split.call(item.sale_price.toFixed(2), '.')
    }
}

module.exports = router;

