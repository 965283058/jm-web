/**
	辅助模块
	author:intpay
	email:eric@weimob.com
	date:2015/02/03
**/
var router = require("./router"),
    url= require("url"),
    qs= require("querystring"),
    user_ctr = require("../../controllers/user"),
    config = require('../../utils/config'),
    admin_ctr= require("../../controllers/admin"),
    statisticsPartner = require("../../utils/statisticsPartner"),
    tools = require('../../utils/tools'),
    verifyCodeHelper= require("../../utils/verifyCodeHelper"),
    qs= require("querystring"),
    proxy= require("../../utils/proxy"),
    QQVcode_utl= require("../../utils/qqVcode"),
    Monitor_utl= require("../../utils/monitor"),
    redisHelper= require("../../models/redisHelper"),
    Statistics2 = require("../../utils/statistics2");


router.all("/util/*?", catchRender, function(req, res, next){
    next();
});

/**
    打开app
    https://m-dev-app.vd.cn/open?param=xxxx&type=0&pkgname=com.hs.yjseller&ckey=CK1295448462798 通用
    http://a.app.qq.com/o/simple.jsp?pkgname=com.hs.yjseller&android_scheme=mdapp%3a%2f%2fmd.app%2fopen%3f  原始
    http://a.app.qq.com/o/simple.jsp?pkgname=com.hs.yjseller&ckey=CK1295448462798  原始
    type: 0-全部跳转应用宝 1－ios单独跳转
    //
    localhost:5000/open?pkgname=com.hs.yjseller&ckey=CK1295448462798&type=1
**/
router.get('/open', function(req, res, next) {
    var link= null,
        query= req.query,
        govd = query.govd,//是否是go.loan.cn过来的
        param= query.param|| "eyJkZXN0Q2xhc3NOYW1lIjoiT3JkZXJGb3JtVmlld0NvbnRyb2xsZXIiLCJzZWd1ZSI6e319";
    //
    var _query= {
        param: param,
        pkgname: "com.hs.yjseller",
        ckey: "CK1295448462798"
    };
    if(/android/i.test(res.locals.config.ua)){
        var link2 = "mdapp://md.app/open?param="+ param;
        //var url_link = encodeURIComponent(link);//此处不再需要编码，因为qs.stringify会进行url编码
        _query.android_scheme= link2;//url_link;
        delete _query.param;
        delete query.param;
    }else{
        
    }
    //非微信环境下直接使用scheme，不经过应用宝打开app
    if (!res.locals.config.isWeixin&&!govd) {
        link = "mdapp://md.app/open?param="+ param;
    } else {
        _query= Object.assign(_query, query);
        var queryStr= qs.stringify(_query);
        link= `http://a.app.qq.com/o/simple.jsp?${queryStr}`;
    }
    //ios 特殊处理
    if(1== query.type&& !/android/i.test(res.locals.config.ua)){
        if(!res.locals.config.isWeixin){
            link= "https://itunes.apple.com/app/apple-store/id945991259?pt=112009858&ct=cpc-yyb&mt=8";
        }
    }

    return res.redirect(link);
});
/* 清空session 数据 */
router.all('/util/:type?', function(req, res, next) {
    var type = req.params.type;
    if(1 == type){
        req.session.wechat= req.session.user = null;
        res.end("success");
    }else if(2== type){
        req.session= null;
        res.end("success");
    }
});


/*下载（我要开微店）*/
router.get("/util/dw/:version?", specialDw, function(req, res, next){
    //统计合伙人页点击下载
    if(req.query.pn == "partnerApply" || req.query.pn == "partnerSuccess"){
        var args = {
            vid: req.query.vid,
            channel: req.query.channel,
            partnertele: req.query.partnertele,
            pop_id: req.query.pop_id,
            action: "download"
        }
        statisticsPartner.invoke(args);
        return res.redirect('https://m-app.vd.cn/open?pkgname=com.hs.yjseller&ckey=CK1295448462798&govd=true');
    }
    //
    var utm_source = req.query.utm_source,
        href = "http://m.intpayment.cn/loan/index",
        hrefs,
        isIosQQ = !/android/gi.test(res.locals.config.ua) && /qq\//gi.test(res.locals.config.ua);
    if(utm_source){
        hrefs = [req.query.ios, req.query.android];
        if(/android/i.test(res.locals.config.ua)){
            href = hrefs[1];
        }else{
            href = hrefs[0];
        }
        if( "wwwvdcn" !== utm_source && (res.localins.config.isWeixin|| isIosQQ ) ){
            res.render("util/download", {
                title: "下载",
                pageName: "download",
                isAndroid: /android/gi.test(res.locals.config.ua),
                isIosQQ: isIosQQ
            });
        }else{
            res.end("<script>location.replace('"+decodeURIComponent(href)+"');</script>"); 
        }
    }else{
        res.redirect(href);
    }    
});

/**
    go.loan.cn
    util/dw/msg2
    partnerApply 的应用宝渠道信息是ckey=CK1295452688631
 */
function specialDw(req, res, next){
    var params= req.params,
        query= req.query,
        paramStr= query.param? "?param="+ query.param: "",
        pageName= query.pageName|| "";
    switch(params.version){
        case "msg":
        case "msg2":
            var monitor= new Monitor_utl().start({
                service: "node-web-msg2download"
            });
            var href= null, isAndroid= false;
            if(/android/gi.test(res.locals.config.ua)){
                isAndroid= true;
                if(pageName.indexOf("partner")>-1){
                    href= "https://m-app.vd.cn/open?pkgname=com.hs.yjseller&ckey=CK1295452688631&govd=true";
                }else{
                    href= "https://m-app.vd.cn/open?pkgname=com.hs.yjseller&ckey=CK1295448462798&govd=true";
                }
            }else{
                if(/(micromessenger|qq)/gi.test(res.locals.config.ua) ){
                    if(pageName.indexOf("partner")>-1){
                        href= "https://m-app.vd.cn/open?pkgname=com.hs.yjseller&ckey=CK1295452688631&govd=true";
                    }else{
                        href= "https://m-app.vd.cn/open?pkgname=com.hs.yjseller&ckey=CK1295448462798&govd=true";
                    }
                }else{
                    href= "https://itunes.apple.com/app/apple-store/id945991259?pt=112009858&ct=cpc-yyb&mt=8";
                }
            }
            monitor.end({
                isSuccess: 1,
                method: "GET-"+ params.version+ "-"+ (isAndroid? "android": "ios")
            });
            if("msg"=== params.version){
                res.redirect(href);
            }else{
                res.render("util/openAPP", {
                    title: "启动萌店app",
                    pageName: "openAPP",
                    isAndroid: isAndroid,
                    href: href,
                    paramStr: paramStr
                });
            }
        break;
        default:
            next();
        break;
    }
}

/**
    订单查询操作
    a)强账号之后，此功能可能废弃
*/ 
router.get('/util/user/login', function(req, res, next) {
    req.getMessage(); // 获取提示信息
    //调用腾讯图形验证码
    if(true){
        var args= {
            userIp: tools.getClientIp(req)
        };
         verifyCodeHelper.createVcode(args, function(err, result){
            _render(null, result.data.queryUrl, 1, result.data.csnonce);
        });
    }else{
        _render();
    }

    function _render(err, result, isTencent, csnonce){
        res.render("util/user/login", {
            title: "登录",
            pageName: "utilLogin",
            captcha: result,
            isTencent: isTencent,
            csnonce: csnonce || 0
        });
    }
});
//用户中心
router.post('/util/user/loginAction', function(req, res, next) {
    var query = req.body,
        verifycode = query.verifycode,
        mobile = query.mobile,
        mode = query.mode;
    // 检查验证码
    user_ctr.checkCode({
        mobile: mobile,
        mode: mode,
        code: verifycode
    }, function (err, result2) {
        if (err) {
            console.log(err);
        } else if (result2.code == 0) {
            user_ctr.getUserByMobile({
                mobile: query.mobile
            }, function (err, result) {
                if (err) {
                    console.log(err);
                } else if (result.code == 0) {
                    if (result.data.user_id) { // 已绑定
                        // 把当前用户放到session中
                        req.session.user = result.data;
                        req.session.user.id = result.data.user_id;
                        req.session.user.openid = result.data.openid || result.data.vd_openid;
                    } else { // 清空当前用户，记忆收货人手机
                        req.session.user ={
                            id: -1,
                            receiverMobile : mobile
                        };
                    }
                    res.redirect("/buyer/user/center?nav=0");
                } else {
                    // 设置提示信息
                    req.setMessage(result.message, '/util/user/login');
                    res.redirect('/util/user/login');
                }
            });
        } else {
            req.setMessage(result2.message, '/util/user/login');
            res.redirect('/util/user/login');
        }
    });
});

//订单查询操作
router.get('/util/admin/config', function(req, res, next) {
   var query= req.query;
   var swth= decodeURIComponent(query.swth);

   try{
   		swth= JSON.parse(swth);
   }catch(e){
   		//console.log(e);
   }
   if("object"!== typeof swth){
   		res.end("config faild");
   }else if(true){

   }
   swth.typeId= "001";

   admin_ctr.setSwthConfig(swth, function(err, result){
   		if(err){
   			res.end(JSON.stringify(err));
   		}else{
   			res.end(JSON.stringify(result));
   		}
   });

});

/**
    node 系统配置文件
 */
router.get('/util/admin/config2', function(req, res, next) {
    var query= req.query,
        typeId= query.typeId,
        configTitles= {
            "001": "合伙人，配置",
            "002": "11.11红包，配置",
            "003": "合伙人，配置"
        };

    var admin= req.session.admin||{};
    if(admin.isAdminLogin){
        var args= {
            typeId: typeId
        };
        admin_ctr.getSwthConfig(args, function(err, result){
            var keys= [], k= null, _config= {}, result= result||{};
            switch(typeId){
                case "001":
                    keys= ["useTecentAPI", "useAccessToken", "useShopCache"];
                    while(k= keys.shift()){
                        _config[k]= ~~result[k];
                    }
                break;
                case "002":
                    keys= ["use", "weixin", "timeline", "weibo", "qzone", "qq", "qweibo", "yixin", "ytimeline", "renren", "message", "copy", "qrcode"];
                    v= config.domain;
                    while(k= keys.shift()){
                        _config[k]= result[k]|| v;
                    }
                break;
            }
            
            _render(null, {
                data: _config
            });
        });
    }else{
        _render(null, {
            data:{}
        });
    }

    function _render(err, result){
        //console.log(result);
        res.render("admin/config", {
            title: "node系统配置",
            pageName: "adminConfig",
            typeId: typeId,
            isAdminLogin: admin.isAdminLogin,
            adminConfig: result.data,
            configTitle: configTitles[typeId]
        });
    }
});

/**
    node 系统配置文件
 */
router.post('/util/admin/config2', function(req, res, next) {
    var query= req.body,
        typeId= query.typeId;
    //
    var admin= req.session.admin||{};
    if(!admin.isAdminLogin){
        res.end("You are not signed in");
    }else{
        var keys= [], k= null, _config= {typeId: typeId};
        switch(typeId){
            case "001":
                keys= ["useTecentAPI", "useAccessToken", "useShopCache"];
                while(k= keys.shift()){
                    _config[k]= ~~query[k];
                }
            break;
            case "002":
                keys= ["use", "weixin", "timeline", "weibo", "qzone", "qq", "qweibo", "yixin", "ytimeline", "renren", "message", "copy", "qrcode"];
                v= config.domain;
                while(k= keys.shift()){
                    _config[k]= query[k]|| v;
                }
            break;
        }
        
        admin_ctr.setSwthConfig(_config, function(err, result){
            if(err){
                res.end("error" );
            }else{
                res.end(JSON.stringify(_config) );
            }
        });
    }
});

router.get('/util/admin/rds', function(req, res, next) {
    var query= req.query,
        type= query.type|| "";

    var user= req.session.user;
    if(!/^(sms|all)$/.test(type)|| !user || !user.wid){
        return res.end("deny!");
    }
    //获取管理员列表
    var rdbk= "admin-1000-all";
    new Promise(function(resolve, reject){

        if("13636607550"== user.mobile){
            resolve();
        }else if("all"=== type&& "13636607550"!== user.mobile){
            reject();
        }else{
            redisHelper.acquire(function(err, client){
                client.get(rdbk, function(err, result){
                    //var result= '["13636607550"]';
                    if(err||! result){
                        reject();
                    }else if((result= JSON.stringify(result), result.indexOf(user.mobile)<0 ) ){
                        reject();
                    }else{
                        resolve();
                    }
                });
            });
        }
    }).then(function(){
        res.render("util/rdsconfig", {
            title: "管理员",
            pageName:"rdsconfig",
            isLogin:1,
            isAdmin: Number("13636607550"== user.mobile),
            type: type
        });
    }).catch(function(err){
        res.end("deny!");
    });
});

router.initConfig= function(typeIds){
    var args= arguments, selfFn= args.callee, typeId= 0;
    //console.log("%s--%s--%s", typeIds, typeIds instanceof Array );
    if(typeIds&& (typeIds instanceof Array)&& typeIds.length){
        typeId= typeIds.shift();
        selfFn(typeIds);
    }
    if(!typeId){
        return;
    }
    admin_ctr.getSwthConfig({typeId: typeId}, function(err, result){
        var keys= [], k= null, _config= {}, result= result||{};
        switch(typeId){
            case "001":
                keys= ["useTecentAPI", "useAccessToken", "useShopCache"];
                while(k= keys.shift()){
                    _config[k]= ~~result[k];
                }
                config.swth= _config;
            break;
            case "002":
                keys= ["use", "weixin", "timeline", "weibo", "qzone", "qq", "qweibo", "yixin", "ytimeline", "renren", "message", "copy", "qrcode"];
                v= config.domain;
                while(k= keys.shift()){
                    _config[k]= result[k]|| v;
                }
                config["swth002"]= _config;
            break;
        }
    });
}

/**
    vcode for APP
*/ 
router.get('/util/app/vcode', function(req, res, next) {
    var query= req.query,
        vcode= query.vcode;
    var args= {
        cip: res.locals.config.clientIp,
        businessId: parseInt(config.env.slice(0, 2), 32)
    };
    QQVcode_utl.createVcode(args, function(err, result){
        res.render("util/app/vcode", {
            title: "appVcode",
            pageName: "appVcode",
            url: result.url,
            vcode: vcode
        });
    });
});
/******************************************************************************************
    pv& uv统计
******************************************************************************************/
function catchRender(req, res, _next){
    //统计
    var render = res.render,
        next = function(){
            res.render = function(view, options, fn){
                options.isLogin= req.session.user.mobile>1000;
                render.apply(res, arguments);
                var _statistics= options.statistics|| {};
                new Statistics2().invoke(req, res, _next, {
                    action: {
                        elementid: "pv",
                        eventtype: "view"
                    },
                    page: {
                        pagename: options.pageName
                    },
                    business: _statistics.business
                });
            }
            _next();
        };
    next();
}
/**
    读取配置文件
    a)001 ["useTecentAPI", "useAccessToken", "useShopCache"];
    b)002 ["use", "weixin", "timeline", "weibo", "qzone", "qq", "qweibo", "yixin", "ytimeline", "renren", "message", "copy", "qrcode"];
 */
router.initConfig(["002"]);
module.exports = router;