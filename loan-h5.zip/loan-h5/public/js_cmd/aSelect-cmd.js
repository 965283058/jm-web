define(function (require, exports, module) {

    var $ = require("lib_cmd/zepto-cmd");
    var aLocation = require("lib_cmd/aLocation-cmd");

    var ATTR_DATA_VALUE = "data-value";

    /**
     * 省市区地址下拉框
     * @param apro 省 {HTMLSelectElement}
     * @param acit 市 {HTMLSelectElement}
     * @param aare 区 {HTMLSelectElement}
     * @param apv 省编码，默认从下拉框的data-value属性中获取。
     * @param acv 市编码，默认从下拉框的data-value属性中获取。
     * @param aav 区编码，默认从下拉框的data-value属性中获取。
     */
    function aSelect(apro, acit, aare, apv, acv, aav) {
        apv = apv || $(apro).attr(ATTR_DATA_VALUE);
        acv = acv || $(acit).attr(ATTR_DATA_VALUE);
        aav = aav || $(aare).attr(ATTR_DATA_VALUE);
        this.apro = apro;
        this.acit = acit;
        this.aare = aare;
        this.values = [];
        this.values.push(apv || 0, acv || 0, aav || 0);
        this.level = 3;
        this.init();
    }

    aSelect.prototype = {
        constructor: aSelect,
        init: function () {
            var self = this;
            self.apro.addEventListener("change", self, false);
            self.acit.addEventListener("change", self, false);
            self.aare && self.aare.addEventListener("change", self, false);
            self.handleEvent({target: {value: self.apro.value}});
            return self;
        },
        handleEvent: function (evt) {
            var self = this,
                ele = evt.target;
            switch (ele) {
                case self.apro:
                    self.values[0] = self.apro.value;
                    self.setOption(self.acit, aLocation["0," + self.values[0]], 1);
                    self.handleEvent({target: self.acit});
                    break;
                case self.acit:
                    self.values[1] = self.acit.value;
                    if (self.aare) {
                        self.setOption(self.aare, aLocation["0," + self.values[0] + "," + self.values[1]], 2);
                        self.handleEvent({target: self.aare});
                        //判断是否存在三级地区
                        self.level = aLocation["0," + self.values[0] + "," + self.values[1]] < 1 ? 2 : 3;
                        $(self.aare).attr("data-required", self.level >= 3).parent().css("display", self.level < 3 ? "none" : "block");
                    }
                    break;
                case self.aare:
                    self.values[2] = self.aare.value;
                    break;
                default:
                    self.setOption(self.apro, aLocation[0], 0);
                    self.handleEvent({target: self.apro});
                    break;
            }
        },
        setOption: function (ele, data, index) {
            var self = this,
                val = 0,
                _val = self.values[index];
            ele.options.length = 1;
            for (var d in data) {
                (d == _val) && (val = d);
                ele.options.add(new Option(data[d], d));
            }
            ele.value = self.values[index] = val;
            return self;
        }
    }
    aSelect.geocoder= function(args, fn){
        if(args.lat&& args.lng){
            $.ajax({
                type: "POST",
                url: APP.urls.geocoder_url,
                //cache: false,
                data: {
                   lat: args.lat||39.984154,
                   lng: args.lng||116.307490
                },
                async:true,
                success: function(result){
                   handleGeocoder.call(this, result);
                },
                dataType: "json"
            });
        }else{
            fn({province_id: 0, city_id: 0, district_id: 0, address: ""});
        }
         
        //
        function handleGeocoder(result){
            var location = result.data,
                names = [location.province, location.city, location.district],
                k,
                keys = [0],
                ck,
                cur_aLocation = {};
            function getK(name){
                if(name){
                    cur_aLocation = aLocation[keys.join(",")];
                    for(k in cur_aLocation){
                        ck = cur_aLocation[k];
                        if(name.indexOf(ck)>-1){
                            break;
                        }
                    }
                    keys.push(k);
                }else{
                    keys.push(0);
                }
                if(names.length>0){
                    arguments.callee(names.shift());
                }
            }
            getK(names.shift());
            location.province_id = keys[1];
            location.city_id = keys[2];
            location.district_id = keys[3];
            fn(location);
        }
    }

    /**
     * 根据微信地址获取相应的地址码
     * @author Henry(jiabin.chen@weimob.com)
     * @param {object} address 微信格式 {provinceName:'',cityName:'',countryName:''}
     */
    aSelect.getAddressCode = function (address) {
        var code = {
            province: 0,
            city: 0,
            zone: 0
        }
        var tempKey = '0';
        for (key in aLocation[tempKey]) {
            if (address.provinceName.indexOf(aLocation['0'][key]) != -1) {
                code.province = key;
                break;
            }
        }
        tempKey = '0,'+code.province;
        for (key in aLocation[tempKey]) {
            if (address.cityName.indexOf(aLocation[tempKey][key]) != -1) {
                code.city = key;
                break;
            }
        }
        tempKey = '0,'+code.province+','+code.city;
        for (key in aLocation[tempKey]) {
            if (address.countryName.indexOf(aLocation[tempKey][key]) != -1) {
                code.zone = key;
                break;
            }
        }
        return code;
    },
    aSelect.checkValid= function(apv, acv, aav){
        var vLevel= 0;
        if(!parseInt(apv) ){
            vLevel= 1; //no province
        }else if(!parseInt(acv) ){
            vLevel= 2; //no city
        }else if(!parseInt(aav)&&  Object.keys(aLocation[0+ ","+ apv+ ","+ acv]).length>0){
            vLevel= 3; //no zone
        }
        return vLevel;
    }

    module.exports = aSelect;
});
