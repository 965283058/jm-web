define(function(require,exports,module){
	function PopPage(id,styleURL){
		var div=document.createElement('div')
		id&&(div.id=id)
		div.className='PopPage'
		div.style.display='none'
		div.addEventListener('transitionend',PopPage._hide)
		var dismiss=document.createElement('div')
		dismiss.className='dismiss'
		div.appendChild(dismiss)
		document.body.appendChild(div)
		if(styleURL){
			var link=document.createElement('link')
			link.rel='stylesheet'
			link.href=styleURL
			document.head.appendChild(link)
		}
		var self=this
		this.el=div
		this.dismiss=dismiss
		this.dismissHandler=function(){
			self.close()
		}
		this.window={}
		this.activeWindow=''
	}
	PopPage._noScroll=function(e){
		e.preventDefault()
	}
	PopPage._hide=function(){
		if(!this.classList.contains('see')){
			this.style.display='none'
		}
	}
	PopPage.prototype.addWindow=function(windowOption){
		var self=this
		if(!windowOption.length){
			windowOption=[windowOption]
		}
		windowOption.forEach(function(v){
			self.window[v.id]=new WindowBody(v)
		})
		if(this.activeWindow){
			this.el.removeChild(this.activeWindow)
		}
		this.el.appendChild(this.window[windowOption[0].id])
		this.activeWindow=this.window[windowOption[0].id]
	}
	PopPage.prototype.pop=function(id,canDismiss,canScroll){
		var self=this
		if(!this.el.style.display){
			return false
		}
		if(id&&typeof id=='string'){
			if(!this.window[id]){
				return false
			}
			if(id!=this.activeWindow.id){
				this.el.removeChild(this.activeWindow)
				this.el.appendChild(this.window[id])
				this.activeWindow=this.window[id]
			}
		}
		else{
			canScroll=canDismiss
			canDismiss=id
		}
		this.dismiss[canDismiss?'addEventListener':'removeEventListener']('click',this.dismissHandler)
		this.el[canScroll?'removeEventListener':'addEventListener']('touchmove',PopPage._noScroll)
		this.el.style.display=''
		requestAnimationFrame(function(){
			self.el.classList.add('see')
		})
		return true
	}
	PopPage.prototype.change=function(id,canDismiss,canScroll){
		if(this.el.style.display||!id||id==this.activeWindow.id||!this.window[id]){
			return false
		}
		this.el.removeChild(this.activeWindow)
		this.el.appendChild(this.window[id])
		this.activeWindow=this.window[id]
		this.dismiss[canDismiss?'addEventListener':'removeEventListener']('click',this.dismissHandler)
		this.dismiss[canScroll?'removeEventListener':'addEventListener']('touchmove',PopPage._noScroll)
		return true
	}
	PopPage.prototype.close=function(gone){
		this.el.classList.remove('see')
		if(gone){
			this.el.style.diaplay='none'
		}
	}
	function WindowBody(opt){
		var article=document.createElement('article')
		if(typeof opt.id=='string'){
			article.id=opt.id
		}
		article.innerHTML=opt.html
		if(opt.action){
			opt.action(article)
		}
		return article
	}
	module.exports=PopPage
})