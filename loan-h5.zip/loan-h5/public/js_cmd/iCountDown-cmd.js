define(function(require, exports, module) { 
/**
*   =============================    iCountDown   ============================
*   [param]         [type]          [default]
*   settings        //object    ==> {}
*       day         //number    ==> 0
*       hour        //number    ==> 0
*       minute      //number    ==> 0
*       second      //number    ==> 0
*       $day        //object    ==> document.getElementById('dayCtrl')
*       $hour       //object    ==> document.getElementById('hourCtrl')
*       $minute     //object    ==> document.getElementById('minuteCtrl')
*       $second     //object    ==> document.getElementById('secondCtrl')
*   callback        //function  ==> null
*   isDoubleNumber  //boolean   ==> false
*   ==========================================================================
*   Author: Rock.Zhang
*   Date:   2015/08/20
**/ 
    var iCountDown=function(settings,callback,isDoubleNumber,callback2){
        settings = settings|| {};
        this.day=settings.day || 0;
        this.hour=settings.hour || 0;
        this.minute=settings.minute || 0;
        this.second=settings.second || 0;
        this.$day=settings.$day || document.getElementById('dayCtrl');
        this.$hour=settings.$hour || document.getElementById('hourCtrl');
        this.$minute=settings.$minute || document.getElementById('minuteCtrl');
        this.$second=settings.$second || document.getElementById('secondCtrl');
        this.isDoubleNumber=isDoubleNumber ||false;
        this.callback=callback ||null;
        this.callback2=callback2 || null;
        this.index = settings.index;//序号记忆
        this.stop = false;//是否停止计时了
        this.init();
    }
    iCountDown.prototype.init=function(){
        var self=this;
        if(!this.$second){
            console.log('Please set time container!');
            return;
        }
        self.timeAdjust();
        self.refreshPageTime();
        if(self.getIsTimeUp()){
            if(self.callback)
                self.callback();
            return; 
        }
        var isAgain=true;
        countDown();
        function countDown(){setTimeout(timeCheck,1000);}
        function timeCheck(){
            if (!self.stop) {
                self.second?self.doSecondMinus():self.minute?self.doMinuteMinus():self.hour?self.doHourMinus():self.day?self.doDayMinus():null;
                self.refreshPageTime();
                self.getIsTimeUp()?self.callback?self.callback():null:countDown();
                self.switchDay();
            }
        }
    }
    iCountDown.prototype.stopCountDown=function(callback){
        this.stop = true;
        this.day=0;this.hour=0;this.minute=0;this.second=0;
        callback&&callback(); 
        // var stopCallBack=callback || this.callback;
        // this.callback=null;
        // if(stopCallBack)
        //     stopCallBack();
    }
    iCountDown.prototype.getIsTimeUp=function(){
        return (!this.day && !this.hour && !this.minute && !this.second);
    }
    iCountDown.prototype.timeAdjust=function(){
        if('object' != typeof(this.$day))
            this.hour+=this.day*24;
        if('object' != typeof(this.$hour))
            this.minute+=this.hour*60;
        if('object' != typeof(this.$minute))
            this.second+=this.minute*60;
    }
    iCountDown.prototype.refreshPageTime=function(){
        var self=this;
        ['day','hour','minute','second'].forEach(function(column){
            if (column == 'day') {//对于天不截取两位
                self['$'+column]?self['$'+column].innerHTML=self[column]+1:'0';
            } else {
                self['$'+column]?self['$'+column].innerHTML=self.getDoubleNumber(self[column]):'00';
            }          
        })
    }
    iCountDown.prototype.getDoubleNumber=function(num){
        var value = num; 
        if(this.isDoubleNumber) {
            if (value < 10) {
                value = '0' + value;
            }
        }
        value = value + '';
        return value;
        //return this.isDoubleNumber?('0'+num).match(/\d{2}\b/):num;  
    }
    iCountDown.prototype.doDayMinus=function(){
        this.day--;this.hour=23;this.minute=59;this.second=59;  
    }
    iCountDown.prototype.doHourMinus=function(){
        this.hour--;this.minute=59;this.second=59;  
    }
    iCountDown.prototype.doMinuteMinus=function(){
        this.minute--;this.second=59;
    }
    iCountDown.prototype.doSecondMinus=function(){
        this.second--;
    }
    //小于24小时时显示时分秒,否则显示天
    iCountDown.prototype.switchDay=function(){
        var self = this;
        if (self.day < 1 && self.callback2) {
            self.callback2(self.index);
        }
    }
    module.exports=iCountDown;
}) 