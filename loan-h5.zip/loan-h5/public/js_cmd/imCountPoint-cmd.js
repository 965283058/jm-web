define(function(require, exports, module){
    var $ = window._$ = require('lib_cmd/zepto-cmd'),
        Swipe = require("lib_cmd/swipe-cmd"),
        ImageUpload = require("lib_cmd/imageUpload-cmd"),
        myDialog = require("lib_cmd/myDialog-cmd"),
        whatever = require('lib_cmd/easymob-webim-SDK1.0-cmd/strophe-custom-2.0.1-cmd'), //兼容grunt压缩
        Easemob = require("lib_cmd/easymob-webim-SDK1.0-cmd/easemob.im-1.0.7-cmd");


    /*****************************
     环信类
     *******************************/
    function webim(args){
        // this.bizId = args.bizId || null;
        // this.bizType = args.bizType || 2; //bizType:业务类型，1：萌店主 2：萌店买家 3：萌店临时买家 4：供应商 5：旺铺商家
        this.imType = args.imType || 1; //第三方消息中心类型，1： 环信
        this.username = args.username || null; //imucid
        this.password = args.password || null;
        this.appKey = args.appKey || 'dwm716#weiim';
        this.avatar = '';//用户头像
        this.nickname = '';//用户昵称

        this.hisAvatar = '';// 对方头像
        this.hisNickName = ''; //对方昵称
        this.hisId = null; //对方imucuid

        this.lastMsgTime = 0; //记录上一条消息的时间
        this.curPage = 0; //历史消息目前加载到哪页
        this.pageSize = 20; //每页加载多少条历史消息
        this.isBind = false; //是否监听滚动加载历史消息事件
        this.lock = false; //是否锁定滚动事件
        this.historyMsg = null; //存储读取到的历史消息
        this.historyLoaded = false; //是否已加载过历史消息
        this.lastBodyHeight = 0; //记录每次加载历史消息之前的Body高度

        this.sendQueue = []; //记录目前在等待发送的消息的id
        this.otherMsg = {}; //当非此卖家发来消息时记录消息时间

        this.conn = new Easemob.im.Connection();
        this.init();
    }
    webim.prototype = {
        init: function(){
            var self = this;
            self.conn.init({
                https: true,
                onOpened: function(){
                    self.conn.setPresence();
                    console.log("登录成功");
                    $("#mask").hide();
                    //调用addTempChat，此接口仅为后端统计用
                    $.ajax({
                        type: "POST",
                        url: APP.urls.addTempChat,
                        data:{
                            data:{
                                requestImucUid: self.username,
                                responseImucUid: self.hisId,
                                relationType: 3
                            }
                        },
                        async: true,
                        success: function(result){
                            console.log("addTempChat");
                        },
                        dataType: "json"
                    });
                    //加载历史消息并监听
                    //self.readMessage();
                    //$(window).scrollTop($('body').height());
                    //self.bindSc();
                },
                onTextMessage: function(message){
                    self.handleTextMessage(message);
                },
                onReceivedMessage: function(message){
                    var msgId = message.getElementsByTagName('body')[0].childNodes[0].nodeValue;
                    //从发送队列里去掉已正确发送的消息
                    for(var i = 0; i < self.sendQueue.length; i++){
                        if(msgId == self.sendQueue[i]){
                            //console.log(msgId);
                            self.sendQueue = self.sendQueue.slice(0,i).concat(self.sendQueue.slice(i+1));
                            break;
                        }
                    }
                    var msgIds = [msgId];
                    //刷新存储的该消息的发送状态
                    self.modifyHistory(msgIds, "success");
                    //
                    $("[data-id="+msgId+"]").prev().removeClass('sending-run');
                },
                onClosed: function(){
                    //console.log("closed");
                    //刷新存储的该消息的发送状态l
                    self.modifyHistory(self.sendQueue, "fail");
                    self.sendQueue = [];
                    if($('.sending-run')){
                        $('.sending-run').removeClass('sending-run').addClass('sending-fail');
                    }
                    self.bindResend();
                },
                onError: function(message){
                    console.log("error: ",message);
                    //alert("网络不给力", {
                    //    TPL: '<div class="widget_wrap" style="z-index:{zIndex2};">\
						//	<div class="widget_header"></div>\
						//	<div class="widget_body">{str}</div>\
						//	<div class="widget_footer">\
						//		<ul>\
						//			<li><button type="button">再试一次</button></li>\
						//		</ul>\
						//	</div>\
						//</div>',
                    //    callBack: function(evt){
                    //        var that = this,ele = null;
                    //        if(evt && (ele = evt.target) && ("BUTTON" == ele.tagName) ){
                    //            location.reload(true);
                    //        }
                    //    }
                    //});
                }
            });
			self.login();
			return self;
            //获取店主imucuid，获取成功后登录
        },

        //登录，如果没有用户则先注册
        login: function(){
            var self = this,
                url = APP.urls.registerGet;

            $.ajax({
                type: "POST",
                url: url,
                data: {
                    data:{
                        imType: self.imType,
                        attrKeys: ["nickName","imgUrl"],
                        settingKeys: [""]
                    }
                },
                async:true,
                success: function(result){
                    //console.log(result);
                    if(0 == result.code.errcode){
                        self.username = JSON.stringify(result.data.imucUid);
                        self.avatar = result.data.attrs.imgUrl;
                        self.nickname = result.data.attrs.nikcName;
                        self.password = result.data.passwd;
						self.getMerchantInfo();
                    }
                },
                dataType: "json"
            });
        },
		getMerchantInfo:function(){
			var self = this;
			var reqData = {},
				reqUrl = '';
			if (!!APP.shopId&&APP.shopId!='0'&&APP.shopId!='undefined') { //供货商商品则联系供货商
				reqUrl = APP.urls.getUserInfoFromBiz;
				reqData = {
					imType: self.imType,
					bizType: 1,
					bizId: APP.shopId,
					attrKeys: ["nickName", "imgUrl"],
					settingKeys: [""]


				}
			} else {
				reqUrl = APP.urls.getSupplier;
				reqData = {
					imType: self.imType,


					bizType: 4,
					bizId: APP.aid,
					attrKeys: ["nickName", "imgUrl"],
					settingKeys: [""],
					ClientInfo: {
						BaseAppType: "H5"
					},
					requestImucId: self.username
				}
			}
			$.ajax({
                    type: "POST",
                    url: reqUrl,
                    data:{
                        data:reqData
                    },
                    async: true,
                    success: function(result){
                        //console.log(result);
                        if(0 == result.code.errcode){
                            self.hisAvatar = result.data.attrs.imgUrl;
                            self.hisNickName = result.data.attrs.nickName;
                            self.hisId = JSON.stringify(result.data.imucUid);
                            self.conn.open({
								user: self.username,
								pwd: self.password,
								appKey: self.appKey
							});
                        }
                        else if(7000001 == result.code.errcode){
                        }
                    },
                    dataType: "json"
                });
		},
        //发送消息
        sendMessage: function(args){
            var self = this;
            var options = {
                to: self.hisId,
                msg: JSON.stringify(args),
                type: "chat"
            };
            //判断是否添加时间
            var now = new Date().getTime();
            var deltaTime = now - self.lastMsgTime;
            if(deltaTime > 60000){
                self.appendTime(now);
            }
            self.lastMsgTime = now;
            //发送消息
            self.conn.sendTextMessage(options, function(webimId){
                var message = {
                    user: 'webim'+self.username,
                    shop: 'vidim'+self.hisId,
                    content: {
                        from: self.username,
                        to: self.hisId,
                        type: args.type,
                        id: webimId,
                        status: "sending",
                        message: args.message
                    }
                };
                self.appendMsg(self.username, self.hisId, args.message, args.type, message.content.id);
                //在本地存储消息
                self.saveMessage(message);
                //存储目前等待发送的消息的id
                self.sendQueue.push(message.content.id);
            });
            //滚动条至底
            $(window).scrollTop($('body').height());
        },
        //以下为消息处理函数
        handleTextMessage: function(message){
            var self = this;
            var from = message.from;//消息的发送者
            var to = message.to; //消息的接收者
            var messageContent = message.data;//文本消息体
            //解析消息
            var parsedMsg = JSON.parse(messageContent),
                messageBody = parsedMsg.message,
                messageType = parsedMsg.type;
            //判断是否添加时间
            var now = new Date().getTime();
            var deltaTime = now - self.lastMsgTime;
            //仅当收到的消息为该店主发来的才显示，否则只存储
            if(from == self.hisId){
                if(deltaTime > 60000){
                    self.appendTime(now);
                }
                self.lastMsgTime = now;

                var count = localStorage['weimobIMCount'+APP.shopId]||0;
                count++;
                localStorage['weimobIMCount'+APP.shopId] = count;
                displayRadius();
                //self.appendMsg(from, to, messageBody, messageType, "receivedMsg");
            }
            else{
                //若非该店主发来的消息，则需根据判断来存储时间
                var otherTime = {
                    user: 'webim'+self.username,
                    shop: 'vidim'+from,
                    content: {
                        from: from,
                        to: to,
                        type: "time",
                        id: new Date().getTime(),
                        status: "success",
                        message: now
                    }
                };
                if(self.otherMsg.hasOwnProperty(from)){
                    if(now-self.otherMsg[from] > 60000){
                        self.saveMessage(otherTime);
                    }
                }
                else{
                    self.saveMessage(otherTime);
                }
                self.otherMsg[from] = now;
            }
            //在本地存储消息
            var msg = {
                user: 'webim'+self.username,
                shop: 'vidim'+from,
                content: {
                    from: from,
                    to: to,
                    type: messageType,
                    id: new Date().getTime(),
                    status: "success",
                    message: messageBody
                }
            }
            self.saveMessage(msg);
            //滚动条至底
            //$(window).scrollTop($('body').height());
        },
        //添加时间栏
        appendTime: function(time){
            var self = this;
            var dateObj = new Date(time);
            var year = '' + dateObj.getFullYear(),
                month = '' + (dateObj.getMonth() + 1),
                day = '' + dateObj.getDate(),
                hour = '' + dateObj.getHours(),
                minute = '' + dateObj.getMinutes();
            hour = hour.length == 1 ? '0'+hour : hour;
            minute = minute.length == 1 ? '0'+minute : minute;
            var timeStr = hour + ':' + minute;
            var TPL = '<div class="time-wrap"><label>'+timeStr+'</label></div>';
            $('#conversation').append(TPL);
            //时间标识也需作为历史消息存储
            var message = {
                user: 'webim'+self.username,
                shop: 'vidim'+self.hisId,
                content: {
                    from: self.username,
                    to: self.hisId,
                    type: "time",
                    id: new Date().getTime(),
                    status: "success",
                    message: time
                }
            }
            self.saveMessage(message);
        },
        //添加消息的处理函数
        //appendMsg: function(who, to, message, chatType, saveId, isHistory, statusHistory){
        //    var localMsg = null,
        //        self = this,
        //        TPL = null,
        //        sendingStatus = "",
        //        originMsg = {type: chatType, message: message};
        //
        //    if(isHistory){
        //        sendingStatus = statusHistory == "success" ? "":"sending-fail";
        //    }
        //    else{
        //        sendingStatus = "sending-run";
        //    }
        //
        //    //普通文本消息
        //    if(chatType == "text"){
        //        if (typeof message == 'string') {
        //            localMsg = Easemob.im.Helper.parseTextMessage(message);
        //            localMsg = localMsg.body;
        //        } else {
        //            localMsg = message.data;
        //        }
        //        //匹配消息中的url
        //        var strRegex = "((http|ftp|https)://)(([a-zA-Z0-9\\._-]+\\.[a-zA-Z]{2,6})|([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}))(:[0-9]{1,4})?(/[a-zA-Z0-9\\&%_\\./-~-]*)?";
        //        var searchObj = new RegExp(strRegex, "g");
        //
        //        var html_msg = '';
        //        for(var i = 0; i < localMsg.length; i++){
        //            var type = localMsg[i].type;
        //            var data = localMsg[i].data;
        //            if(type == "txt"){
        //                var regData = data.replace(searchObj, function($1, $2){
        //                    var msgLink = "";
        //                    if(who == self.username){
        //                        msgLink = "my-link";
        //                    }
        //                    else{
        //                        msgLink = "his-link";
        //                    }
        //                    var urlLink = '<a href="'+$1+'" class="'+msgLink+'">'+$1+'</a>';
        //                    return urlLink;
        //                });
        //                html_msg += '<span>'+regData+'</span>';
        //            }
        //            else if(type == "emotion"){
        //                html_msg +='<img src="'+data+'">';
        //            }
        //        }
        //        //
        //        if(who == self.username){
        //            TPL = '<div class="message-wrap">\
        //				<div class="my-message">\
        //					<div class="sending-wrap">\
        //						<div class="sending-icon '+sendingStatus+'"></div>\
        //						<input type="hidden" data-id='+saveId+' value='+JSON.stringify(originMsg)+'>\
        //					</div>\
        //					<div class="content-wrap">\
        //						<div class="content">\
        //							<p>'+html_msg+'</p>\
        //						</div>\
        //						<div class="little-horn"></div>\
        //					</div>\
        //					<div class="avatar">\
        //						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+self.avatar+');>\
        //					</div>\
        //				</div>\
        //			</div>';
        //        }
        //        else{
        //            TPL = '<div class="message-wrap">\
        //        		<div class="his-message">\
        //        			<div class="avatar">\
        //        				<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+self.hisAvatar+');>\
        //        			</div>\
        //        			<div class="content-wrap">\
        //        				<div class="content">\
        //        					<p>'+html_msg+'</p>\
        //        				</div>\
        //        				<div class="little-horn"></div>\
        //        			</div>\
        //        		</div>\
        //        	</div>';
        //        }
        //    }
        //    //商品链接消息
        //    else if(chatType == "goods"){
        //        if(who == self.username){
        //            TPL = '<div class="message-wrap">\
        //				<div class="my-message">\
        //					<div class="sending-wrap">\
        //							<div class="sending-icon '+sendingStatus+'"></div>\
        //							<input type="hidden" data-id='+saveId+' value='+JSON.stringify(originMsg)+'>\
        //						</div>\
        //					<div class="content-wrap">\
        //						<div class="content content-goods">\
        //							<a href="'+message.url+'" class="goods-consult">\
        //								<div>\
        //									<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+message.imgUrl+');>\
        //								</div>\
        //								<div>\
        //									<span>意向咨询商品</span>\
        //									<span>'+message.title+'</span>\
        //								</div>\
        //							</a>\
        //						</div>\
        //						<div class="little-horn"></div>\
        //					</div>\
        //					<div class="avatar">\
        //						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+self.avatar+');>\
        //					</div>\
        //				</div>\
        //			</div>';
        //        }
        //        else{
        //            TPL = '<div class="message-wrap">\
        //				<div class="his-message">\
        //					<div class="avatar">\
        //						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+self.hisAvatar+');>\
        //					</div>\
        //					<div class="content-wrap">\
        //						<div class="content content-goods">\
        //							<a href="'+message.url+'" class="goods-consult">\
        //								<div>\
        //									<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+message.imgUrl+');>\
        //								</div>\
        //								<div>\
        //									<span>商品</span>\
        //									<span>'+message.title+'</span>\
        //								</div>\
        //							</a>\
        //						</div>\
        //						<div class="little-horn"></div>\
        //					</div>\
        //				</div>\
        //			</div>';
        //        }
        //    }
        //    //维权消息
        //    else if(chatType == "rights"){
        //        TPL = '<div class="message-wrap">\
        //				<div class="my-message">\
        //					<div class="sending-wrap">\
        //							<div class="sending-icon '+sendingStatus+'"></div>\
        //							<input type="hidden" data-id='+saveId+' value='+JSON.stringify(originMsg)+'>\
        //						</div>\
        //					<div class="content-wrap">\
        //						<div class="content content-goods">\
        //							<a href="'+message.url+'" class="rights-consult">\
        //								<div>\
        //									<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+message.imgUrl+');>\
        //								</div>\
        //								<div>\
        //									<span>维权单</span>\
        //									<span>'+message.title+'</span>\
        //									<span>维权状态：'+message.status+'</span>\
        //								</div>\
        //							</a>\
        //						</div>\
        //						<div class="little-horn"></div>\
        //					</div>\
        //					<div class="avatar">\
        //						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+self.avatar+');>\
        //					</div>\
        //				</div>\
        //			</div>';
        //    }
        //    //图片消息
        //    else if(chatType == "image"){
        //        var url = message.url,
        //            thumbnailUrl = message.thumbnailUrl,
        //            picId = message.picId;
        //
        //        var html_msg = picId ? '<img data-picId="'+picId+'" class="picMsg loadPic" src="'+url+'">' : '<img class="picMsg" src="'+url+'">';
        //
        //        if(who == self.username){
        //            TPL = '<div class="message-wrap">\
        //				<div class="my-message">\
        //					<div class="sending-wrap">\
        //						<div class="sending-icon '+sendingStatus+'"></div>\
        //						<input type="hidden" data-id='+saveId+' value='+JSON.stringify(originMsg)+'>\
        //					</div>\
        //					<div class="content-wrap">\
        //						<div class="content">\
        //							<p>'+html_msg+'</p>\
        //						</div>\
        //						<div class="little-horn"></div>\
        //					</div>\
        //					<div class="avatar">\
        //						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+self.avatar+');>\
        //					</div>\
        //				</div>\
        //			</div>';
        //        }
        //        else{
        //            TPL = '<div class="message-wrap">\
        //        		<div class="his-message">\
        //        			<div class="avatar">\
        //        				<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style=background-image:url('+self.hisAvatar+');>\
        //        			</div>\
        //        			<div class="content-wrap">\
        //        				<div class="content">\
        //        					<p>'+html_msg+'</p>\
        //        				</div>\
        //        				<div class="little-horn"></div>\
        //        			</div>\
        //        		</div>\
        //        	</div>';
        //        }
        //    }
        //    //时间消息（这个消息只在读取历史消息时有用）
        //    else if(chatType == "time"){
        //        var days = ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'],
        //            showTime = '';
        //
        //        var dateObj = new Date(message);
        //        var year = dateObj.getFullYear(),
        //            month = dateObj.getMonth() + 1,
        //            date = dateObj.getDate(),
        //            day = dateObj.getDay(),
        //            hour = '' + dateObj.getHours(),
        //            minute = '' + dateObj.getMinutes();
        //        hour = hour.length == 1 ? '0'+hour : hour;
        //        minute = minute.length == 1 ? '0'+minute : minute;
        //
        //        var now = new Date();
        //        var yearNow = now.getFullYear(),
        //            monthNow = now.getMonth() + 1,
        //            dateNow = now.getDate(),
        //            dayNow = now.getDay(),
        //            hourNow = '' + now.getHours(),
        //            minuteNow = '' + now.getMinutes();
        //        hourNow = hourNow.length == 1 ? '0'+hourNow : hourNow;
        //        minuteNow = minuteNow.length == 1 ? '0'+minuteNow : minuteNow;
        //
        //
        //        var todayStart = new Date();
        //        todayStart.setFullYear(yearNow);
        //        todayStart.setMonth(monthNow-1);
        //        todayStart.setDate(dateNow);
        //        todayStart.setHours(0);
        //        todayStart.setMinutes(0);
        //        todayStart.setSeconds(0);
        //        todayStart.setMilliseconds(0);
        //
        //        var yesterdayStart = new Date(todayStart-24*60*60*1000);
        //        var sevenDaysAgo = new Date(todayStart - 6*24*60*60*1000);
        //        //今天
        //        if(dateObj >= todayStart){
        //            showTime = hour + ':' + minute;
        //        }
        //        //昨天
        //        else if(dateObj < todayStart && dateObj >= yesterdayStart){
        //            showTime = "昨天 " + hour + ':' + minute;
        //        }
        //        //一周内
        //        else if(dateObj < yesterdayStart && dateObj >= sevenDaysAgo){
        //            showTime = days[day] + ' ' + hour + ':' + minute;
        //        }
        //        //7天前
        //        else if(dateObj < sevenDaysAgo){
        //            showTime = year + '-' + month + '-' + date + ' ' + hour + ':' + minute;
        //        }
        //
        //        TPL = '<div class="time-wrap"><label>'+showTime+'</label></div>';
        //    }
        //    //
        //    if(TPL){
        //        if(isHistory){
        //            return TPL;
        //        }
        //        else{
        //            $('#conversation').append(TPL);
        //        }
        //    }
        //},
        //将消息存在本地，作为历史消息
        saveMessage: function(message){
            var self = this;
            if(window.localStorage){
                //在存储历史消息时都先对message做处理，即添加存储的时间time
                message.content.saveTime = new Date().getTime();
                //获取该用户所有的历史消息
                var userMsg = localStorage[message.user] ? JSON.parse(localStorage[message.user]) : null;
                if(userMsg){
                    //获取该用户和指定店主的聊天消息
                    var userShopMsg = userMsg[message.shop];
                    if(userShopMsg){
                        if(userShopMsg.length > 250){
                            userShopMsg.shift();
                        }
                        userShopMsg.push(message.content);
                    }
                    else{
                        userShopMsg = [];
                        userShopMsg.push(message.content);
                    }
                    userMsg[message.shop] = userShopMsg;
                }
                else{
                    userMsg = {};
                    var userShopMsg = [];
                    userShopMsg.push(message.content);
                    userMsg[message.shop] = userShopMsg;
                }
                localStorage[message.user] = JSON.stringify(userMsg);
            }

        },
        //读取本地历史消息
        readMessage: function(){
            var self = this;
            self.lock = true;
            if(window.localStorage){
                //若尚未读取过历史消息则读取一下
                if(!self.historyLoaded){
                    var key = 'webim'+self.username;

                    self.historyMsg = localStorage[key] ? JSON.parse(localStorage[key]) : null;

                    self.historyLoaded = true;
                    if(self.historyMsg && self.historyMsg['vidim'+self.hisId]){
                        self.historyMsg['vidim'+self.hisId].reverse();
                        //检测第一条历史消息是否为12小时前的,若是则显示开场语
                        var lastHsy = self.historyMsg['vidim'+self.hisId][0],
                            now = new Date().getTime();
                        if(now - lastHsy.saveTime > 12*60*60*1000 || typeof(lastHsy.saveTime) === "undefined"){//兼容之前没有saveTime的版本
                            self.showStartSentence();
                        }
                    }
                    else{
                        $(window).off('scroll.gl');
                        //没有历史消息，加载开场语
                        self.showStartSentence();
                    }
                }
                if(self.historyMsg  && self.historyMsg['vidim'+self.hisId]){
                    var hsy = self.historyMsg['vidim'+self.hisId],
                        TPL = '';
                    for(var i = self.curPage*self.pageSize; i < (self.curPage+1)*self.pageSize && i < hsy.length; i++){
                        TPL = self.appendMsg(hsy[i].from, hsy[i].to, hsy[i].message, hsy[i].type, hsy[i].id, true, hsy[i].status) + TPL;
                    }
                    $('#conversation').prepend(TPL);
                    self.bindResend();//重新绑定下失败重发事件
                    self.curPage++;
                    if(self.curPage*self.pageSize >= hsy.length && self.isBind){
                        $(window).off('scroll.gl');
                    }
                    //使消息加载后滚动条仍然停留在原来的位置
                    var deltaHeight = $('body').height()-self.lastBodyHeight;
                    self.lastBodyHeight = $('body').height();
                    $(window).scrollTop(deltaHeight);
                }
            }
            else{
                $(window).off('scroll.gl');
            }
            self.lock = false;
        },
        modifyHistory: function(msgIds, statusOrId, modifyId){
            //刷新存储的该消息的发送状态
            var self = this;
            if(window.localStorage){
                var key = 'webim'+self.username;
                var tempHistory = localStorage[key] ? JSON.parse(localStorage[key]) : null;
                if(tempHistory && tempHistory['vidim'+self.hisId]){
                    for(var q = 0; q < msgIds.length; q++){
                        for(var i = tempHistory['vidim'+self.hisId].length - 1; i >= 0; i--){
                            if(msgIds[q] == tempHistory['vidim'+self.hisId][i].id){
                                if(modifyId){
                                    tempHistory['vidim'+self.hisId][i].id = statusOrId;
                                }
                                else{
                                    tempHistory['vidim'+self.hisId][i].status = statusOrId;
                                }
                                break;
                            }
                        }
                    }
                    localStorage[key] = JSON.stringify(tempHistory);
                }
            }
        },
        bindSc: function(){
            var self = this;
            $(window).on('scroll.gl', function(){
                if($(this).scrollTop() <= 0 && !self.lock){
                    self.readMessage();
                }
            });
            self.isBind = true;
        },
        //用于给发送失败感叹号绑定重发消息功能
        bindResend: function(){
            var self = this;
            $('.sending-fail').on('click', function(){
                var $resend = $(this);
                var $resendContent = $resend.next();

                var msg = $resendContent.val();

                var options = {
                    to: self.hisId,
                    msg: msg,
                    type: "chat"
                };

                $resend.removeClass("sending-fail").addClass("sending-run");
                self.conn.sendTextMessage(options, function(webimId){
                    var oldId = $resendContent.data('id');
                    var oldIds = [oldId];
                    //将历史消息中的老id改为新id
                    self.modifyHistory(oldIds, webimId, true);
                    //将页面元素的老id改为新id
                    $resendContent.data('id', webimId);
                    //存储目前等待发送的消息的id
                    self.sendQueue.push(webimId);
                });
                $resend.off();//解除绑定的重发事件
            });
        },
        //获取开场语
        showStartSentence: function(){
            var self = this;
            $.ajax({
                type: "POST",
                url: APP.urls.getStartSentence,
                data:{
                    data:{
                        imucUid: self.hisId
                    }
                },
                async: true,
                success: function(result){
                    //console.log(result);
                    if(result.code.errcode == 0){
                        if(result.data[0] && result.data[0].value){
                            var startSentence = result.data[0].value;
                            var now = new Date().getTime();
                            var deltaTime = now - self.lastMsgTime;
                            if(deltaTime > 60000){
                                self.appendTime(now);
                            }
                            self.lastMsgTime = now;
                            //
                            self.appendMsg(self.hisId, self.username, startSentence, "text", "receivedMsg");
                            //在本地存储消息
                            var msg = {
                                user: 'webim'+self.username,
                                shop: 'vidim'+self.hisId,
                                content: {
                                    from: self.hisId,
                                    to: self.username,
                                    type: "text",
                                    id: new Date().getTime(),
                                    status: "success",
                                    message: startSentence
                                }
                            }
                            self.saveMessage(msg);
                            //滚动条至底
                            $(window).scrollTop($('body').height());
                        }
                    }
                },
                dataType: "json"
            });
        }
    }
    /**********************************
     实例化环信类并登录
     *************************************/
    var _args = {
        appKey: APP.appKey//'weimob#vdian' //'dwm716#weiim'
    }
    //
    var im = new webim(_args);
    //确保用户离开此页面时登出环信
    window.onbeforeunload = function(){
        im.conn.close();
        //return '';
    }

    function displayRadius(){
        var count = localStorage['weimobIMCount'+APP.shopId]||0;
        if(parseInt(count)>0){
            $(APP.tip_label).css({"display":"inline-block"});
        }else if(parseInt(count)==0){
            $(APP.tip_label).css({"display":"none"});
        }
    }
    /*************************************
     初始化页面
     **************************************/
    function initPage(){
        displayRadius();
        ///*****************插入表情******************/
        //var emotion_json = Easemob.im.Helper.EmotionPicData;
        //var html_emoji = '',
        //    emotion_array = [],
        //    rows = 0,
        //    cols = 0,
        //    maxCols = 7,
        //    maxRows = 3,
        //    pageSize = maxCols * maxRows; //每页的表情数，包括删除按钮
        //
        ////将emotion_json转化为数组形式，并且插入删除按钮
        //var delBtn_img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDowNzI4Q0JCMDM3RjJFNDExOEMyRDk2REYzNjRDN0Y2RSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpCOEQ2NEI5MEYyMzcxMUU0OEYyMEMxQThCMTI2QTA1RSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpCOEQ2NEI4RkYyMzcxMUU0OEYyMEMxQThCMTI2QTA1RSIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChXaW5kb3dzKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjA3MjhDQkIwMzdGMkU0MTE4QzJEOTZERjM2NEM3RjZFIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjA3MjhDQkIwMzdGMkU0MTE4QzJEOTZERjM2NEM3RjZFIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+w8rKFQAAB+BJREFUeNrsmelTE1sQxclkwBWC+oIs7kqwLAUVFN7/X+UHAQH3AiwBFxCS4A7Z3+/ek7k1TIaQeX6x3nOKSk0md/qe7j59umdI7eSLXb/f4XX9lsd/AlbKHpw0Gg19/dcbO1OxdrzOrQClXq8LUPg80dGwR+Qipn41ifLS8zw+W8117mGtVuN2zx6ta/zOvQynT19jLR6JyRlpQwY/UfxbGZaUXgqwXBITfhWWEufIET5PSi9Z0+2CGOFD4iTqfgx1d3en0+lGQnqlLBrZcUe1Wo3wIUG0IKkYCr5SqbS5ufn169datZosVNYlTGEkk8lks9mTJ09WW4z4rVEhBip+hUfJMkt9v1KpHDt2bHd398WLF+/fvy8UCtVKRRSRu5x7oXhgKlIlmJN7WDtz5szIyMjly5evXLkS3jE+WlrhtnFxEuKdnZ2nT5+urKyQxNHR0f6+vrTvm1QGZW8yG2xgSIMQWGuC3rDWWEO8v3//vra2RtRZf/HiRXcjC/xWXnNVQeJEUBxK4jQ7O0ucBgYGxsbGLl261J/JdPf0AL+mgAVFAAhwA6huXTKg63VsVtnS97FM4Pf29l6+fPn69Ws+++1xaLT4Ae9hjIDrU4a2t7efPXu2sbEBpgcPHly4cMGQrFzeK5UaNpHg4EoF/tob0+VyzULxAuGVQZaBiSu9vb03b97c398nZp8+feKrC0FUD3GuEZIWV31bW1uLi4sfPnwYHh6empwEkyGUIgECW5gqeM+qGp4YI/ZP5ZYKDtWd6ubEiROwHjT5fL5qY3Eo5bmjG7pYorAZn1ubm8+fPy/m80ODg5OTk0NDQ4bpgfeugTgus4GjsAAJpa4Ilkmx8ctsoWIKS6AXq5nOP65AyYWFBeL0VzYrTOVyWfLj6kAFj3WHxrVOLLCAEzbWenBwka+ONnImLP1+rHLKCbK+vLy8urpKhK9du3b79m2iVbEaI+vSGxB//PgRuGKby5fTOY/63d5eX1+H1CwjcU7i7Y9ptbOw0PuRlklYTWV1dRGSldXVpcVFTnK53N27d3v7+vbLZawoTQ2rjbhWLBSg3cb6eurvv0eGh2s2YC6WLAbTkydP3r17h0RBTYVN7G6WrS1599ULi1NTaayWcoIyoZn7pdJoLjc+MQEmcaJhtSBlb1RUCNJYLmf2np8ncj64bR14tgZ3i8XFhYX1tbWBbDY3OqpkHZjYVCXk2hrXr36YUjUrKmxPwA3Hi8Vbt27duXOnz2KKbSY4TWrQC/ZAgWQUPUvZLX/+/Dk/P//27dvBwcH79++TwVrQD8JTYWu/N9jFWfUKIgwmYv7lyxdEfGJi4vTp0+3HPYzS1+7du4cREDx+/JiLdBWoiW9v3rwhcfxKUMU2183aHL6LpxIEefHv8+fPcHx6ZoY4RUo3tj7wB/QPHz7EDtqIBRScYEMD4kQsUWAtq9oWElbv2AHV6BMJEgHRgqWlJbwE09TU1PHjx8P1fxgyt+DUqVMzMzNUKPF+9OgR9zIjgOncuXP8amQlMHJktDwRC9PcBizUnHMCzh7GOSuMbTAp9Wqj2AEHOsKVHz9+EGbskEH91NPTUw3EJTJDx8BSGEX28+fP0wpEeYYWx4M2Mzs/4Y/rPDCSEgYrbAMcnY5OqjLSaBT7bNfKXd85jWmcQ0IQIRhmKtnzAKoW0fqQ2BzOPK9q7SpCcODVq1dkjfkCx+D73NwceSSKqi03AYQnuRjKOwVTsq5fv85XkCHu3Iciw+XIPOimeKMp9TrZkRaACY7DbnrU1atXqRv8MXa6usQw415gKjJ4hp/VYlo1d6I6/MZcRU3BeqRLvoq2ml3DaeU6mPAETGfPnkWfwMRKqphzGEbMuAuN4FcVnrLWRnf8SLUbKU+nQYa52bk5BjR2RVGJmRaQXLZ00wH5Y6JHn8AE+unpaTqM0GMBpR0fH8dVpjQsU92Z/n616vDj3dFP1SIve6MRaCkJgitsCW/ccKFQsY06CURkDbjBhD9uJ2WEnIIG9WKmpQ3U7BGeMo6OltnMzg44ypakj9s01GKLSZKHAleAygInJBpGUi54QpwkjxJ06Rl1QzbJIGl1o+WB6apVTmNVu5n4VAoRYle4DDKKHy7jt6YlzXFUouYCigNMKkkFkk8XDEADzgC1C5Q19cL4nhj9budSY85OClyBv1zhaQcxAwqTLjjcOKUpgKc0MLmKdtFSQ8MH13nDz23m5OBIcygss429D+J7wasicACIGRVkFB0b0InV3RUNjeHCAT5QiluikZs5DTKrgu5ZUuuV+vDju9/61KvyCFdH2tYmn/RgnhOZLzgncUZpg4HHiZlLn+O1EypnU8M7Rpjn8oUCE29fJkMgXFPxO3wBoSdMKS19E3zUJjM0opDovY0e9jUcgGxleRntoBRwUrLcdLLzN81SLEWLKZRMGbIPDSV7YWmXVezx7ds3FBuUKMiNGzdcmM3ROazmg3K9TlehMPGSiaoSjCsdwqoFbwBxBqmDo4gLyuK2kIJ0Ckt5TNv0q9ugouDjqdpreTPbJq0qBcGiByAcPExrGjhwe6J/FzhvONFzVXga6wSWytO97EBuNLVGyiLZ+y2kldkVVkECTlpfih75blyFpvErbY9If9RnAliaYKWKymb4zWfkLW0bMriQy1UnwmFwCWBFEByWqfbcjx3nw6aa0vXnfz5/YP2/YP0jwABT7wgF7PD/1wAAAABJRU5ErkJggg==";
        //var count = 1,
        //    del = {"delBtn":delBtn_img};
        //for(var i in emotion_json){
        //    if(count%pageSize == 0){
        //        emotion_array.push(del);
        //    }
        //    var obj = {};
        //    obj[i] = emotion_json[i];
        //    emotion_array.push(obj);
        //    count++;
        //}
        //emotion_array.push(del);
        //计算表情页数
        //var pageNum = Math.ceil(emotion_array.length/pageSize);
        ////插入表情
        //for(var i = 0; i < emotion_array.length; i++){
        //    if(i%pageSize == 0){
        //        html_emoji +='<li><table>';
        //    }
        //    if(i%maxCols == 0){
        //        html_emoji +='<tr>';
        //    }
        //    var key = '';
        //    for(var k in emotion_array[i]){
        //        key += k;
        //    }
        //    html_emoji += '<td>\
        //			<img data-emoji="'+key+'" src='+emotion_array[i][key]+'>\
        //			</td>';
        //    if((i+1)%maxCols == 0){
        //        html_emoji += '</tr>'
        //    }
        //    if((i+1)%pageSize == 0 || i == emotion_array.length-1){
        //        html_emoji +='</table></li>';
        //    }
        //}
        //$('#list_emoji').html(html_emoji);

        //var list_emoji = new Swipe($('#list_emoji_wrap')[0], {
        //    speed:500,
        //    loop: false,
        //    indicate:"#emoji_indicate"
        //});
        //$("#list_emoji_wrap").removeClass('on');

        /*****************绑定按钮事件********************/
        //    $("#btn_emo_keyboard").on("click", function(){
        //        if($(this).hasClass('emo')){
        //            $(this).removeClass('emo').addClass('keyboard');
        //            $("#text_input").blur();
        //            $("#list_emoji_wrap").addClass('on');
        //        }
        //        else{
        //            $(this).removeClass('keyboard').addClass('emo');
        //            $("#list_emoji_wrap").removeClass('on');
        //            $("#text_input").focus();
        //        }
        //    });
        //    $("#text_input").focus(function(){
        //        $("#btn_emo_keyboard").removeClass('keyboard').addClass('emo');
        //        $("#list_emoji_wrap").removeClass('on');
        //    });
        //    //各表情按下输入，删除按钮按下删除
        //    $('#list_emoji').find("img").on("click", function(){
        //        var val = $("#text_input").val();
        //        if($(this).data("emoji") == "delBtn"){
        //            if(val[val.length-1] === ']'){
        //                val = val.substring(0, val.lastIndexOf('['));
        //            }
        //            else{
        //                val = val.substring(0, val.length-1);
        //            }
        //            $("#text_input").val(val);
        //        }
        //        else{
        //            var emo_str = $(this).data("emoji");
        //            $("#text_input").val(val+emo_str);
        //        }
        //
        //    });
        //    //发送商品详情链接
        //    $('#btn_send_link').on('click', function(){
        //        var msg = {
        //            type: "goods",
        //            message: {title: APP.goodsInfo.title, content:"", productType: APP.goodsInfo.product_type, gid: APP.goodsInfo.wk_itemid, url: APP.goodsLink, imgUrl: APP.goodsInfo.index_image, sellerUrl: APP.sellerLink}
        //        }
        //        im.sendMessage(msg);
        //        $(this).closest('div.goods-info-wrap').hide();
        //    });
        //    //发送维权单链接
        //    $('#btn_send_rights').on('click', function(){
        //        var msg = {
        //            type: "rights",
        //            message: {title: APP.goodsInfo.title, content:"", url: APP.refundLink, imgUrl: APP.goodsInfo.index_image, order: APP.orderId, refund: APP.refundId, status: APP.status}
        //        }
        //        im.sendMessage(msg);
        //        $(this).closest('div.rights-info-wrap').hide();
        //    });
        //    //发送文本消息按钮
        //    $('#btn_send_text').on('click', function(){
        //        var content = $('#text_input').val();
        //        if(content){
        //            var msg = {
        //                type: "text",
        //                message: content
        //            }
        //            im.sendMessage(msg);
        //            $('#text_input').val('');
        //        }
        //    });
        //    //当选择图片后发送图片，把图片上传到我方服务器，然后将返回的地址作为消息走环信发type=image的文本消息
        //    $('#add_photo').on("change", function(){
        //        var file = this.files && this.files[0];
        //        var str = $(this).val();
        //
        //        //截取文件名
        //        var arr = str.split('\\');
        //        var filename = arr[arr.length-1];
        //
        //        //压缩图片并返回base64码
        //        new ImageUpload({
        //            file: file,
        //            width: 320,
        //            noBlur: true,
        //            filename: filename || "unknow.png", //文件名
        //            callback: handleImageUpload
        //        });
        //    });
        //}
        //
        //function handleImageUpload(data){
        //    var dataUrl = data.base64,
        //        filename = data.filename,
        //        picId = new Date().getTime();
        //
        //    var loadingMsg = {url: "../../imgs/loading.png", picId: picId};
        //    im.appendMsg(im.username, im.hisId, loadingMsg, "image", "pic-loading"); //此信息为图片上传等候状态，不作为历史消息存储
        //
        //    $.ajax({
        //        type: "POST",
        //        url: APP.urls.uploadImage,
        //        data: {
        //            data:{
        //                shop_id: APP.shopId,
        //                uploadimage: dataUrl
        //            }
        //        },
        //        async:true,
        //        success: function(result){
        //            $('[data-picId="'+picId+'"]').closest('div.message-wrap').remove();
        //            var msg = {
        //                type: "image",
        //                message: {url: result.data[0], thumbnailUrl: result.data[0]}
        //            }
        //            im.sendMessage(msg);
        //        },
        //        dataType: "json"
        //    });
    }

    //初始化
    $(function(){
        initPage();
    });
});
