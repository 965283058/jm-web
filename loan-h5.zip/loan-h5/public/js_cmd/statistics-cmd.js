/******允许APP对当前页面进行分享*********/
//最新打点需使用 statistics2-cmd.js
define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd");

	function statistics (args) {
        this.url = args.url; //请求url
        this.params = args.params || {}; //请求参数（对象）
    }
    statistics.prototype = {
        config: function (args) {
            var self = this;
            self.params = args || {};
            return self;
        },
        invoke: function () {
            var self = this;
            console.log(self.params);
            $.ajax({
                type: 'POST',
                url: self.url,
                async: true,
                data: {
                    params: self.params
                },
                dataType: "json",
                success: function (res) {
                    
                }
            });
        }
    }

	module.exports = statistics;
});