define(function (require, exports, module) {

    var $ = require("lib_cmd/zepto-cmd");
    var Juicer = require("lib_cmd/juicer-cmd");
    var statistics = require('js_cmd/statistics2-cmd');

    var CLS_ON = 'on';
    var CLS_FIXED = 'fixed';
    var CLS_NAV_ITEM = 'nav-item';
    var CLS_NUM = 'num';
    var CLS_EMPTY = 'empty';
    var PAGE_INDEX = 'page-index';

    var doc = document;
    var winH = window.innerHeight;

    var sass = new statistics();
    /**
     * 标签页
     * @param options：配置项
     *      {
     *          nav: 标签导航,
     *          content: 标签内容,
     *          fixed：是否固定导航栏，默认false,
     *          // ajax为Object：表示渲染数据类型一致；ajax为Array：表示渲染数据类型不一致
     *          ajax: [{
     *              url: 请求地址,
     *              param: 请求参数,
     *              tabParamName: 选中标签-参数名，用于区分标签项，默认为 'type'
     *              pageParamName：当前页-参数名，用于分页，默认为 'page'
     *              // juicer渲染模板
     *              tpl: {
     *                  value: juicer模板,
     *                  functions: 自定义渲染函数
     *              }
     *          }]
     *      }
     * @constructor
     */
    function Tab(options) {
        this.options = options || {};
        this.rendered = false;

        this.render();
    }

    Tab.prototype = {
        constructor: Tab,
        // 渲染
        render: function () {
            var _self = this;
            if (!_self.rendered) {
                _self._init();
                _self._bindUI();

                _self.rendered = true;
            }
        },
        // 初始化
        _init: function () {
            var _self = this,
                isLoading = false;

            // 导航
            _self.nav = $(_self.get('nav'));
            // 我的订单
            _self.orderNav = $(_self.get('orderNav'));
            // 团类型导航
            _self.tuanNav = $(_self.get('tuanNav'));
            // 内容
            _self.content = $(_self.get('content'));
            // 异步请求配置
            _self.ajax = _self.get('ajax');
            // 记录当前选中标签项
            _self.activedItem = _self.content.children('.' + CLS_NAV_ITEM + '.' + CLS_ON);
            //订单业务类型
            _self.order_biz_type = _self.get('order_biz_type');
            //
            _self.order_group_type = _self.get('order_group_type');
            // 控制加载提示是否可见
            Object.defineProperty(_self, "isLoading", {
                get: function () {
                    return isLoading;
                },
                set: function(v){
                    isLoading = v;
                    $('#J_Loading').css('visibility', v ? 'visible' : 'hidden');
                    $('#J_Loading').css('display', v ? 'block' : 'none');
                }
            });
        },
        // 绑定事件
        _bindUI: function () {
            var _self = this,
                fixed = _self.get('fixed'),
                navTop = _self.nav.offset().top,
                isAjax = !!_self.ajax;

            // 点击
            _self.nav.on("click", 'li', function () {
                var target = $(this),
                    idx = target.index(),
                    type = target.children('a').eq(0).data('type');

                target.addClass(CLS_ON).siblings('.' + CLS_ON).removeClass(CLS_ON);
                _self.content.children('.' + CLS_NAV_ITEM).each(function(){
                    if ($(this).data('type')==type&&$(this).data('biztype')==_self.orderNav.data('biztype')&&$(this).data('grouptype')==_self.orderNav.data('grouptype')) {
                        _self.activedItem = $(this).addClass(CLS_ON);
                        return false;
                    }
                })
                //_self.activedItem = _self.content.children('.' + CLS_NAV_ITEM).eq(idx).addClass(CLS_ON);
                _self.activedItem.siblings('.' + CLS_ON).removeClass(CLS_ON);

                // 标签项为空，则异步加载
                if (!_self.activedItem[0].firstElementChild) {
                    _self.load();
                }
                //打点
                sass.invoke({
                    action: {
                        elementid: 'listType',
                        eventtype: "tap"
                    },
                    page: {
                        pagename: APP.pageName,
                        url: location.href
                    },
                    business:{
                        type: type,
                        biztype:  _self.order_biz_type,
                        grouptype: _self.order_group_type
                    }
                });
            });

            //我的订单按钮
            _self.orderNav.on('click', function () {
                if ($(this).hasClass('on')) {
                    $(this).removeClass('on');
                    _self.tuanNav.removeClass('on');
                } else {
                    $(this).addClass('on');
                    _self.tuanNav.addClass('on');
                }   
            });

            //团类型选择
            _self.tuanNav.on('click', 'li', function () {
                $(this).siblings('li').children('a').removeClass('on');
                var target = $(this).children('a').eq(0);
                var text = target.addClass('on').text();
                var eid = target.data('eid');
                _self.tuanNav.removeClass('on');
                _self.orderNav.removeClass('on');
                _self.orderNav.text(text);
                _self.orderNav.data('biztype', target.data('biztype'));
                _self.orderNav.data('grouptype', target.data('grouptype'));

                _self.order_biz_type = target.data('biztype');
                _self.order_group_type = target.data('grouptype');
                var type = _self.nav.find('li.' + CLS_ON).eq(0).children('a').eq(0).data('type');
                _self.content.children('.' + CLS_NAV_ITEM).each(function(){
                    if ($(this).data('type')==type&&$(this).data('biztype')==_self.orderNav.data('biztype')&&$(this).data('grouptype')==_self.orderNav.data('grouptype')) {
                        _self.activedItem = $(this).addClass(CLS_ON);
                        return false;
                    }
                })
                //_self.activedItem = _self.content.children('.' + CLS_NAV_ITEM).eq(idx).addClass(CLS_ON);
                _self.activedItem.siblings('.' + CLS_ON).removeClass(CLS_ON);

                // 标签项为空，则异步加载
                if (!_self.activedItem[0].firstElementChild) {
                    _self.load();
                }
                //打点
                sass.invoke({
                    action: {
                        elementid: eid,
                        eventtype: "tap"
                    },
                    page: {
                        pagename: APP.pageName,
                        url: location.href
                    },
                    business:{
                        biztype:  _self.order_biz_type,
                        grouptype: _self.order_group_type,
                        text: text
                    }
                });
            });

            // 滚动
            if (fixed || isAjax) {
                $(window).on("scroll", function() {
                    var scrollTop = doc.body.scrollTop,
                        activedItem = _self.activedItem,
                        docH = winH;

                    // 滚动固定导航栏
                    if (fixed) {
                        _self.nav[(scrollTop > navTop) ? "addClass" : "removeClass"](CLS_FIXED);
                    }
                    // 滚动加载更多
                    if (isAjax && activedItem.isVisible()) {
                        docH = $(doc).height();
                        if (docH - scrollTop - winH <= 100) {
                            _self.load();
                        }
                    }
                });
            }
        },
        // 获取指定配置项
        get: function(key) {
            var _self = this,
                options = _self.options || {};
            return options[key];
        },
        // 获取异步请求配置
        getAjaxOption: function(key) {
            var _self = this,
                ajax = _self.ajax,
                result, activedItem, activedIndex;
            if ($.isArray(ajax)){
                activedItem = _self.activedItem || $();
                activedIndex = activedItem.index();
                // 设置当前标签配置项
                ajax = ajax[activedIndex];
            }

            if ($.isPlainObject(ajax)) {
                switch(key) {
                    case 'tabParamName':
                        result = ajax[key] || 'type';
                        break;
                    case 'pageParamName':
                        result = ajax[key] || 'page';
                        break;
                    case 'param':
                        result = ajax[key] || {};
                        break;
                    default :
                        result = ajax[key];
                        break;
                }
            }

            return result;
        },
        /**
         * 异步加载数据
         * @param params 请求参数
         */
        load: function() {
            var _self = this,
                tabParamName = _self.getAjaxOption('tabParamName'),
                pageParamName = _self.getAjaxOption('pageParamName'),
                tpl = _self.getAjaxOption('tpl') || {},
                url = _self.getAjaxOption('url');
            if (!url || _self.isLoading) {
                return;
            }

            var activedItem = _self.activedItem || $(),
                index = activedItem.index(),
                page = activedItem.attr(PAGE_INDEX),
                page = page || (activedItem[0].firstElementChild ? 1 : 0),
                param = {},
                data;
            if (page == -1) {
                return;
            }

            _self.isLoading = true;
            param[tabParamName] = activedItem.attr('data-type') || index;
            param[pageParamName] = ++page;
            param['order_biz_type'] = _self.order_biz_type;
            param['order_group_type'] = _self.order_group_type;
            data = $.extend(_self.getAjaxOption('param'), param);
            $.ajax({
                type: "POST",
                url: url,
                data: data,
                dataType: "json",
                timeout: 5000,
                success: function (res) {
                    _self.isLoading = false;

                    var res = res || {},
                        data = res.data || [],
                        sPage = (typeof res.page === 'undefined') ? page : res.page,
                        total = res.total || 0,
                        childrenNum = 0;
                    // 注册自定义函数
                    for (var name in tpl.functions) {
                        Juicer.register(name, tpl.functions[name]);
                    }
                    activedItem.append(Juicer(tpl.value, res));

                    childrenNum = activedItem.children().length;
                    // 判断标签内容是否为空
                    if (childrenNum) {
                        activedItem.removeClass(CLS_EMPTY);
                    } else {
                        activedItem.addClass(CLS_EMPTY);
                    }
                    // 更新页码
                    if (sPage > 0) {
                        activedItem.attr(PAGE_INDEX, ( data.length ) ? sPage : --sPage);
                    }
                    // 标记数据是否加载完，如果加载完，则设置当前页为-1，且不再加载
                    if (childrenNum >= total) {
                        activedItem.attr(PAGE_INDEX, -1);
                    }
                    // 更新总记录数
                    _self.nav.children().eq(index).find('.'+ CLS_NUM).text(res.total || 0);
                },
                error: function () {
                    _self.isLoading = false;
                }
            });
        }
    };

    /**
     * 检查元素是否可见，用于扩展$对象。
     * @returns {boolean}
     */
    $.fn.isVisible = function () {
        return !!(this.width() || this.height()) && this.css("display") !== "none";
    };

    module.exports = Tab;
});
