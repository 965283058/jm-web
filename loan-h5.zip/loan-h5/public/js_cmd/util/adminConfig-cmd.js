define(function(require, exports, module){
    var $ = window._$ = require("lib_cmd/zepto-cmd"),
    	main = require("../main-cmd"),
    	//iForm= require("lib_cmd/iForm-cmd"),
		$eles = {},
		eles = {};

	$(function(){
		$eles= {
			form_login: $("#form_login"),
			form_config: $("#form_config")
		};

		initPage();
	});

	function initPage(){
		//
		if(!APP.isAdminLogin){
			var form_login= $eles.form_login[0];
			//01
			form_login.btn_ok.onclick= function(evt){
				var args= {
					typeId: form_login.typeId.value,
					mobile: $.trim(form_login.mobile.value),
		            mode: "h5Login",
		            vcode: $.trim(form_login.vcode.value),
		            pwd: $.trim(form_login.pwd.value)
				};
				var l= loading();
	            $.ajax({
	                type: "POST",
	                url: APP.urls.adminLogin,
	                //cache: false,
	                data: args,
	                async:true,
	                success: function(result){
	                    l.destroy();
	                	if(0=== result.code){
							location.reload();
						}else{
							alert(result.message);
						}
	                },
	                dataType: "json"
	            });
			}
			//02
			form_login.btn_sendVcode.onclick= function(evt){
	            var args= {
	            	mobile: $.trim(form_login.mobile.value),
	            	mode: "h5Login"
	            };
	            if(!/^\d{5,20}$/g.test(args.mobile) ){
	                return alert("请输入正确的手机号");
	            }
	            var l= loading();
	            $.ajax({
	                type: "POST",
	                url: APP.urls.verify,
	                //cache: false,
	                data: args,
	                async:true,
	                success: function(result){
	                    l.destroy();
	                    if(0== result.code){
	                        //startTick(59);
	                    }else{
	                        alert(result.message);
	                    }
	                },
	                dataType: "json"
	            });
			}
		}else{
			//
			var form_config= $eles.form_config[0];
			form_config.action= APP.urls.adminConfig;
			var btn_save= form_config.btn_save;
			btn_save.onclick= function(evt){
				alert(111);
				form_config.submit();
				return true;
			}
		}
	}
});