define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
    	main = require("js_cmd/main-cmd"),
        Vue = require('lib_cmd/vue-cmd');

    var cfgPanel= new Vue({
    	el: '#cfg-panel',
    	data: {
    		show: 0,
    		rdbk: "",
    		result: "",
    		isAdmin: "1"=== APP.isAdmin,
    		passCode: "",
    	},
    	computed: {
    		type: function(){
    			return ("sms"=== APP.type? "验证码查询-": "");
    		}
    	},
    	methods: {
    		getKey: function(){
    			var self= this;
    			if("sms"=== APP.type&& !/^\w{11}$/.test(self.rdbk)){
    				return alert("请输入正确的手机号");
    			}
    			var l= loading();
    			$.ajax({
    				type: "POST",
	                url: APP.urls.getKey,
	                data: {
	                	type: APP.type,
	                	rdbk: self.rdbk
	                },
	                async:true,
	                success: function(res){
	                	l.destroy();
	                    if(0!= res.code){
	                    	alert(res.message);
	                    }else{
	                    	self.result= res.data;
	                    	self.passCode= res.passCode;
	                    }
	                },
	                dataType: "json"
    			});
    		},
    		setKey: function(){
    			//验证
    			var self= this;
    			if("sms"=== APP.type&& !/^\w{6,13}$/.test(self.rdbk)){
    				return alert("请输入正确的手机号");
    			}
    			confirm("操作需谨慎，请认真核对保存的内容!!!", {
    				callBack: function(evt){
    					if("确定"=== evt.target.innerText){
    						var l= loading();
    						$.ajax({
			    				type: "POST",
				                url: APP.urls.setKey,
				                data: {
				                	type: APP.type,
				                	rdbk: self.rdbk,
				                	passCode: self.passCode,
				                	result: self.result
				                },
				                async:true,
				                success: function(res){
				                	l.destroy();
				                    alert(res.message);
				                },
				                dataType: "json"
			    			});
    					}else{
    						console.log("cancled");
    					}
    					this.close();
    				}
    			});
    			var self= this;
    			
    		}
    	},
    	created: function(){
    		this.show=1;
    	}
    });
});