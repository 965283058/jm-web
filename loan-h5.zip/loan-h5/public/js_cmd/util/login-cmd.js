define(function(require, exports, module){
    var $ = window._$ = require("lib_cmd/zepto-cmd"),
    	main = require("../main-cmd"),
    	Form = require("js_cmd/form-cmd"),
		$eles = {},
		eles = {};
	// 页面操作所需元素选择器
    var selectors = {
        // 表单
        formWrap: '.form-wrap'
    };
	/**********************************
		页面初始化函数
	**********************************/
	function initPage(){
		$('#J_BtnVerifyPicCodeTencent').on('click', function () {
			TSOCapObj.refresh();
		});
		//初始化，参数传入显示验证码的元素imgid
    	TSOCapObj.init("J_BtnVerifyPicCodeTencent");
    	//刷新拉取验证码图片
    	TSOCapObj.refresh();

    	APP.verifyPicCode= function(fn) {
    		//获取用户输入
    		var ans = $("#input_verifyPicCode").val();
    		//验证答案，验证完成后会回调第二个参数传入的函数
    		TSOCapObj.verify(ans , function(ret_json){
    			if (ret_json.errorCode!=0) {
	        		$("#input_verifyPicCode").val("");
	        		TSOCapObj.refresh();
	        		tip("图形验证码输入错误！");
	    		} else {
	    			fn(ret_json.ticket);
	    		}
    		});
		}
		//
		main.checkLogin(null, null, function(_evt, _args, _result){
	        location.replace("/buyer/user/center?nav=0");
	    });
	}

	
	/**********************************
		页面初始化函数
	**********************************/
	$(function(){
		//
		initPage();
	});
});