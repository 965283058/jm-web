define(function(require, exports, module){
    var $= window._$= require("lib_cmd/zepto-cmd"),
        touchAPP= require("js_cmd/touchApp-cmd"),
        TA= new touchAPP();
    var capOption={callback :cbfn, showHeader :true};
    capInit(document, capOption);
    //回调函数：验证码页面关闭时回调
    function cbfn(retJson){
        if(retJson.ret==0){
            fn_processTicket(retJson.ticket);
        }else{
            if(APP.isVdianAPP){
                TA.executeAPPMethod("webVerifyCode", -1);
            }else{
                parent.webVerifyCode(-1);
            }    
            //用户关闭验证码页面，没有验证
        }
    }
    
    function fn_processTicket(ticket){
        var args= {
            ticket: ticket,
            vcode: APP.vcode
        };
        $.ajax({
            type: "POST",
            url: APP.urls.checkQCode,
            data: args,
            async:true,
            success: function(res){
                if(0== res.code){
                    if(APP.isVdianAPP){
                        TA.executeAPPMethod("webVerifyCode", res.vvcode);
                    }else{
                        parent.webVerifyCode(res.vvcode);
                    }
                }else{
                    alert(res.message);
                }
            },
            dataType: "json"
        });
    }

});