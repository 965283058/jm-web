/**
    店铺公告插件
    @author intpay
    @time 2016.03.26
 */
define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        iTemplate= require("lib_cmd/iTemplate-cmd"),
        iScroll= require("lib_cmd/iScroll-cmd"),
        dialog= require("lib_cmd/myDialog-cmd"),
        touchAPP= require("js_cmd/touchApp-cmd"),
        TA= new touchAPP(),
        $eles= {},
        eles= {
            nStyle: '<style>\
                        .widget-notice {}\
                        .widget-notice a{display: block; height: 40px; line-height:40px; color:#fff; background: #ffa61b;padding: 0 13px;overflow:hidden;text-overflow:ellipsis;white-space: pre;}\
                        .widget-notice a img{display:inline-block; height:15px;max-width:100px;margin:0 10px 0;}\
                        .widget-notice-dialog .widget_footer ul{border-width:0!important;}\
                        .widget-notice-dialog .button{width: 90px!important;height: 30px!important;line-height: 28px!important;color: #f84e37!important;border: 1px solid #f84e37!important;border-radius: 3px!important;margin:10px auto;}\
                        .widget-notice-dialog .widget_body{}\
                        .widget-notice-dialog .widget_body:before{content: "";display: block;width: 90px;height: 90px;background: url(/imgs/w_17.png) no-repeat center -4px #fff;background-size: 85px auto;position: absolute;left: 50%;margin: -100px -45px;border-radius: 100%;}\
                    </style>',
            nTPL: '<div data-role="widget" data-widget="widget_notice" class="widget-notice on">\
                        <div><a href="javascript:;" style=""><img src="{iconUrl}" />{text}</a>\
                    </div></div>',
            dTPL: '<div class="widget_wrap" style="z-index:{zIndex2}; overflow:inherit;">\
                        <div class="widget_body" style="padding:60px 10px 10px;">\
                            <div id="dialog_scroll" style="max-height:200px;overflow:hidden;position:relative;"><div>\
                                {str}\
                            </div></div>\
                        </div>\
                        <div class="widget_footer">\
                            <ul>\
                                <li><a href="javascript:;" class="button">确定</a></li>\
                            </ul>\
                        </div>\
                    </div>\
                </div>'
        };
    APP.urls.agentBackInfo= "/api/info/agentBackInfo";
    //品牌馆BrandHome
    $(function(){
        var args= {
            route: "/intpayApp/declaration",
            channel: {"specialOne": "OneBuy", "specialOne2": "OneBuy", "specialKill": "DailyBuy", "specialKill2": "DailyBuy", "tuanList": "GroupBuy"}[APP.pageName],
            BaseAppVersion: "4.0.0"
        };
        $.ajax({
            type: "POST",
                url: APP.urls.agentBackInfo,
                //cache: false,
                data: args,
                async:true,
                success: function(result){
                    if(0== result.code&& result.data.actionItems){
                        fn_processNotice(result.data);
                    }
                },
                dataType: "json"
        });
    });
    //
    function fn_processNotice(data){
        var notice= data.actionItems[0],
            $nHTML= null,
            _jump=  notice.action.segue,
                    destClassName= _jump.dest.split("|")[~~("android"!== TA.osType)];
            _jump.destClassName= destClassName;
            delete _jump.dest;
        if(_jump.destClassName=== TA.NativeView.GoodsDetail&& touchAPP.version< new touchAPP.Version("4.0.0") ){
            return;
        }
        $nHTML= $(eles.nStyle+ iTemplate.makeList(eles.nTPL, [notice], function(k, v){
            
        }) );
        $nHTML.on("click", function(){
            if(notice.action.segue.tips){
                alert(notice.action.segue.tips.dialog.content, {
                    TPL: eles.dTPL,
                    classes: "widget-notice-dialog",
                    callBack: function(evt){
                        if(evt.target.classList.contains("button") ){
                            this.destroy();
                        }
                    }
                });
                new iScroll(document.getElementById("dialog_scroll"),{
                    hideScrollbar:false,
                    handleClick:false,
                    onBeforeScrollStart: function(e){}
                });
            }else if(notice.action.segue.destClassName){
                var __jump= null;
                if(APP.isVdianAPP){
                    switch(notice.action.segue.destClassName){
                        case TA.NativeView.WebView:
                            __jump= _jump;
                        break;
                        case TA.NativeView.GoodsDetail:
                            __jump= {
                                destClassName: _jump.destClassName,
                                segue: {
                                    aid: _jump.segue.aid,
                                    goods: {
                                        sellType: _jump.segue.goods.sellType,
                                        wp_goods_id: _jump.segue.goods.wp_goods_id
                                    }
                                }
                            };
                        break;
                        case TA.NativeView.VShopDetail:
                             __jump= {
                                destClassName: _jump.destClassName,
                                segue: {
                                    aid: _jump.segue.aid
                                }
                            }
                        break;
                        default:
                            
                        break;
                    }
                    TA.jump(__jump);
                }else{
                    switch(notice.action.segue.destClassName){
                        case TA.NativeView.WebView:
                            //TODO 对于专场地址，往往需要添加 “/share”处理，但是4.0.0 已经兼容（？）
                            location.href= notice.action.segue.segue.web.url;
                        break;
                        case TA.NativeView.GoodsDetail:
                            var params= {};
                            if(notice.action.segue.segue.shop_id){
                                params= {

                                };
                            }else{
                                 params= {
                                    vid: 0,
                                    aid: notice.action.segue.segue.aid,
                                    gid: notice.action.segue.segue.goods.wp_goods_id.split("_")[1],
                                    iswp: "true"
                                }
                            }
                            location.href= "/buyer/goods/detail?vid="+ params.vid+ "&aid="+ params.aid+ "&gid="+ params.gid+ "&scenarios=2&iswp="+ params.iswp;
                        break;
                        case TA.NativeView.VShopDetail:
                            location.href= "/buyer/vshop/index?aid="+ notice.action.segue.segue.aid;
                        break;
                        default:
                            console.log("unsupport type");
                        break;
                    }
                }  
            }
        });
        eles.container.prepend($nHTML);
    }
    //
    module.exports= {
        init: function(container){
            eles.container= container;
        }
    }
});
