define(function (require, exports, module) {
    var Vue = require('lib_cmd/vue-cmd'),
        main = require("js_cmd/main-cmd"),
        DataService = require("./DataService-cmd"),
        sta=require("./intpay-cmd"),
        touchApp = require("js_cmd/touchApp-cmd");
    if(!String.prototype.setPhoneNumber){
        String.prototype.setPhoneNumber = function(){
            var first = this.substring(0,3);
            var end = this.substring(7,11);
            return first+'****'+end;
        }
    }
    //rem自适应
    var ohtml = document.documentElement;
    getSize()
    window.onresize=function(){
        getSize()
    }
    function getSize(){
        var screenWidth = ohtml.clientWidth;
        screenWidth = screenWidth > 750 ? 750 : screenWidth;
        ohtml.style.fontSize = screenWidth*100/750+'px';
    }

    APP.makeMoney = {
        getLatestCommissionList:function(res){
            if(res.code!=0)return;
            vm.commissionList = res.data.commission_list
            var total = res.data.commission_list.length
            var count = 1;
            var a= setInterval(function(){
                if(count == total){
                    count=0;
                    $(".makeMoney-infoList-container ul").css({marginTop:(-.33)*count+"rem"});
                    count++;
                }else{
                    $(".makeMoney-infoList-container ul").animate({marginTop:(-.33)*count+"rem"},function(){
                    },1000);
                    count++;
                }
            },5000);
        }
    };
    var makeMoneyRequestData = {
    }
    //设置请求url和请求回调接口
    var makeMoneyService = new DataService({
        url: APP.urls.getLatestCommissionList,
        pluginName: "makeMoney",
        actionName: "getLatestCommissionList"
    });
    makeMoneyService.params = makeMoneyRequestData;

    var vm = new Vue({
        data: {
            commissionList:[]
        },
        methods: {
            goLuckDraw:function(){
                // 抽奖打点
                sta.recode({elementid:'draw'});
                sta.gotopage('/loan/intpay/luckyRoller');
            },
            goRule:function(){
                // sta.recode({elementid:'draw'});
                sta.gotopage('/loan/intpay/agentRule');
            },
            myQrcodeBtn:function(){
                // 二维码打点
                sta.recode({elementid:'ad'});
                if (APP.isVdianAPP) {
                    main.checkAppLogin(null,null,function(){
                        var TA=new touchApp();
                        TA.getUserInfo(function (userInfo) {
                            alert('app is login');
                        });
                    });
                }
                else {
                    if (APP.isLogin) {
                        alert('web is login')
                    } else {
                        self.isSend = false;
                        var curWwwPath = window.document.location.href;
                        var pathName = window.document.location.pathname;
                        var pos = curWwwPath.indexOf(pathName);
                        var localhostPath = curWwwPath.substring(0, pos);
                        var path = curWwwPath.replace(localhostPath, "").replace(/&/g, "%2338");
                        sta.gotopage("/loan/intpay/login?referrer=" + path); // 未登录跳转登录页面
                    }
                }
            },
            goShare:function(){
                // 分享打点
                sta.recode({elementid:'share'});
                var TA = new touchApp();
                TA.getUserInfo(function (userInfo) {
                    if (!userInfo) {
                        userInfo = {};
                    }
                    if (true) {
                        var shopId = userInfo.shop_id || -1;
                        var title = self.share_title,
                            desc = self.share_sub_title,
                            imgUrl = self.share_image_url;
                        var loc = document.location,
                            locHref = loc.pathname + "/share" + loc.search;
                        var reg = /\?/gi;
                        if (reg.test(locHref)) {
                            locHref = locHref + '&vid=' + shopId;
                        } else {
                            locHref = locHref + '?vid=' + shopId;
                        }
                        //分享信息
                        var shareInfo = {};
                        if (self._shareInfo) {
                            shareInfo = self._shareInfo;
                        } else {
                            shareInfo = {
                                weixin: {
                                    title: title,
                                    desc: desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                timeline: {
                                    title: title,
                                    desc: desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                weibo: {
                                    title: title,
                                    desc: desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                qzone: {
                                    title: title,
                                    desc: desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                qq: {
                                    title: title,
                                    desc: desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                qweibo: {
                                    title: title,
                                    desc: desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                yixin: {
                                    title: title,
                                    desc: desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                ytimeline: {
                                    title: title,
                                    desc: desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                renren: {
                                    title: title,
                                    desc: desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                message: {
                                    title: title,
                                    desc: '【'+title+'】'+desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                copy: {
                                    title: title,
                                    desc: '【'+title+'】'+desc,
                                    link: locHref,
                                    imgUrl: imgUrl
                                },
                                qrcode: {
                                    title: title,
                                    desc: '扫描二维码可查看详情',
                                    link: locHref,
                                    imgUrl: imgUrl
                                }
                            };
                        }
                        TA.toShare(shareInfo);
                    }
                });
            }
        }
    });

    //发送请求
    makeMoneyService.getData();
    vm.$mount('#makeMoney-body');
    $("#makeMoney-body").css({display:"block"});
});