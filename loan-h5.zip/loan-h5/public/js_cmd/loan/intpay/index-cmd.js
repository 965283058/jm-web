define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        Vue = require('lib_cmd/vue-cmd'),
        main = require("js_cmd/main-cmd"),
        Swipe = require("lib_cmd/swipe-cmd"),
        sta=require("./intpay-cmd"),
        DataService = require("./DataService-cmd"),
        widgetTabNavi = require("js_cmd/loan/intpay/widget/tabNavi-cmd"),
        loading = require("js_cmd/loan/intpay/widget/loading-cmd"),
        widgetGoodsList = require("js_cmd/loan/intpay/widget/goodsList-cmd"),
        touchApp = require("js_cmd/touchApp-cmd");
    /*if(!String.prototype.setPhoneNumber){
        String.prototype.setPhoneNumber = function(){
            var first = this.substring(0,3);
            var end = this.substring(7,11);
            return first+'****'+end;
        }
    }*/

    APP.index = {
        getIndex:function(data){
            if(data.code!=0)return;
            vm.banner_list = data.data.banner_list;//轮播
            vm.loan_list = data.data.loan_list;//贷款成功名单列表
            vm.amount_label_list = data.data.amount_label_list;//金额列表
            vm.type_label_list = data.data.type_label_list;//类型列表
            vm.product_list = data.data.product_list;//产品列表
            setTimeout(function(){
                var list_banner = new Swipe($("#list_topic")[0], {
                    imgsReady:{0:true},
                    speed:500,
                    loop:true,
                    auto:3000,
                    indicate:"#slider_3_indicate"
                });
                $(".slider-3 .img img").on("click",function(){
                    var index = $(this).data("index");
                    if(!vm.banner_list[index].jump_status||!vm.banner_list[index].jump_url){
                        return;
                    }
                   /* sta.recode({elementid:'banner',extend:{"index":index}});*/
                    window.location.href = vm.banner_list[index].jump_url;
                    //sta.gotopage(vm.banner_list[index].jump_url);
                    //wedgetTool.picJump(self.item.materialList.materialList[index].segue);
                })
            },200);
            var total = 1;
            vm.loadMore = false;
            var a= setInterval(function(){
                if(total==100){
                    total=0;
                    $(".adv ul").css({marginTop:(-30)*total+"px"});
                    total++;
                }else{
                    $(".adv ul").animate({marginTop:(-30)*total+"px"},function(){
                    },1000);
                    total++;
                }
            },5000);
        }
    };
    var indexRequestData = {
        channel: APP.channel,
        clientIp:APP.clientIp
    }
//设置请求url和请求回调接口
    var indexService = new DataService({
        url: APP.urls.getIndexInfo,
        pluginName: "index",
        actionName: "getIndex",
        channel: APP.channel
    });
    indexService.params = indexRequestData;



    var vm = new Vue({
        data: {
            banner_list:[],
            loan_list:[],
            amount_label_list:[],
            type_label_list:[],
            product_list:[],
            loadMore:false,
            width:320,
            isDialog:false,
            phoneNum:'',
            channel: APP.channel
        },
        methods:{
            kownBtn:function(){
                /*sta.recode({elementid:'enter'});*/
                localStorage.intpay_a_l_t = this.phoneNum;
                this.isDialog = false;
            },
            hideDialog:function(){
                this.isDialog = false;
            },
            go2teail:function(val){
                if(val){
                    /*sta.recode({elementid:'product',extend:{"product_id":val}});*/
                    sta.gotopage('/loan/productDetails?product_id='+val);
                }
            },
            rule:function(){
                sta.gotopage('/loan/declaration');
            },
            jump:function(index,flag){
                var url = '/loan/loanSearch?';
                var self = this;
                if(flag==0){
                    url+='type_label='+
                    this.type_label_list[index].label_id
                }else{
                    url+='amount_label='+this.amount_label_list[index].label_id
                }
                setTimeout(function(){
                    window.location.href = url;
                },100);
            }
        }
    });
    //发送请求
    vm.loadMore = true;
    indexService.getData();
    vm.$mount('.section-body');
    vm.width = $(window).width();
    if(APP.isVdianAPP){
        main.checkAppLogin(null,null,function(){
            var TA=new touchApp();
            TA.getUserInfo(function (userInfo) {
                //args.wid=userInfo.wid;
                var isRegister =  localStorage.intpay_a_l_t||'';
                vm.phoneNum=userInfo.mobile;
                if(!isRegister||isRegister!=userInfo.mobile){
                    vm.isDialog = true;
                }
                $(".section-body").css({display:"block"});
            });
        });
    }else{
        $(".section-body").css({display:"block"});
    }
});
