define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        main = require("js_cmd/main-cmd"),
        sta=require("./intpay-cmd"),
        Vue = require('lib_cmd/vue-cmd');
    $(function(){
        // if(APP.isVdianAPP){
        //     main.checkAppLogin(null,null,function(){
        //         //登陆成功以后回调
        //     });
        // }  
        initPage();
    });


    function initPage(){
        var guideList = [
            {
                "Q": "什么是“趣借了”？",
                "A": "“趣借了”可以为您提供便捷的贷款流程和定制化的移动贷款推荐信息服务平台。"
            }, {
                "Q": "贷款是否需要提供抵押物？",
                "A": "提供的贷款是纯信用贷款。"
            }, {
                "Q": "贷款流程: ",
                "A": "申请贷款-----贷款审批-----贷款发放<br>\
                        1、申请贷款: 申请贷款并选择贷款产品。<br>\
                        2、贷款审批: 贷款机构对贷款申请人的资质进行审核。<br>\
                        3、贷款发放: 贷款审批成功后，由贷款机构发放贷款。"
            }, {
                "Q": "提交完申请后，多久能放款？在哪里能查看审批进度？",
                "A": "根据每家贷款机构不一样，最终放款时间由贷款机构审核而定，您可以从“我的贷款”中查看审批进度。"
            }, {
                "Q": "遇到了审批、放款、还款、提前还款等问题如何解决？",
                "A": "您可以拨打对应贷款机构官方客服电话进行咨询。"
            }, {
                "Q": "之前征信有过不良还能贷款吗？",
                "A": "每家贷款机构对征信判断的标准不一样，您可以尝试申请。"
            }
        ];

        var vm = new Vue({
            el: '#guideList',
            data: {
                guideList: guideList
            }
        });
    }
});
