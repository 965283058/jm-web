/**
 * Created by Administrator on 2017/2/14 0014.
 */
define(function (require,exports,module) {
    var l=null;
    var $ = require("lib_cmd/zepto-cmd"),
        sta=require("./intpay-cmd"),
        Vue = require('lib_cmd/vue-cmd'),
        DataService = require("./DataService-cmd"),
        flowDetailComponent = require("js_cmd/loan/intpay/widget/flowDetailComponent-cmd");
    APP.cashDetail = {
        getcashDetail:function (res) {
            console.log(res)
            if(res.code == "0"){
                if(res.data){
                    //res.data.withdraw_status = 0;
                    if(res.data.withdraw_status == "1"){  //  1表成功
                        vm.isSuccess = true
                    }else if(res.data.withdraw_status == "0"){  //0表申请中
                        vm.isSuccess = false
                    };
                    vm.amount_info = res.data.amount_info;
                    vm.apply_time = res.data.apply_time ,
                    vm.bank_card_info = res.data.bank_card_info ,
                    vm.take_days = res.data.take_days,
                    vm.complete_time = res.data.complete_time
                }
            }
        }
    };

    var vm = new Vue({
        el:"#cashDetailMain",
        data:{
            withdraw_id:"" ,                                //现金提取id,
            bank_card_info:'' ,                             //银行账号信息如尾号2828银行卡
            amount_info:"" ,                                //提取金额
            apply_time:'',                                  //提取申请时间
            take_days:'',                                   //预计几个工作日到账
            isSuccess: false,                               //是否成功，成功就加success类
            pageTitle:false,                                //控制是否只有时间那块
            complete_time:''                                //到账时间
        },
        methods:{
        }
    });

    //请求的参数
    var cashDetailRequestData = {
        "withdraw_id": APP.withdraw_id,   //流量流水表主键id
        "wid":1,
        "biz_account_source":2
    };
    if(APP.pageTitle == '1'){        //流量提取详情
        vm.pageTitle = true
    }else if(APP.pageTitle == '0'){   //结果详情
        vm.pageTitle = false
    }

    //设置请求url和请求的回调
    var cashDetailService = new DataService({
        url: APP.urls.cashDetail,
        pluginName: "cashDetail",
        actionName: "getcashDetail"
    });
    cashDetailService.params = cashDetailRequestData;

    //发送请求
    cashDetailService.getData();


})