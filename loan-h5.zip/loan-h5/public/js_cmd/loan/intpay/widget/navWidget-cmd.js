/**
 * Created by Administrator on 2017/2/16 0016.
 */
define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        Vue = require("lib_cmd/vue-cmd");
    Vue.component('navWidget',{
        template:
            '<div id="navWidget" :class="{close:isClose}">\
                <i @click="toOpen()"></i>\
                <div>\
                    <ul>\
                        <li @click="jump(0)">\
                            <span>首页</span>\
                        </li>\
                         <li @click="jump(1)">\
                            <span>贷款搜索</span>\
                        </li>\
                         <li @click="jump(2)">\
                            <span>我的贷款</span>\
                        </li>\
                    </ul>\
                    <i @click="toClose()"></i>\
                </div>\
            </div>'
        ,
        data: function () {
            return {
                isClose : true,
                onOff : true
            }
        },
        methods: {
            toOpen: function () {
                  this.isClose = false
            },
            toClose: function () {
                this.isClose = true
            },
            jump: function (flag) {
                if(flag == 0){
                    window.location.href = "../intpay/index"
                }else if(flag == 1){
                    window.location.href = "../intpay/loanSearch"
                }else if(flag == 2){
                    window.location.href = "../intpay/myLoan"
                }
            }
        }
    })
    module.exports = Vue;
})