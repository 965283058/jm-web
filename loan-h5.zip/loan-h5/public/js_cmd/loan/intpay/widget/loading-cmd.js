/**
 * Created by Administrator on 2017/2/16 0016.
 */
define(function (require,exports,module) {
    var $ = require("lib_cmd/zepto-cmd"),
        Vue = require("lib_cmd/vue-cmd");
    Vue.component('loading',{
       template:
        '<div class="com-widget-loadMore">\
        <div class="loadingImg"></div>\
            加载中...\
        </div>\
        '
    })
})