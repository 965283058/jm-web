/**
 * Created by Administrator on 2017/2/15 0015.
 */
define(function (require,exports,module) {
    var $ = require("lib_cmd/zepto-cmd"),
        sta = require("../intpay-cmd"),
        Vue = require("lib_cmd/vue-cmd");
    Vue.component('goods_list_widget',{
        template:
            ' <div class="loanSearch-list-main">\
              <div class="home-title" v-if="is_home==1">热门贷款</div>\
                <div class="loanSearch-list" v-for="item in goods_list" :id="item.product_id" @click.stop="gotoDetails(item.product_id)">\
                    <div class="loanSearch-list-l">\
                        <div class="loanSearch-list-l-img">\
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" alt="" :style="\'background-image:url(\'+item.thirdparty_logo+\')\'">\
                        </div>\
                        <div class="loanSearch-list-l-con">\
                            <p class="title">\
                                {{item.product_name}}\
                                <em class="recommend-icon" v-if="item.ishot==1">热</em>\
                            </p>\
                            <template v-if="item.productDetailList&&item.productDetailList.length > 0 ">\
                                <p class="con" v-for="itemDetail in item.productDetailList" :style="$index==1?\'color:#FE8D1D\':\'\'" v-html="itemDetail.detail_value"></p>\
                            </template>\
                        </div>\
                    </div>\
                    <div class="loanSearch-list-r">\
                        <b class="right"><i class="right-arrow1"></i><i class="right-arrow2"></i></b>\
                    </div>\
                </div>\
                <div class="moreGoods" @click="go2search" v-if="is_home==1">更多贷款产品<i></i></div>\
             </div>'
        ,
        props:['goods_list','is_home'],
        methods: {
            gotoDetails: function (e) {
                var product_id = e;
                sta.recode({elementid:'item'});
                sta.gotopage('/loan/productDetails?product_id=' + product_id)
            },
            go2search:function(){
                sta.recode({elementid:'check'});
                sta.gotopage('/loan/loanSearch');
            }
        }
    })
    module.exports = Vue;
})