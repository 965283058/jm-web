/**
 * Created by Administrator on 2017/2/16 0016.
 */
define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        Vue = require("lib_cmd/vue-cmd");
    Vue.component('empty',{
        template:
            '<div class="empty" data-empty="没有符合条件的产品哦">\
             </div>'
    })
    module.exports = Vue;
})