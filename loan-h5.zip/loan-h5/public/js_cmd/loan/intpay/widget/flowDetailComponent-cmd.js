/**
 * Created by Administrator on 2017/2/16 0016.
 */
define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        Vue = require("lib_cmd/vue-cmd");
    Vue.component('flow_detail_component',{
        props:['is_success'],
        template:'\
                    <div class="flowDetailComponentMain" :class="{success:is_success}">\
                        <div class="flowDetailComponentMain-h">\
                            <slot name="flowHead">\
                            </slot>\
                        </div>\
                        <div class="flowDetailComponentMain-c">\
                            <slot name="flowCon">\
                            </slot>\
                        </div>\
                        <div class="flowDetailComponentMain-f">\
                            <slot name="flowFoo">\
                            </slot>\
                        </div>\
                    </div>\
                  '
    })
    module.exports = Vue;
})