define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        sta=require("../intpay-cmd"),
        Vue = require("lib_cmd/vue-cmd");
    Vue.component('tab_navi', {
        template:
            '<div class="fillBottomBox"></div>\
            <div class="navi">\
                <ul>\
                    <li @click="jump(0)" class="{{index==0?\'home active\':\'home\'}}"><i></i><span>首页</span></li>\
                    <li @click="jump(1)" class="{{index==1?\'search active\':\'search\'}}"><i></i><span>贷款搜索</span></li>\
                    <li @click="jump(2)" class="{{index==2?\'profile active\':\'profile\'}}"><i></i><span>我的贷款</span></li>\
                </ul>\
            </div>',
        props:['index'],
        methods:{
            jump:function(val){
                if(val==this.index){
                    return;
                }
                /*var url = '';*/
                if(val==0){
                    sta.recode({elementid:'home'});
                    sta.gotopage('/loan/intpay/index')
                    /*url = '/loan/intpay/index';*/
                }else if(val==1){
                    sta.recode({elementid:'search'});
                    sta.gotopage('/loan/intpay/loanSearch')
                    /*url = '/loan/intpay/loanSearch';*/
                }else if(val==2){
                    sta.recode({elementid:'myloan'});
                    sta.gotopage('/loan/intpay/myLoan')
                    /*url = '/loan/intpay/myLoan';*/
                }
               /* location.href = url;*/
            }
        }
    });
    module.exports =Vue;
});
