define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        sta=require("./intpay-cmd"),
       main = require("js_cmd/main-cmd");
    $(function(){    
    	// if(APP.isVdianAPP){
     //        main.checkAppLogin(null,null,function(){
     //            //登陆成功以后回调
     //        });
     //    }     
        initPage();
    });


    function initPage(){
       
    }
});