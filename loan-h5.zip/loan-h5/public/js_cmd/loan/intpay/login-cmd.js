define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        sta=require("./intpay-cmd"),
        main = require("js_cmd/main-cmd"),
       thirdValidator = null;
    $(function(){       
        initPage();        
    });


    function initPage(){
      if(!thirdValidator){
          require.async('js_cmd/loan/thirdValidator-cmd', function(tvr){
              thirdValidator= tvr;
          });
      }
       $("#phoneNo")[0].addEventListener("input", function(evt){
       		checkdata(this);
       });
        $("#code")[0].addEventListener("input", function(evt){
        	checkdata(this);
        });
       function checkdata(elm){
       		if(elm.value.length>0){
        		$(".del",$(elm).parent()).removeClass("disabled");
        	}else{
        		$(".del",$(elm).parent()).addClass("disabled");
        	}
            if(/^\d{11}$/.test($("#phoneNo").val())&/^\d{4}$/.test($("#code").val())){
            	$(".loginbtn").addClass("red");
            }
            else{
            	$(".loginbtn").removeClass("red");
            }
       }
       $(".del").click(function () {
       		$("input",$(this).parent()).val("");
       		$(".loginbtn").removeClass("red");
       		$(this).addClass("disabled");
       });
       $("#sendcode").click(function(){
          if($(this).hasClass("on")){
            var tel=$("#phoneNo").val();
         		if (!/^(13|15|17|18|14)[0-9]{9}$/.test(tel)) {
                  showmessage("请输入正确的手机号码~");
            }
            else{
              fn_sendVcode();
            }
          }
       });
       $("#login").click(function(){
          sta.fc_status("login","tap",APP.pageName,null);
       		fn_doLogin();
       });
       //发送验证
      function fn_sendVcode(validate, passCode){
          var args= {
              mobile:$("#phoneNo").val(),
              //mode:"h5Login"
               mode: "h5IntpayLogin",
               appIdentifier:"node-intpay"
          };
          if(validate){
              if("string"=== typeof validate){
                  //i.md.cn
                  args.data= {
                      ticket: validate,
                      csnonce: APP.newLogin&& APP.newLogin.csnonce
                  };
              }else{
                  args.validate= validate;
                  args.passCode= passCode;
              }
          }
          var l= loading();
          $.ajax({
              type: "POST",
              url: APP.urls.verify,
              data: args,
              async:true,
              success: function(result){
                  l.destroy();
                  if(0== result.code){
                      showmessage("验证码已发送");
                      startTick(59);
                  }else if("200002"== result.code){
                      //风险
                      var passCode= result.data&& result.data.url;
                      passCode= passCode&& passCode.match(/\d+$/)[0];
                      APP.thirdValidation= result.thirdValidation;
                      thirdValidator.showVerify(function(validate,passCode){
                         return {
                              onend: function(){
                                  fn_sendVcode(validate, passCode);
                              }
                          };
                      }, passCode);
                  }else{
                      alert(result.message);
                      $("#sendcode").addClass("on");
                  }
              },
              timeout: 4000,
              error: function () {
                  l.destroy();
                  alert("网络不稳定，点击发送验证码重试")
              },
              dataType: "json"
          });
      }
      //2-3 登录
        function fn_doLogin(){
            var l= loading(),
                args= {
                    verifycode: $("#code").val(),
                    mobile:$("#phoneNo").val(),
                    //mode:"h5Login"
                     mode: "h5IntpayLogin",
                     appIdentifier:"node-intpay"
                };
            $.ajax({
                type: "POST",
                url: APP.urls.login,
                //cache: false,
                data: args,
                async:true,
                success: function(result){
                    l.destroy();
                    if(0== result.code){
                        APP.isLogin= true;
                        APP.isSelfShop= result.data.isSelfShop;
                        var url=APP.urls.referrer.replace(/#38/g,"&");
                        sta.gotopage(url);                       
                    }else{
                        alert(result.message);
                    }
                },
                timeout: 4000,
                error: function () {
                    l.destroy();
                    alert("1111");
                },                
                dataType: "json"
            });
        }
      function startTick(seconds){
            var self= this, callee= arguments.callee;
            $("#sendcode").html(seconds+ "s");
            if(0=== seconds){
                $("#sendcode").html("发送验证码").addClass("on");
                timer= null;
            }else{
              $("#sendcode").removeClass("on")
                timer= setTimeout(function(){
                    callee(--seconds);
                }, 1000);
            }
        }
       function showmessage(message){
          $(".tips").show();
          $(".tips").html(message);

          setTimeout(function(){
              $(".tips").hide();
              $(".tips").html("");
          },3000);
       }
    }
});