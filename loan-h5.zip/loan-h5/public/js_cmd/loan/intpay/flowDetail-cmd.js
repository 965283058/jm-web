/**
 * Created by Administrator on 2017/2/14 0014.
 */
define(function (require,exports,module) {
    var l=null;
    var $ = require("lib_cmd/zepto-cmd"),
        sta=require("./intpay-cmd"),
        Vue = require('lib_cmd/vue-cmd'),
        DataService = require("./DataService-cmd"),
        flowDetailComponent = require("js_cmd/loan/intpay/widget/flowDetailComponent-cmd");
    Vue.filter('moibleAddStar',function (value) {
        var forword = value.slice(0,3),
            center =  value.slice(3,7),
            back = value.slice(-4),
            centerStr = '';
        for(var i = 0; i<center.length; i++){
            centerStr+= "*";
        }
        return forword+centerStr+back
    })
    APP.flowDetail = {
        getFlowDetail:function (res) {
            console.log(res)
            if(res.code == "0"){
                if(res.data){
                    res.data.response_status = 0;
                    if(res.data.response_status == "1"){
                        vm.isSuccess = true
                    }else if(res.data.response_status == "0"){
                        vm.isSuccess = false
                    };
                    vm.mobile = res.data.mobile;
                    vm.cellphone_traffic_success_to_account_date = res.data.cellphone_traffic_success_to_account_date , //成功到账日期,
                    vm.cellphone_traffic_expect_to_account_days = res.data.cellphone_traffic_expect_to_account_days ,   //预计流量到账天数
                    vm.mobile = res.data.mobile,   //手机号
                    vm.traffic_value = res.data.traffic_value,    //流量
                    vm.operate_time = res.data.operate_time
                }
            }
        }
    };

    var vm = new Vue({
        el:"#flowDetailMain",
        data:{
            cellphone_traffic_success_to_account_date:"" , //成功到账日期,
            cellphone_traffic_expect_to_account_days:'' ,   //预计流量到账天数
            mobile:"" ,                                      //手机号
            traffic_value:'',                                 //流量数量
            operate_time:'',                                 //申请日期
            isSuccess: false,                               //是否成功，成功就加success类
            pageTitle:false                                 //控制是否只有时间那块
        },
        methods:{
        }
    });

    //请求的参数
    var flowDetailRequestData = {
        "cellphone_traffic_journal_id": APP.cellphone_traffic_journal_id,   //流量流水表主键id
        "wid":1,
        "biz_account_source":2
    };
    if(APP.pageTitle == '1'){        //流量提取详情
        vm.pageTitle = true
    }else if(APP.pageTitle == '0'){   //结果详情
        vm.pageTitle = false
    }

    //设置请求url和请求的回调
    var flowDetailService = new DataService({
        url: APP.urls.flowDetail,
        pluginName: "flowDetail",
        actionName: "getFlowDetail"
    });
    flowDetailService.params = flowDetailRequestData;

    //发送请求
    flowDetailService.getData();


})