define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        main = require("js_cmd/main-cmd"),
        touchApp = require("js_cmd/touchApp-cmd"),
        sta = require("./intpay-cmd"),
        DataService = require("./DataService-cmd"),
        Vue = require('lib_cmd/vue-cmd'),
        navWidget = require("js_cmd/loan/intpay/widget/navWidget-cmd"),
        loading = require("js_cmd/loan/intpay/widget/loading-cmd");

    APP.productDetail = {
        getDetail:function(data){
            if(data.code!=0)return;
            vm.details = data.data.product;
            vm.limit = data.data.product.limit_min;
            vm.term = data.data.product.term_min;
            vm.dataUrl = data.data.product.apply_url
            if(vm.details.repay_type==1){
                vm.moneyPermonth = (vm.limit*(1+vm.details.rate_min*vm.term/100)/vm.term).toFixed(2);
               //vm.moneyPermonth = vm.limit*vm.details.rate_min/100;
            }
            vm.loadMore = false;
        },
        loan:function(data){
            /*if(data.code == -1){
                var curWwwPath = window.document.location.href;
                var pathName = window.document.location.pathname;
                var pos = curWwwPath.indexOf(pathName);
                var localhostPath = curWwwPath.substring(0, pos);
                var path=curWwwPath.replace(localhostPath,"");
                sta.gotopage(path); // 未登录跳转登录页面
            }*/
            if (data.code == 0){
               window.location.href = data.data.apply_url;

            } else {
                vm.isDialog = true;
                loanService.isbusy = false;
            }
        },
        login: function (res) {  //登录后的回调
           /* vm.inSubInfo = true*/
            if("success" == res.code){
                vm.showMessage('登录成功');
                // window.location.reload();
                APP.isPLogin = res.data;
                vm.applyLoan()
                setTimeout(function () {
                    vm.popHide = false
                },3000)
            }else{
                vm.showMessage(res.message);
            }
        },
        sendCode: function (res) {  //获取验证码后的回调
            if(res.code == "success") {
                vm.showMessage("验证码已发送");
                vm.startTick(59);
            }else{
                vm.showMessage(res.message);
                vm.sendCodeText = '发送验证码';
            }
        }
    };

    var vm = new Vue({
        data: {
            details: {
            },
            limit:0,
            term:0,
            moneyPermonth:0,
            isSend: false,
            applyFlag:false,
            materialFlag:false,
            processFlag:false,
            isDialog:false,
            loadMore:false,
            channel: APP.channel,
            phoneNum: '',//手机号
            codeNum: '',//验证码
            sendCodeText: '获取验证码',//验证码文案
            otherTips: '',//toast提示信息
            isShowPhoneInputDel: false,//是否显示手机号输入框的清空按钮
            isShowCodeInputDel: false,//是否显示验证码输入框的清空按钮
            inSubInfo: false,//是否正在进行提交操作
            confirmBtnActive: false ,//确定按钮是否加active类
            popHide: false ,  //点击按钮隐藏提示框
            dataUrl:""
        },
        computed:{
            confirmBtnActive: function () {
                if(vm.phoneNum.length !=0 && vm.codeNum.length !=0) {
                    return true 
                }
            }
        },
        watch: {
            phoneNum:{
                handler:function(){
                    vm.isShowPhoneInputDel = vm.phoneNum.length != 0
                }
            },
            codeNum:{
                handler:function(){
                    vm.isShowCodeInputDel = vm.codeNum.length != 0
                }
            }
        },
        methods:{
            clearInput: function (type) {
                if(type === "phone"){
                    vm.phoneNum = ""
                }else if(type === 'code'){
                    vm.codeNum = ""
                }
            },
            confirm: function () {  //确定登录
               /* if(this.inSubInfo) {
                    return false;
                };*/
                if(this.phoneNum.length == 0){
                    this.showMessage('请输入手机号');
                    return false;
                }else if(!/^(13|15|17|18|14)[0-9]{9}$/.test(this.phoneNum)){
                    this.showMessage('手机号格式不正确');
                    return false;
                };
                if(this.codeNum == ""){
                    this.showMessage("请输入验证码");
                    return false;
                };

                var receiveRewardRequestData = {
                    "phone": vm.phoneNum,
                    "authenticode":vm.codeNum,
                    "channel": APP.channel
                }

                //设置请求url和请求回调接口
                var receiveRewardService = new DataService({
                    url: APP.urls.qjdLogin,
                    pluginName: "productDetail",
                    actionName: "login"
                });
                receiveRewardService.params = receiveRewardRequestData;
                receiveRewardService.getData();
                /*this.inSubInfo = true*/

            },
            sendCode: function () {  //发送验证码
                if(this.sendCodeText == "获取验证码"){
                    this.sendCodeText = "获取验证码";
                    if(this.phoneNum.length == 0){
                        this.showMessage('请输入手机号')
                    }else if(!/^(13|15|17|18|14)[0-9]{9}$/.test(this.phoneNum)){
                        this.showMessage('手机号格式不正确')
                    }else {
                        var sendVcodeRequestData = {
                            smsListPhone: vm.phoneNum,
                            smsListIp: APP.clientIp,
                            channel:APP.channel
                        }
                        //设置请求url和请求回调接口
                        console.log(APP.urls.qjdsendCode);
                        var sendVcodeService = new DataService({
                            url: APP.urls.qjdsendCode,
                            pluginName: "productDetail",
                            actionName: "sendCode"
                        });
                        sendVcodeService.params = sendVcodeRequestData;
                        sendVcodeService.getData();
                    }
                }
            },
            showMessage: function (message) {
                vm.otherTips = message;
                setTimeout(function () {
                    vm.otherTips = ''
                },3000)
            },
            startTick: function (sec) {  //发送验证码倒计时
                this.sendCodeText = sec + "秒后重发";
                if(sec === 0){
                    this.sendCodeText = "获取验证码";
                    timer = null;
                }else {
                    timer = setTimeout(function () {
                        vm.startTick(--sec);
                    },1000);
                }
            },
            closePop: function () {
                this.popHide = false;
            },
            repayMethod: function (repay_method) {
                switch (repay_method) {
                    case 1: return '按月还款';
                    case 2: return '随借随还';
                    default: return '未知类型';
                }
            },
            toggleShow: function (type) {
                //var el = e.target;
                if(type=='applyFlag'){
                    this.applyFlag =!this.applyFlag;
                }else if(type=='materialFlag'){
                    this.materialFlag = !this.materialFlag;
                }else if(type=='processFlag'){
                    this.processFlag = !this.processFlag;
                }
            },
            hideDialog:function(){
                this.isDialog = false;
            },
            go2more:function(){
                sta.gotopage('/loan/loanSearch');
            },
            testMax:function(){
                if(this.limit>=this.details.limit_max){
                    this.limit = this.details.limit_max;
                    //this.moneyPermonth = (this.limit*(1+this.details.rate_min/100)/vm.term).toFixed(2);
                    //（金额*期限*利息+金额）/期限
                    this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
                    return;
                }
            },
            testMin:function(){
                if(this.limit<this.details.limit_min){
                    this.limit = this.details.limit_min;
                    this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
                    return;
                }
                this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            testMaxTerm:function(){
                if(this.term>=this.details.term_max){
                    this.term = this.details.term_max;
                    this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
                    return;
                }
                //this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            testMinTerm:function(){
                if(this.term<this.details.term_min){
                    this.term = this.details.term_min;
                    this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
                    return;
                }
                this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            termChange:function(){
                if(this.details.islinkage){
                    var linkage_list = this.details.linkage_list;
                    for(var i=0,len = linkage_list.length;i<len;i++){
                        if(this.term==linkage_list[i].detail_value){
                            this.limit = linkage_list[i].detail_value1;
                        }
                    }
                }
                this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            limitChange:function(){
                if(this.details.islinkage){
                    var linkage_list = this.details.linkage_list;
                    for(var i=0,len = linkage_list.length;i<len;i++){
                        if(this.limit==linkage_list[i].detail_value1){
                            this.term = linkage_list[i].detail_value;
                        }
                    }
                }
                this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            applyLoan: function () {
                var self = this;
                if(this.limit<this.details.limit_min||this.limit>this.details.limit_max){
                    alert('金额超出范围了！');
                    return;
                }
                if(this.term < this.details.term_min||this.term>this.details.term_max){
                    alert('期限超出范围了！');
                    return;
                }
                var args = {
                    product_id: APP.product_id,                    // 贷款产品id
                    product_type: self.details.product_type,                // 产品类型
                    biz_account_source: 2,                                  // 业务来源
                    apply_amount: self.limit,   // 贷款金额
                    apply_term: self.term,              // 贷款期限(月数)
                    apply_term_unit: self.details.repay_type==1?1:2,         // 贷款期限单位,月1，日2
                    is_sign:1  ,                   // 是否签署协议1是0否
                    channel: APP.channel,
                    clientIp:APP.clientIp,
                    phone: APP.isPLogin
                };
                /*  sta.recode({elementid:'submit'});*/
                loanService.params = args;

                //是否登录判断
                if (APP.isPLogin != "") {
                    console.log(11);
                    loanService.getData();
                } else {
                    console.log(22);
                    self.isSend = false;
                    // 未登录跳转登录页面
                    vm.popHide = true;
                }
                //loanService.getData();
            }
        }
    });
    var detailRequestData = {
        product_id: APP.product_id,
        channel: APP.channel,
        clientIp:APP.clientIp
    }
//设置请求url和请求回调接口
    var detailService = new DataService({
        url: APP.urls.getProductByCode,
        pluginName: "productDetail",
        actionName: "getDetail"
    });
    detailService.params = detailRequestData;
//发送请求
    detailService.getData();

//设置请求url和请求回调接口
    var loanService = new DataService({
        url: APP.urls.applyLoan,
        pluginName: "productDetail",
        actionName: "loan"
    });

    vm.loadMore = true;
    vm.$mount('.body');
    $(".body").css({display:"block"});

});
