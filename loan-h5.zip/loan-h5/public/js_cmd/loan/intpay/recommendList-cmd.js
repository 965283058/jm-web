define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        main = require("js_cmd/main-cmd"),
        sta = require("./intpayMain-cmd"),
        Vue = require('lib_cmd/vue-cmd');
    $(function(){
        // if(APP.isVdianAPP){
        //     main.checkAppLogin(null,null,function(){
        //         //登陆成功以后回调
        //     });
        // }  
        initPage();
    });


    function initPage(){

        var vm = new Vue({
            el: "#recommendList",
            data: {
                config: {
                    pageIndex: 1, // 第几列数据
                    pageSize: 10, // 每页显示数据
                    loadFlag: true, // 数据加载完成为false,
                    totalPage: 1 //数据总页数
                },
                productList: [],      //请求动态的数据存放
            },
            created: function () {
                var self = this,
                    config = self.config;
                self.getList(config.pageIndex, config.pageSize);

            },
            methods: {
                getList: function (pageIndex, pageSize) {
                    var self = this,
                        config = self.config;
                    // if (!config.loadFlag) return;
                    // main.eles.loading();
                    // $('#J_Loading').css('visibility', 'visible');
                    // config.loadFpage_sizelag = false;
                    // if (config.pageIndex > config.totalPage) {
                    //     return false;
                    // } else {
                        $.ajax({
                            type: "POST",
                            async: true,
                            dataType: "json",
                            url: APP.urls.queryProductList,
                            data: {
                                page_size:pageSize,
                                page_num:pageIndex
                            },
                            dataType: 'json',
                            success: function (res) {
                                // config.isscroll=1;
                                $('#J_Loading').css('visibility', 'hidden');
                                if(res.data.productList==undefined){
                                    res.data.productList=[];
                                }
                                if (res.code == 0 && res.data.productList.length != 0) {

                                    self.productList = res.data.productList || [];
                                    // self.$nextTick(function () {
                                    //     for(var len=res.data.productList.length, i=0; i<len; i++){
                                    //         res.data.productList[i].point = self.resolveArray(res.data.productList[i].productDetailList, 0);
                                    //     }
                                    // });
                                    // config.totalPage = Math.ceil(res.data.total / config.pageSize); //计算总页数
                                    // self.loanList = self.loanList.concat(productList);
                                    // if (config.totalPage <= config.pageIndex) {
                                    //     self._loading();
                                    //     config.loadFlag= false;
                                    // }else {
                                    //     config.loadFlag = true;
                                    // }
                                } else if (res.code == 0 && res.data.productList.length == 0) {
                                    alert('服务器开小差，点击空白刷新');
                                } else {
                                    if(res.msg!=undefined){
                                        alert(res.msg)
                                    }
                                    else{                                        
                                        alert(res.message);
                                    }
                                }
                                $("body").show();
                                $('.section-body').css('visibility', 'visible')
                            },
                            timeout: 4000,
                            error: function () {
                                $('#recommendList').innerHTML = '\
                                    <div id="errPage" style="width: 100%;height: 100%;text-align:center;vertical-align: middle">载入失败，点击空白刷新</div>\
                                    ';
                                $('.section-body').bind('click', function () {
                                    $('#errPage').display = 'none';
                                    location.reload();
                                });
                            }
                        })
                    // }

                },
                gotoDetails: function (e) {
                    var product_id = $(e.currentTarget).attr("id");
                    new sta.Statistics2().invoke({
                        action:     {
                            elementid: "item",
                            eventtype: "tap"
                        },
                        page:       {
                            pagename: APP.pageName,
                            url: location.href
                        },
                        business:   {
                        },
                        platform:   {

                        },
                        user:       {},
                        app:        {},
                        extend:     {
                            pid: product_id
                        }
                    }, function(result){
                        sta.gotopage('/loan/intpay/productDetails?money='+APP.money+'&v=111&term='+APP.term+'&product_id=' + product_id);
                    });

                },
                /**
                 * 在array选择type类型的值并组装成数组(没有使用)
                 * @param array
                 * @param type
                 * @returns {Array}
                 */
                resolveArray: function (array, type) {
                    var arr = [];
                    for(item in array){
                        if(item.detail_type == type){
                            arr.push(item.detail_value);
                        }
                    }
                    return arr;
                }
            },
            ready: function () {
                // var self = this,
                //     config = self.config;
                // $(window).on("scroll", function(){
                //     var nScrollTop = document.body.scrollTop,
                //         nClientHeight = document.documentElement.clientHeight,
                //         nBodyHeight = document.body.scrollHeight;
                //     if (nBodyHeight <= nScrollTop + nClientHeight) {
                //         if (config.loadFlag&config.isscroll==1) {
                //             self.getList(++config.pageIndex, config.pageSize);
                //         }else{
                //             $(window).off("scroll");
                //         }
                //     }
                // });
            },
            filters: {
                /**
                 * 当获取信息为空时显示‘- -’
                 * @param Info
                 * @returns {string}
                 */
                formatInfo: function (Info) {
                    var _info;
                    if((typeof Info=="undefined")||Info==''||Info=='null'){
                        _info = '— —'
                    }else {
                        _info = Info;
                    }
                    return _info;
                },
                formatRate: function (num) {
                    var rate = parseFloat(num).toFixed(2);
                    return (rate == 'NaN') ? ('- -'): (rate + '%/月');
                },
                formatRateDay: function (num) {
                    var rate = parseFloat(num).toFixed(2);
                    return (rate == 'NaN') ? ('- -'): (rate + '%/日');
                },
                formatMoney: function (num) {
                    var money = parseFloat(num).toFixed(2);
                    return (money == 'NaN') ? ('- -'): (money + '元/月');
                }
            }
        });
    }
});
