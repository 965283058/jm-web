define(function (require, exports, module) {
   var $ = require("lib_cmd/zepto-cmd"),
        Statistics2= require("js_cmd/statistics2-cmd"),
        touchApp=null;
        if(APP.isVdianAPP){
            var touchApp = require("js_cmd/touchApp-cmd");
            var TA= new touchApp();
            TA.setRightBtn("0");

        }

    function recode(obj){
        new Statistics2().invoke({
            action:     {
                elementid: obj.elementid||'',
                eventtype: obj.eventtype||'tap'
            },
            page:       {
                pagename: APP.pageName,
                url: location.href,
                uuid: ''
            },
            business:   {
            },
            platform:   {
            },
            user:       {},
            app:        {},
            extend:     obj.extend||{}
        }, function(result){
        });
    }
    function gotopage(url){            
        if(APP.isVdianAPP){
            var segue = {
                dest: "BaseWebViewActivity|ShareWebViewController",
                tips: null,
                segue:{
                    web:{
                        btn: 0,
                        title: null,
                        url:"http://"+window.location.host+url
                    }
                }
            }
            TA.jump(segue);
        }else{
            location.href = url;
        }
    }
    //打点
    function fc_status(elementid,eventtype,pagename,fn){

        new Statistics2().invoke({
            action:     {
                elementid: elementid,
                eventtype: eventtype
            },
            page:       {
                pagename: pagename,
                url: location.href
            },
            business:   {
            },
            platform:   {

            },
            user:       {},
            app:        {},
            extend:     {}
        }, function(result){
            if(fn) fn.call();
            console.log(result);
        });
    }
    module.exports = {
        fc_status:fc_status,
        Statistics2:Statistics2,
        gotopage:gotopage,
        recode:recode
    }
});
