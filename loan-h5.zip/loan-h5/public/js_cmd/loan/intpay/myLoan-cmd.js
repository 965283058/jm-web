/**
 * Created by Administrator on 2017/2/16 0016.
 */
define(function (require,exports,module) {
    var l=null;
    var $ = require("lib_cmd/zepto-cmd"),
        myDialog = require("lib_cmd/myDialog-cmd"),
        sta=require("./intpay-cmd"),
        Vue = require('lib_cmd/vue-cmd'),
        DataService = require("./DataService-cmd"),
        widgetTabNavi = require("js_cmd/loan/intpay/widget/tabNavi-cmd"),
        end = require("js_cmd/loan/intpay/widget/end-cmd"),
        loading = require("js_cmd/loan/intpay/widget/loading-cmd");
    APP.myLoan = {
        getLoanListData: function (res) {
            getLoanListService.isbusy = false;
            if(res.code == "0"){
                if(res.data){
                    vm.loadMore = false;
                    if(!res.data.loan_list) return;
                    if(getLoanListService.params.page_num==1&&res.data.loan_list.length==0){
                        vm.flag2 = true;   //没数据返回时的默认提示
                    }else{
                        if(res.data.loan_list.length==getLoanListService.params.page_size){
                            getLoanListService.params.page_num+=1;
                            getLoanListService.isbusy = false;
                        }else{
                            vm.flag = true;
                        }
                        vm.flag2 = false;
                    }
                    res.data.loan_list.forEach(function (v,i) {
                        if(Number(v.term_unit) === 1){
                            v.termDate = "个月"
                        }else if(Number(v.term_unit) === 2){
                            v.termDate = "天"
                        };
                        switch (v.loan_status){
                            case 1:
                                v.loanStatus = "申请中";
                                break;
                            case 2:
                                v.loanStatus = "成功";
                                break;
                            case 3:
                                v.loanStatus = "失败";
                                break;
                        }

                    })

                    vm.loanList = vm.loanList.concat(res.data.loan_list ||[]);
                }
            }
        }
    };
    //requestData请求数据
    getLoanListRequestData = {
        page_num:1,   //当前页数
        page_size:10,  //每页显示多少数据
        biz_account_source:2
    };
    //设置请求url和请求回调接口
    var getLoanListService = new DataService({
        url: APP.urls.getmyLoadList,
        pluginName: "myLoan",
        actionName: "getLoanListData"  //请求成功的回调
    });
    getLoanListService.params = getLoanListRequestData;
    var vm = new Vue({
        data:{
            flag:false,//到底啦~
            flag2:false,//记录为空的情况
            loadMore:false,//默认不加载
            isDialog: false, //是否显示弹窗
            loanList:[]   //
        },
        methods:{
            knowTips: function (ev) {
                if(ev ==1){
                    this.isDialog = true
                }
            },
            kownBtn: function () {
                this.isDialog = false
            },
            gotoIndex: function () {
                sta.gotopage("/loan/intpay/index");
            },
            confirmPhone: function () {
                
            }
        }
    })
    //发送请求
    vm.loadMore = true;  //未请求到数据之前让loading显示
    getLoanListService.getData();

    vm.$mount("#myLoanMain");
    $("#myLoanMain").css({display:"block"});

    $(window).off("scroll").on("scroll", function () {  //加载数据
        var scrollTop;
        if ($(document).height() - $(window).height() <= $(window).scrollTop() + 425) {
            if(getLoanListService.isbusy == false&&!vm.flag&&!vm.flag2){
                vm.flag = false;
                vm.loadMore = true;
                getLoanListService.getData();
            }
        }
    });

})