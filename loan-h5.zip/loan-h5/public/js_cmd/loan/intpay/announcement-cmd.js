define(function (require, exports, module) {
   var $ = require("lib_cmd/zepto-cmd"),
        main = require("js_cmd/main-cmd"),
        sta=require("./intpay-cmd"),
        Vue = require('lib_cmd/vue-cmd');
    $(function(){
        // if(APP.isVdianAPP){
        //     main.checkAppLogin(null,null,function(){
        //         //登陆成功以后回调
        //     });
        // }     
        initPage();
    });


    function initPage(){
        var vm = new Vue({
            el: "#announcement",
            data: {
                info: {}
            },
            ready: function () {
                var self = this;
                self.getAnnouncement();
            },
            methods: {
                getAnnouncement: function () {
                    var self = this;
                    $.ajax({
                        type: "POST",
                        async: true,
                        dataType: "json",
                        url: APP.urls.getAffiche,
                        data: {},
                        dataType: 'json',
                        success: function (res) {
                            if (res.code == 0) {
                                self.info = res.data;
                                $('.section-body').css('visibility', 'visible');
                            }
                            else {
                                // alert(res.msg);
                                if(res.msg!=undefined){
                                    alert(res.msg)
                                }
                                else{                                        
                                    alert(res.message);
                                }
                            }

                        },
                        timeout: 4000,
                        error: function () {
                            // alert('网络不稳定额~');
                            $('.section-body').innerHTML = '\
                                    <div style="width: 100%;height: 100%;text-align:center;vertical-align: middle">载入失败，点击空白刷新</div>\
                                    ';
                            $('.section-body').click= function () {
                                location.reload();
                            };
                        }
                    })

                }
            }
        });
    }
});
