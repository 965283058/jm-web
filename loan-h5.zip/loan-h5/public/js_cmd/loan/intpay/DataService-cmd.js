define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd");
    $.getData = function (requestData, options) {
        $.ajax($.extend({
            data:requestData,
            type: "POST",
            dataType: "json"
        }, options));
    }
    function DataService(oParams) {
        var self = this;
        this.totalCount = null;
        this.isAppend = true;//ƴ��
        this.canILoad = true;
        this.isbusy = false;
        this.loaderText = "Ŭ��������";
        this.loaderClass = "";
        this.params = {
//            lineId:"",
//            page:1,
//            pageSize:10,
//            dPlineAssess:0
        }
        this.builtParams = {
            "url":oParams.url,
            "CBPluginName": oParams.pluginName,
            "CBTagName": oParams.actionName
        }
    }


    DataService.prototype.getData = function () {

        if (this.isbusy || !this.canILoad) {
            return;
        }

        if ((this.params.page && this.params.page > this.totalCount && this.totalCount != null)) {
            this.loaderClass = " loaderNo";
            this.loaderText = "加载完成";
            this.canILoad = false;
            return false;
        }
        else {
            this.canILoad = true;
            this.loaderClass = "";
            this.loaderText = "加载中";
        }
        var self = this;
        this.isbusy = true;
        var ajaxObj = $.extend({}, this.params);
        this.builtParams.success=APP[self.builtParams.CBPluginName][self.builtParams.CBTagName];
        var param = this.builtParams;
        $.getData(ajaxObj,param);
    }

    DataService.prototype.encode = function (str) {
        return encodeURIComponent(str);
    }
    module.exports = DataService;
})
