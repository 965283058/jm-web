define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        main = require("js_cmd/main-cmd"),
        touchApp = require("js_cmd/touchApp-cmd"),
        sta=require("./intpayMain-cmd"),
        Vue = require('lib_cmd/vue-cmd');
        var wid=0;
    $(function(){   
        if(APP.isVdianAPP){
            main.checkAppLogin(null,null,function(){
            });
        }      
        initPage();
    });


    function initPage(){
        $(".refresh").click(function(){
            window.location.reload();
        });
       var vm = new Vue({
        el: "#repaymentList",
        data: {
            config: {
                pageIndex: 1, // 第几列数据
                pageSize: 20, // 每页显示数据
                loadFlag: true, // 数据加载完成为false,
                totalPage: 1, //数据总页数
                isscroll:0,
                repay_url:""                
            },
            list: [],      //请求动态的数据存放
            listcss:""
        },
        created: function () {
            var self = this,
                config = self.config;
            self.getList(config.pageIndex, config.pageSize);

        },
        filters: {
            range:function(str){
                var d= new Date(str)
                var year = d.getFullYear();
              var month = d.getMonth()+1;
              var date = d.getDate();
                return year+"-"+month+"-"+date
            }
        },
        methods: {
            _loading: function () { //添加页面加载到底部的特效
                $('#J_Loading').hide();
                $('#tips').html("没有更多了~");
            },
            
            getList: function (pageIndex, pageSize) {
                var self = this,
                    config = self.config;
                if (!config.loadFlag) return;
                main.eles.loading();
                $('#J_Loading').css('visibility', 'visible');
                config.loadFpage_sizelag = false;
                if (config.pageIndex > config.totalPage) {
                    return false;
                } else {
                    if(APP.isVdianAPP){
                        var TA=new touchApp();
                        TA.getUserInfo(function (userInfo) {
                            wid=userInfo.wid;
                            getinfo();
                        }); 
                    }
                    else{
                        getinfo();
                    }
                    function getinfo(){
                        $.ajax({
                            type: "POST",
                            async: true,
                            dataType: "json",
                            url: APP.urls.getrepaymentList,
                            data: {
                                page_size:pageSize,
                                page_num:pageIndex,
                                loanId:APP.loanId
                            },
                            dataType: 'json',
                            success: function (res) {
                                config.isscroll=1;
                                $(".refresh").hide();
                                $('#J_Loading').css('visibility', 'hidden');

                                config.repay_url=res.data.repay_url||"";
                                if (res.code == 0 && res.data.repay_list.length != 0) {
                                    $(".body").removeClass("disabled");
                                    self.listcss="hasdata";                                    
                                    var repay_list = res.data.repay_list || [];
                                    config.totalPage = Math.ceil(res.data.total / config.pageSize); //计算总页数
                                    self.list = self.list.concat(repay_list);
                                    if (config.totalPage <= config.pageIndex) {
                                        self._loading();
                                        config.loadFlag= false;
                                    }else {
                                        config.loadFlag = true;
                                    }
                                } else {
                                    if(res.code == 0&config.pageIndex==1&res.data.repay_list.length == 0){
                                        $(".body").removeClass("disabled");
                                        self.listcss="nodata";  
                                        $('#J_Loading').css('visibility', 'hidden');                                      
                                    }
                                    else{
                                        alert(res.msg);
                                    }
                                }
                                
                            },
                            timeout: 4000,
                            error: function () {
                                $('#J_Loading').css('visibility', 'hidden');
                                if(config.pageIndex==1){
                                    $(".refresh").show();
                                }
                                else{
                                    $('#tips').html("载入失败，向上滑动加载更多~");
                                }
                            }
                        })
                    }
                    
                }

            },
            gotopay:function(){                           
                sta.fc_status("submit","tap",APP.pageName,null);
                window.location.href=this.config.repay_url;     

            }
        },
        ready: function () {
            var self = this,
                config = self.config;
            $(window).on("scroll", function(){
                var nScrollTop = document.body.scrollTop,
                    nClientHeight = document.documentElement.clientHeight,
                    nBodyHeight = document.body.scrollHeight;
                if (nBodyHeight <= nScrollTop + nClientHeight) {
                    if (config.loadFlag&config.isscroll==1) {
                        self.getList(++config.pageIndex, config.pageSize);
                    }else{
                        $(window).off("scroll");
                    }
                }
            });
        }
    });
    }
});