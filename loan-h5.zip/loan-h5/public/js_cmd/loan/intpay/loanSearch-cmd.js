/**
 * Created by Administrator on 2017/2/14 0014.
 */
define(function (require,exports,module) {
    var l=null;
    var $ = require("lib_cmd/zepto-cmd"),
        myDialog = require("lib_cmd/myDialog-cmd"),
        sta = require("./intpay-cmd"),
        Vue = require('lib_cmd/vue-cmd'),
        DataService = require("./DataService-cmd"),
        widgetTabNavi = require("js_cmd/loan/intpay/widget/tabNavi-cmd"),
        end = require("js_cmd/loan/intpay/widget/end-cmd"),
        loading = require("js_cmd/loan/intpay/widget/loading-cmd"),
        empty = require("js_cmd/loan/intpay/widget/empty-cmd"),
        navWidget = require("js_cmd/loan/intpay/widget/navWidget-cmd"),
        widgetGoodsList = require("js_cmd/loan/intpay/widget/goodsList-cmd");
    APP.loanSearch = {
        goodsList:function(res){
            goodsListService.isbusy = false;
            if(res.code=="0"){
                if(res.data){
                    vm.loadMore = false;
                    var labelList = '';
                    if(goodsListService.params.amount_label && APP.amount_label){
/*                        vm.isAmount_label_show = true;
                    }else {*/
                        labelList =  res.data.amount_label_list;
                         for(var i=0,len=labelList.length;i<len;i++){
                             /*console.log(labelList[i].label_id);
                             console.log(goodsListService.params.amount_label)*/
                             if(labelList[i].label_id == goodsListService.params.amount_label){
	                             vm.money_value = labelList[i].label_name;
	                             vm.money_index = i;  //更新金额不限下的span的索引
	                             break;
                             }
                         }
                        vm.amount_label_list = labelList || '';
                        vm.isAmount_label_show = true;
                    };
                    if(goodsListService.params.type_label){
                        labelList =  res.data.type_label_list;
                        for(var i=0,len=labelList.length;i<len;i++){
                           /* console.log(labelList[i].label_id);
                            console.log(goodsListService.params.type_label);*/
                            if(labelList[i].label_id==goodsListService.params.type_label){
                                vm.type_value = labelList[i].label_name;
                                vm.type_key = i;   //更新类型不限下的span的索引
                                break;
                            }
                        }
                        vm.type_label_list = labelList || '';
                        vm.isAmount_label_show = true;
                    };
                    //if(!res.data.productList) return;
                    if(goodsListService.params.page==1&&!res.data.productList){ //没有返回productList
                        vm.flag2 = true;
                    }else if(goodsListService.params.page==1&&res.data.productList.length==0){ //返回了productList但是是个[]
                        vm.flag2 = true;
                    }else{
                        if(res.data.total==goodsListRequestData.limit){
                            vm.flag = true;
                        }else if(res.data.productList.length==goodsListRequestData.limit){
                            goodsListService.params.page+=1;
                            goodsListService.isbusy = false;
                        }else{
                            vm.flag = true;
                        }
                        vm.flag2 = false;
                    }
                    vm.amount_label_list = res.data.amount_label_list || '';
                    vm.type_label_list = res.data.type_label_list || '';
                    res.data.productList.forEach(function (v,i) {
                        if(Number(v.repay_type) === 1){
                            if(v.rate_min == null && v.rate_max!= null){
                                v.month = "参考月利率："+ Number(v.rate_max).toFixed(2)+"%"
                            }else if(v.rate_max == null && v.rate_min != null){
                                v.month = "参考月利率："+ Number(v.rate_min).toFixed(2)+"%"
                            }else if(v.rate_max == null && v.rate_min == null ){
                                v.month = "参考月利率：无"
                            }else if(v.rate_max == v.rate_min){
                                v.month = "参考月利率："+ Number(v.rate_min).toFixed(2)+"%"
                            }else {
                                v.month = "参考月利率: "+Number(v.rate_min).toFixed(2)+"%~"+Number(v.rate_max).toFixed(2)+"%"
                            }
                        }else if(Number(v.repay_type) === 2){
                            if(v.monthly_min == null && v.monthly_max!= null){
                                v.month = "参考月供："+ Number(v.monthly_max).toFixed(2)+"%"
                            }else if(v.monthly_max == null && v.monthly_min != null){
                                v.month = "参考月供："+ Number(v.monthly_min).toFixed(2)+"%"
                            }else if(v.monthly_max == null && v.monthly_min == null ){
                                v.month = "参考月供：无"
                            }else if(v.monthly_max == v.monthly_min){
                                v.month = "参考月供："+ Number(v.monthly_min).toFixed(2)+"%"
                            }else {
                                v.month = "参考月供: "+Number(v.monthly_min).toFixed(2)+"%~"+Number(v.monthly_max).toFixed(2)+"%"
                            }
                        }else if(Number(v.repay_type) === 3){
                            if(v.rate_day_min == null && v.rate_day_max!= null){
                                v.month = "参考日利率："+ Number(v.rate_day_max).toFixed(2)+"%"
                            }else if(v.rate_day_max == null && v.rate_day_min != null){
                                v.month = "参考日利率："+ Number(v.rate_day_min).toFixed(2)+"%"
                            }else if(v.rate_day_max == null && v.rate_day_min == null ){
                                v.month = "参考日利率：无"
                            }else if(v.rate_day_max == v.rate_day_min){
                                v.month = "参考日利率："+ Number(v.rate_day_min).toFixed(2)+"%"
                            }else {
                                v.month = "参考日利率: "+Number(v.rate_day_min).toFixed(2)+"%~"+Number(v.rate_day_max).toFixed(2)+"%"
                            }
                        }
                    })
                    vm.goodsList = vm.goodsList.concat(res.data.productList||[]);
                }
            }
        }

    }

    var vm = new Vue({
        data:{
            flag:false,//到底啦~
            flag2:false,//记录为空的情况
            loadMore:false,//默认不加载
            type_index:-1,  //金额和类型不限的2个大标签
            tabs_con_is_show:false, //金额和类型下的整体span标签默认不显示
            goodsList:[],   //动态请求数据的存放
            amount_label_list:[],  //金额不限下的span标签请求的数据存放
            type_label_list:[],    //类型不限下的span标签请求的数据存放
            money_index:-1,  //金额不限下的span标签索引
            type_key:-1,     //类型不限下的span标签索引
            money_value:'金额不限',   //金额不限的默认选中文字
            type_value: '类型不限' ,    //类型不限的默认选中文字
            moneyId:'',   //金额不限下的span标签id
            typeId:'' ,    //类型不限下的span标签id
            isAmount_label_show: true,  //首页如果是金额类别的跳过来，头部那块不显示,
            channel:APP.channel
        },
        methods:{
            type:function(val){
                if(this.type_index==val){
                    this.tabs_con_is_show = false;
                    this.type_index = -1;
                    return;
                }
                this.type_index = val;
                this.tabs_con_is_show = true;
            },
            maskTap:function(){
                this.tabs_con_is_show = false;
                this.type_index = -1;
            },
            moneyClick:function(val,money_value){
                if(this.money_index==val){
                    this.tabs_con_is_show = false;
                    this.type_index = -1;
                    return;
                };
                this.moneyId = money_value.target.id;
                this.money_value = money_value.target.innerText;
                this.money_index = val;
                this.tabs_con_is_show = false;
                this.type_index = -1;
                goodsListRequestData.page = 1;
                goodsListRequestData.amount_label = this.moneyId
                goodsListRequestData.type_label = goodsListRequestData.type_label || "";
                this.goodsList = [];
                this.flag = false;
                goodsListService.getData();
                /*new sta.Statistics2().invoke({
                    action:     {
                        elementid: "money",
                        eventtype: "tap"
                    },
                    page:       {
                        pagename: APP.pageName,
                        url: location.href
                    },
                    business:   {
                    },
                    platform:   {

                    },
                    user:       {},
                    app:        {},
                    extend:     {
                       /!* pid: moneyId*!/
                    }
                });*/

            },
            typeClick: function (val,type_value) {
                if(this.type_key == val){
                    this.tabs_con_is_show = false;
                    this.type_index = -1;
                    return;
                }
                this.typeId = type_value.target.id;
                this.type_value = type_value.target.innerText;
                this.type_key = val;
                this.tabs_con_is_show = false;
                this.type_index = -1;
                goodsListRequestData.page = 1;
                goodsListRequestData.amount_label = goodsListRequestData.amount_label || "";
                goodsListRequestData.type_label = this.typeId;
                this.goodsList = [];
                this.flag = false;
                goodsListService.getData();
                /*new sta.Statistics2().invoke({
                    action:     {
                        elementid: "type",
                        eventtype: "tap"
                    },
                    page:       {
                        pagename: APP.pageName,
                        url: location.href
                    },
                    business:   {
                    },
                    platform:   {

                    },
                    user:       {},
                    app:        {},
                    extend:     {
                        /!* pid: typeId*!/
                    }
                });*/
               /* sta.recode({elementid:'type'});*/
            }
        }
    })
    vm.$mount('#searchMain');
    $("#searchMain").css({display:"block"});

    //requestData请求数据
    goodsListRequestData = {
        page:1,
        limit:10,
        biz_account_source:2,
        channel: APP.channel,
        clientIp:APP.clientIp
    }
    if(APP.type_label){
        goodsListRequestData.type_label = APP.type_label || "";
    }
    if(APP.amount_label){
        goodsListRequestData.amount_label = APP.amount_label || "";
    }

//设置请求url和请求回调接口
    var goodsListService = new DataService({
        url: APP.urls.queryProductList,
        pluginName: "loanSearch",
        actionName: "goodsList"
    });
    goodsListService.params = goodsListRequestData;
//发送请求
    vm.loadMore = true;   //后台没返回数据之前设置loading为true
    goodsListService.getData();

    $(window).off("scroll").on("scroll", function () {
        var scrollTop;
        if ($(document).height() - $(window).height() <= $(window).scrollTop() + 425) {
            if(goodsListService.isbusy == false&&!vm.flag&&!vm.flag2){
                vm.flag = false;
                vm.loadMore = true;
                goodsListService.getData();
            }
        }
    })
})