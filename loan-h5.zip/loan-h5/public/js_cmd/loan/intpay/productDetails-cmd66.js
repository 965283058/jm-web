define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        main = require("js_cmd/main-cmd"),
        touchApp = require("js_cmd/touchApp-cmd"),
        sta = require("./intpayMain-cmd"),
        DataService = require("./DataService-cmd"),
        Vue = require('lib_cmd/vue-cmd'),
        navWidget = require("js_cmd/loan/intpay/widget/navWidget-cmd"),
        loading = require("js_cmd/loan/intpay/widget/loading-cmd");


    APP.productDetail = {
        getDetail:function(data){
            if(data.code!=0)return;
            vm.details = data.data.product;
            vm.limit = data.data.product.limit_max;
            vm.term = data.data.product.term_max;
            if(vm.details.repay_type==1){
                vm.moneyPermonth = (vm.limit*(1+vm.details.rate_min*vm.term/100)/vm.term).toFixed(2);
               //vm.moneyPermonth = vm.limit*vm.details.rate_min/100;
            }
            vm.loadMore = false;
        },
        loan:function(data){
            if(data.code == -1){
                var curWwwPath = window.document.location.href;
                var pathName = window.document.location.pathname;
                var pos = curWwwPath.indexOf(pathName);
                var localhostPath = curWwwPath.substring(0, pos);
                var path=curWwwPath.replace(localhostPath,"");
                sta.gotopage(path); // 未登录跳转登录页面
            }
            if (data.code == 0){
                window.location.href = data.data.apply_url;
            } else {
                vm.isDialog = true;
                loanService.isbusy = false;
            }
        }
    };
    var detailRequestData = {
        product_id: APP.product_id
    }
//设置请求url和请求回调接口
    var detailService = new DataService({
        url: APP.urls.getProductByCode,
        pluginName: "productDetail",
        actionName: "getDetail",
        channel: APP.channel
    });
    detailService.params = detailRequestData;
//发送请求
    detailService.getData();

//设置请求url和请求回调接口
    var loanService = new DataService({
        url: APP.urls.applyLoan,
        pluginName: "productDetail",
        actionName: "loan"
    });
    var vm = new Vue({
        data: {
            details: {
            },
            limit:0,
            term:0,
            moneyPermonth:0,
            isSend: false,
            applyFlag:false,
            materialFlag:false,
            processFlag:false,
            isDialog:false,
            loadMore:false
        },
        methods:{
            repayMethod: function (repay_method) {
                switch (repay_method) {
                    case 0: return '随借随还';
                    case 1: return '等额本金';
                    case 2: return '等额本息';
                    default: return '未知类型';
                }
            },
            toggleShow: function (type) {
                //var el = e.target;
                if(type=='applyFlag'){
                    this.applyFlag =!this.applyFlag;
                }else if(type=='materialFlag'){
                    this.materialFlag = !this.materialFlag;
                }else if(type=='processFlag'){
                    this.processFlag = !this.processFlag;
                }
            },
            hideDialog:function(){
                this.isDialog = false;
            },
            go2more:function(){
                sta.gotopage('/loan/loanSearch');
            },
            testMax:function(){
                if(this.limit>=this.details.limit_max){
                    this.limit = this.details.limit_max;
                    //this.moneyPermonth = (this.limit*(1+this.details.rate_min/100)/vm.term).toFixed(2);
                    //（金额*期限*利息+金额）/期限
                    this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
                    return;
                }
            },
            testMin:function(){
                if(this.limit<this.details.limit_min){
                    this.limit = this.details.limit_min;
                    this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
                    return;
                }
                this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            testMaxTerm:function(){
                if(this.term>=this.details.term_max){
                    this.term = this.details.term_max;
                    this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
                    return;
                }
                //this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            testMinTerm:function(){
                if(this.term<this.details.term_min){
                    this.term = this.details.term_min;
                    this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
                    return;
                }
                this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            termChange:function(){
                if(this.details.islinkage){
                    var linkage_list = this.details.linkage_list;
                    for(var i=0,len = linkage_list.length;i<len;i++){
                        if(this.term==linkage_list[i].detail_value){
                            this.limit = linkage_list[i].detail_value1;
                        }
                    }
                }
                this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            limitChange:function(){
                if(this.details.islinkage){
                    var linkage_list = this.details.linkage_list;
                    for(var i=0,len = linkage_list.length;i<len;i++){
                        if(this.limit==linkage_list[i].detail_value1){
                            this.term = linkage_list[i].detail_value;
                        }
                    }
                }
                this.moneyPermonth = (this.limit*(1+this.details.rate_min*this.term/100)/this.term).toFixed(2);
            },
            applyLoan: function () {
                var self = this;
                if(this.limit<this.details.limit_min||this.limit>this.details.limit_max){
                    alert('金额超出范围了！');
                    return;
                }
                if(this.term < this.details.term_min||this.term>this.details.term_max){
                    alert('期限超出范围了！');
                    return;
                }
                var args = {
                    product_id: APP.product_id,                    // 贷款产品id
                    product_type: self.details.product_type,                // 产品类型
                    biz_account_source: 2,                                  // 业务来源
                    apply_amount: self.limit,   // 贷款金额
                    apply_term: self.term,              // 贷款期限(月数)
                    apply_term_unit: self.details.repay_type==1?1:2,         // 贷款期限单位,月1，日2
                    is_sign:1                     // 是否签署协议1是0否
                };
                // sta.recode({elementid:'submit'});
                loanService.params = args;
                if (APP.isVdianAPP) {
                    main.checkAppLogin(null, null, function () {
                        var TA = new touchApp();
                        TA.getUserInfo(function (userInfo) {
                            loanService.getData();
                        });
                    });
                }
                else {
                    if (APP.isLogin) {
                        loanService.getData();
                    } else {
                        self.isSend = false;
                        var curWwwPath = window.document.location.href;
                        var pathName = window.document.location.pathname;
                        var pos = curWwwPath.indexOf(pathName);
                        var localhostPath = curWwwPath.substring(0, pos);
                        var path = curWwwPath.replace(localhostPath, "").replace(/&/g, "%2338");
                       /* sta.gotopage("/loan/intpay/login?referrer=" + path); // 未登录跳转登录页面*/
                    }
                }
            }
        }
    });
    vm.loadMore = true;
    vm.$mount('.section-body');
    $(".section-body").css({display:"block"});

});
