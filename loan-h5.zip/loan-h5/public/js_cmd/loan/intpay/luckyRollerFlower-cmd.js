define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        award = require('./awardRotate-cmd'),
        Vue = require('lib_cmd/vue-cmd'),
        main = require("js_cmd/main-cmd"),
        DataService = require("./DataService-cmd"),
        touchApp = require("js_cmd/touchApp-cmd"),
        sta = require("./intpay-cmd");
    var turnplate = {
        restaraunts: [],
        //大转盘奖品名称
        colors: [],
        //大转盘奖品区块对应背景颜色
        outsideRadius: 162,
        //大转盘外圆的半径
        textRadius: 125,
        //大转盘奖品位置距离圆心的距离
        insideRadius: 42,
        //大转盘内圆的半径
        startAngle: 1.5 * Math.PI,
        //开始角度
        bRotate: false,
        //中奖id
        prize_id:"",
        //中奖id名称
        prize_id_name:"",
        //大转盘渲染数据未拼接
        newValueListArray: []
    };
    Vue.filter('moibleAddStar',function (value) {  //处理电话号码为*
        var forword = value.slice(0,3),
            center =  value.slice(3,7),
            back = value.slice(-4),
            centerStr = '';
        for(var i = 0; i<center.length; i++){
            centerStr+= "*";
        }
        return forword+centerStr+back
    })
    APP.getflowDraw = {
        getFlowDrawData: function (res) {  //获取大转盘数据和上下滚动数据
            console.log(res)
            if(res.code == "0"){
                getflowDrawService.isbusy = false;
                if(res.data){
                    vm.scrolled_list = res.data.scrolled_list || '';   //上下滚动数据
                    vm.current_extract_times = res.data.current_extract_times || 0;  //当前可抽次数
                    var valuaList = res.data.cellphone_traffic_value_list,  //  大转盘渲染数据
                        newValueList = "";
                    if(valuaList == ""){
                        return;
                    }
                    for(var i = 0; i < valuaList.length; i++){
                        turnplate.newValueListArray.push(valuaList[i].cellphone_traffic_value);
                        newValueList = valuaList[i].cellphone_traffic_value + "M流量";
                        turnplate.restaraunts.push(newValueList);
                        //console.log(turnplate.restaraunts)
                        //拿到大转盘配置数据后进行渲染
                        drawRouletteWheel()
                    };
                }
            }
        },
        luckdraw: function (res) {   //抽奖数据
            console.log(res)
            if(res.code !=0 ) {
                return;
            }else {
                if(res.data){
                    //res.data.end_status = 1
                    if(res.data.end_status == 1){   //1表活动已结束
                        $(".result-div").addClass("failed gameover");
                    }
                    getLuckDrawService.isbusy = false;
                    turnplate.prize_id_name = res.data.lottery_detail.prize_id;
                    console.log(turnplate.newValueListArray);
                    console.log(turnplate.prize_id_name)
                    turnplate.prize_id = turnplate.newValueListArray.indexOf(turnplate.prize_id_name);
                    console.log(turnplate.prize_id)
                }
            }
        }

    }

    var vm = new Vue({
        el:"#flow-draw",
        data:{
            scrolled_list:'',  //上下滚动数据
            current_extract_times:'' //当前可抽奖次数
        },
        methods:{
            jump: function () {
                sta.recode({elementid:'agent'});
                sta.gotopage('/loan/intpay/makeMoney')
            }
        }
    })

    /***********大转盘数据渲染部分****************/
    //requestData大转盘请求数据
    getflowDrawRequestData = {
       /* wid: APP.wid,*/
        "wid": 1,
        "biz_account_source":2,
        "limit":100
    };
    //设置请求大转盘url和请求回调接口
    var getflowDrawService = new DataService({
        url: APP.urls.getFlowRender,
        pluginName: "getflowDraw",
        actionName: "getFlowDrawData"  //请求成功的回调
    });
    getflowDrawService.params = getflowDrawRequestData;
    //大转盘发送请求
    getflowDrawService.getData();

    /***********立即抽奖部分****************/
    //requestData立即抽奖请求数据
    luckDrawRequestData = {
        /*wid: APP.wid,*/
        wid: 1,
        lottery_type:2
    };
    //设置立即抽奖url和回调接口
    var getLuckDrawService = new DataService({
        url: APP.urls.getLuckDraw,
        pluginName: "getflowDraw",
        actionName: "luckdraw"  //请求成功的回调
    });
    getLuckDrawService.params = luckDrawRequestData;
    //立即抽奖发送请求
    getLuckDrawService.getData();


    $(document).ready(function () {
        turnplate.colors = ["#FED012", "#F9DE6F"];
        var rotateTimeOut = function () {
            $("#wheelcanvas").rotate({
                angle: 0,
                animateTo: 2160,
                duration: 8e3,
                callback: function () {
                    alert("载入失败，点击空白刷新！");
                }
            });
        };
        //旋转转盘 item:奖品位置; txt：提示语;
        var rotateFn = function (item, txt) {
            var angles = (-1) * (item - 1) * (360 / turnplate.restaraunts.length);
            console.log(angles)
            $("#wheelcanvas").stopRotate();
            $("#wheelcanvas").rotate({
                angle: 0,
                animateTo: angles + 1800,
                duration: 8e3,
                callback: function () {
                    console.log(txt);
                    //弹出抽到的奖品
                    if(txt == undefined){
                        return;
                    }
                    var index = txt.indexOf("M");
                    var before = txt.slice(0,index+1);
                    var after = txt.slice(index+1);
                    $(".cover-div").show();
                    $(".addTxt").html("");
                    if (txt.indexOf("未中奖") != -1) {
                        $(".addTxt").html("你未中奖")
                    } else {
                        $(".addTxt").html("获得"+before+"手机"+after);
                    }
                    $(".result-div").show();
                    $(".inviteBtn-r").click(function () {
                        sta.gotopage('http://www.baidu.com')
                    })
                    turnplate.bRotate = !turnplate.bRotate;
                }
            });
        };

        $(".pointer").click(function () {   //点击旋转转盘
            //vm.current_extract_times = 0;
            if ( getLuckDrawService.isbusy == true ){
                return;
            }
            if($(".result-div").hasClass('gameover')) {
                gameover();
                return;
            }
            getLuckDrawService.getData();
            if (vm.current_extract_times <= 0) {
                $(".result-div").addClass("failed");
                $(".addTxt").html("<p style='padding: 0 20px;'>您暂时没有抽流量的资格</p>去做经纪人，邀好友，赚流量吧");
                $(".inviteBtn-r").html("立即去赚流量").click(function () {
                    location.href = "/loan/intpay/makeMoney"
                });
                $(".result-div").show();
                $(".cover-div").show();
                return;
            }
            turnplateRotate();
            sta.recode({elementid:'draw'});
        });

        function gameover(){    //活动已结束
            $(".addTxt").html("活动已结束");
            $(".result-div").show();
            $(".cover-div").show();
        };

        function turnplateRotate() {        //旋转转盘
            if (turnplate.bRotate) return;
            turnplate.bRotate = !turnplate.bRotate;
            //获取随机数(奖品个数范围内)
           /* var item = rnd(1, turnplate.restaraunts.length); //item为获奖的奖项位置*/
            //奖品数量等于10,指针落在对应奖品区域的中心角度[252, 216, 180, 144, 108, 72, 36, 360, 324, 288]
            var item = turnplate.prize_id + 1;
            rotateFn(item, turnplate.restaraunts[item -1]);
            console.log(item);
        };

        //相应js点击事件
        $(".cover-div").hide();
        //关闭抽奖结果中的按钮
        $(".close-img").click(function () {
            $(".result-div").hide();
            $(".cover-div").hide();
        });


        //上下滚动
        var total = 1;
        var a = setInterval(function () {
            if (total == 4) {
                total = 0;
                $(".adv ul").css({marginTop: (-30) * total + "px"});
                total++;
            } else {
                $(".adv ul").animate({marginTop: (-30) * total + "px"}, 1000);
                total++;
            }
        }, 5000);

    });

   /* function rnd(n, m) {
        var random = Math.floor(Math.random() * (m - n + 1) + n);
        return random;
    }*/

    function drawRouletteWheel() {
        var canvas = document.getElementById("wheelcanvas");
        if (canvas.getContext) {
            //根据奖品个数计算圆周角度
            var arc = Math.PI / (turnplate.restaraunts.length / 2);
            var ctx = canvas.getContext("2d");
            //在给定矩形内清空一个矩形
            ctx.clearRect(0, 0, 424, 424);
            //strokeStyle 属性设置或返回用于笔触的颜色、渐变或模式
            ctx.strokeStyle = "#FFBE04";
            //font 属性设置或返回画布上文本内容的当前字体属性
            ctx.font = "16px Microsoft YaHei";
            for (var i = 0; i < turnplate.restaraunts.length; i++) {
                var angle = turnplate.startAngle + (i - 0.5) * arc;
                ctx.fillStyle = turnplate.colors[(i % 2)];
                ctx.beginPath();
                //arc(x,y,r,起始角,结束角,绘制方向) 方法创建弧/曲线（用于创建圆或部分圆）
                ctx.arc(212, 212, turnplate.outsideRadius, angle, angle + arc, false);
                ctx.arc(212, 212, turnplate.insideRadius, angle + arc, angle, false);
                ctx.stroke();
                ctx.fill();
                //锁画布(为了保存之前的画布状态)
                ctx.save();
                //----绘制奖品开始----
                ctx.fillStyle = "#DE5724";
                var text = turnplate.restaraunts[i];
                var line_height = 22;
                //translate方法重新映射画布上的 (0,0) 位置
                ctx.translate(212 + Math.cos(angle + arc / 2) * turnplate.textRadius, 212 + Math.sin(angle + arc / 2) * turnplate.textRadius);
                //rotate方法旋转当前的绘图
                ctx.rotate(angle + arc / 2 + Math.PI / 2);
                /** 下面代码根据奖品类型、奖品名称长度渲染不同效果，如字体、颜色、图片效果。(具体根据实际情况改变) **/
                if (text.indexOf("M") > 0) {
                    //流量包
                    var texts = text.split("M");
                    for (var j = 0; j < texts.length; j++) {
                        if (j == 0) {
                            ctx.fillText(texts[j] + "M", -ctx.measureText(texts[j] + "M").width / 2, j * line_height);
                        } else {
                            ctx.fillText(texts[j], -ctx.measureText(texts[j]).width / 2, j * line_height);
                        }
                    }
                } else if (text.indexOf("M") == -1 && text.length > 6) {
                    //奖品名称长度超过一定范围
                    text = text.substring(0, 3) + "||" + text.substring(3, 6) + "||" + text.substring(6);
                    var texts = text.split("||");
                    for (var j = 0; j < texts.length; j++) {
                        ctx.fillText(texts[j], -ctx.measureText(texts[j]).width / 2, j * line_height);
                    }
                } else {
                    //在画布上绘制填色的文本。文本的默认颜色是黑色
                    //measureText()方法返回包含一个对象，该对象包含以像素计的指定字体宽度
                    ctx.fillText(text, -ctx.measureText(text).width / 2, 0);
                }
                //把当前画布返回（调整）到上一个save()状态之前 */
                ctx.restore();
            }
        }
    }
});


