define(function (require, exports, module) {
    var Vue = require('lib_cmd/vue-cmd'),
        DataService = require("./DataService-cmd"),
        sta=require("./intpayMain-cmd"),
        myDialog = require("lib_cmd/myDialog-cmd"),
        thirdValidator = require("js_cmd/loan/thirdValidator-cmd");

    //rem自适应
    var ohtml = document.documentElement;
    getSize()
    window.onresize=function(){
        getSize()
    }
    function getSize(){
        var screenWidth = ohtml.clientWidth;
        screenWidth = screenWidth > 750 ? 750 : screenWidth;
        ohtml.style.fontSize = screenWidth*100/750+'px';
        // 设置底部信息的margin值，使其始终居于底部
        var screenHeight = ohtml.clientHeight;
        var otherHeight = ohtml.clientWidth/750 * 885 + (3.2 + 0.5) * (screenWidth*100/750);
        var marginNum = (screenHeight-otherHeight) / (screenWidth*100/750);
        marginNum = marginNum > 0.5 ? marginNum : 0.5;
        document.querySelector(".footer-content").style.marginTop = marginNum + 'rem';
    }
    APP.shareMakeMoney = {
        sendVcode:function(res){//发送验证码获得结果后回调方法
            if(res.code == 0){
                vm.showMessage("验证码已发送");
                vm.startTick(59);
            }else if("200002" == res.code) {
                //风险
                var passCode= res.data && res.data.url;
                passCode= passCode&& passCode.match(/\d+$/)[0];
                APP.thirdValidation= res.thirdValidation;
                thirdValidator.showVerify(function(validate,passCode){
                    return {
                        onend: function(){
                            APP.shareMakeMoney.sendVcode(validate, passCode);
                        }
                    };
                }, passCode);
            }else{
                vm.showMessage(res.message);
                vm.sendCodeText = '发送验证码';
            }
        },
        receiveReward:function(res){//登录回调方法
            vm.inSubInfo = true
            if(0 == res.code){
                APP.isLogin= true;
                APP.isSelfShop= res.data.isSelfShop;
                if(res.message == '注册成功'){
                    vm.isShowSuccessPop = true
                } else{
                    vm.isShowFailPop = true
                }
            }else{
                vm.showMessage(res.message);
            }
        },
        GetQueryString:function(name) {////获取URL参数
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r!=null)
                return  decodeURI(r[2]);
            return null;
        }
    };
    var vm = new Vue({
        data: {
            phoneNum: '',//手机号
            codeNum: '',//验证码
            sendCodeText: '发送验证码',//验证码文案
            isShowSuccessPop: false,//显示新用户提示框
            isShowFailPop:  false,//显示老用户提示框
            otherTips: '',//toast提示信息
            isShowPhoneInputDel: false,//是否显示手机号输入框的清空按钮
            isShowCodeInputDel: false,//是否显示验证码输入框的清空按钮
            inSubInfo: false//是否正在进行提交操作
        },
        watch:{//监听事件
            phoneNum:{
                handler:function(){
                    vm.isShowPhoneInputDel = vm.phoneNum.length != 0
                }
            },
            codeNum:{
                handler:function(){
                    vm.isShowCodeInputDel = vm.codeNum.length != 0
                }
            }
        },
        methods: {
            clearInput:function(type){//清空input
                if(type == 'phone'){
                    vm.phoneNum = ''
                }else if(type == 'code'){
                    vm.codeNum = ''
                }
            },
            receiveReward:function () {//领取奖励方法
                if(this.inSubInfo) {
                    return false
                }
                if(this.phoneNum.length == 0){
                    this.showMessage("请输入手机号");
                    return false;
                }else if (!/^(13|15|17|18|14)[0-9]{9}$/.test(this.phoneNum)) {
                    this.showMessage("手机号格式错误，请重新输入");
                    return false;
                }
                if(this.codeNum == ''){
                    this.showMessage('请输入验证码');
                    return false;
                }
                var receiveRewardRequestData = {
                    verifycode: vm.codeNum,
                    mobile: vm.phoneNum,
                    mode: "h5IntpayLogin",
                    appIdentifier:"node-intpay"
                }
                //设置请求url和请求回调接口
                var receiveRewardService = new DataService({
                    url: APP.urls.login,
                    pluginName: "shareMakeMoney",
                    actionName: "receiveReward"
                });
                receiveRewardService.params = receiveRewardRequestData;
                receiveRewardService.getData();
                // 立即赚钱打点
                sta.recode({elementid:'receive'});
                this.inSubInfo = true
            },
            showMessage:function (message){//Toast提示信息
                vm.otherTips = message
                setTimeout(function(){
                    vm.otherTips = ''
                },3000);
            },
            sendCode:function(){//发送验证码
                if(this.sendCodeText == '发送验证码'){
                    this.sendCodeText = '发送验证码 '
                    if(this.phoneNum.length == 0){
                        this.showMessage("请输入手机号");
                    }else if (!/^(13|15|17|18|14)[0-9]{9}$/.test(this.phoneNum)) {
                        this.showMessage("手机号格式错误，请重新输入");
                    }else{
                        var sendVcodeRequestData = {
                            mobile: vm.phoneNum,
                            mode: "h5IntpayLogin",
                            appIdentifier:"node-intpay"
                        }
                        //设置请求url和请求回调接口
                        var sendVcodeService = new DataService({
                            url: APP.urls.verify,
                            pluginName: "shareMakeMoney",
                            actionName: "sendVcode"
                        });
                        sendVcodeService.params = sendVcodeRequestData;
                        sendVcodeService.getData();
                    }
                }
            },
            startTick:function(seconds){//发送验证码按钮倒计时
                this.sendCodeText = seconds + "s";
                if(0 === seconds){
                    this.sendCodeText = "发送验证码";
                    timer = null;
                }else{
                    timer= setTimeout(function(){
                        vm.startTick(--seconds);
                    }, 1000);
                }
            },
            goDownLoadApp:function(){
                // 浮层-下载APP打点
                sta.recode({elementid:'dowmload'});
                // location.href = ""
            }
        }
    });
    //发送请求
    // indexService.getData();
    vm.$mount('#shareMakeMoney-body');
    document.getElementById("shareMakeMoney-body").style.display = 'block'
});