define(function(require,exports,module){
	var els,i,
	makeTouchFeedback=function(context){
		els=(context||document).querySelectorAll('.touchFeedback')
		if(!els.length)return;
		for(i=0;i<els.length;i++){
			els[i].addEventListener('touchstart',s)
			els[i].addEventListener('touchend',e)
		}
		els=null
	}
	function s(){this.classList.add('tc');this.addEventListener('touchmove',m)}
	function m(){this.classList.remove('tc');this.removeEventListener('touchmove',m)}
	function e(){this.classList.remove('tc');this.removeEventListener('touchmove',m)}
	els=null
	makeTouchFeedback()
	module.exports=makeTouchFeedback
})