/*****************
 * 该文件用于讲某些页面改造为分享赚模式，分享出去的url要有/share
 *****************/
define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        shareApp = require("js_cmd/shareApp-cmd"),
        touchApp= require("js_cmd/touchApp-cmd"),
        statistics2 = require('js_cmd/statistics2-cmd');

    var TA= new touchApp();
    var appInfo = {};
    var permitShare = null;
    var sass = new statistics2();
    //
    function fxzPoint () {
        
    }
    fxzPoint.prototype = {
        configShare: function (noTitle) {
            getShareInfo(noTitle);
        },
        check: function (pageName) {
            if (APP.srcBizType == 1) { //是分享赚活动
                setTimeout(function () {
                    $.ajax({
                        type: "POST",
                        url: '/api/stayPage/check',
                        dataType: 'json',
                        data: {
                            pageName: pageName,
                            url: location.href,
                            is_valid: APP.status
                        },
                        success: function (res) {
                            console.log('checked');
                        }
                    });
                }, 3000);
            }
        }
    }
    /*********分享赚活动时调取分享文案**********/
    function getShareInfo (noTitle) {
        if (APP.srcBizType == 1) { //是分享赚活动
            if (APP.isVdianAPP) { //在APP中
                TA.getUserInfo(function (userInfo) {
                    if (userInfo) { //已登录
                        appInfo.isLogin = 1;
                        appInfo.wid = userInfo.wid;
                        if (typeof TA.deviceId === "undefined") {
                            TA.deviceId = userInfo.uuid;
                        }
                        getTaskDetail(userInfo,true, true, noTitle);
                    } else {//未登录
                        appInfo.isLogin = 2;
                        var noUser = {
                            wid: 0,
                            shop_id: 0
                        };
                        getTaskDetail(noUser, true, false, noTitle);
                    }
                });
            } else { //不在APP中
                var userInfo = {
                    wid: APP.wid,
                    shop_id: APP.shop_id
                };
                getTaskDetail(userInfo, false, false, noTitle);
            }
        }
    }
    //请求分享文案信息
    function getTaskDetail (userInfo, isAPP, isLogin, noTitle) {
        $.ajax({
            type: "POST",
            url: '/api/fenxiangzhuan/getTaskShareInfo',
            dataType: 'json',
            data: {
                wid: userInfo.wid || 0,
                shopId: userInfo.shop_id || 0,
                taskId: APP.srcBizId || 0
            },
            success: function (res) {
                if (isAPP) { //在APP中
                    if (res.returnCode == "000000") {
                        var fxzShareInfo = res.responseVo;
                        if (!noTitle) {
                            if (TA.osType == 'ios') {
                                TA.setTitle(fxzShareInfo.taskTitle);//ios需要调用接口设置APP标题栏
                            }
                            $('title').text(fxzShareInfo.taskTitle);
                        }

                        var shopId = userInfo.shop_id || 0,
                        wid = userInfo.wid || 0;
                        var loc = document.location,
                            queryStr = loc.search,
                            locHref = loc.pathname,
                            queryObj = {};
                        if (queryStr.indexOf("?") != -1) {
                            var queries = queryStr.substr(1).split("&");
                            for (var i = 0; i < queries.length; i++) {
                                queryObj[queries[i].split("=")[0]] = queries[i].split("=")[1] || "";
                            }
                            //覆盖或添加需要重置的参数
                            queryObj['vid'] = shopId;
                            queryObj['wid'] = wid;
                            //拼接新的参数
                            var newQueryStr = '';
                            for (var k in queryObj) {
                                newQueryStr += "&" + k + "=" + queryObj[k];
                            }
                            newQueryStr = '?' + newQueryStr.substr(1);
                            if (/\/share$/.test(locHref)) {
                                locHref += encodeURI(newQueryStr);
                            } else {
                                locHref += '/share' + encodeURI(newQueryStr);
                            }
                        }
                        //   
                        var channels = APP.shareChannel.split('_');
                        var fxzObj = {
                            info: {
                                extInfo: [APP.srcBizId]
                            },
                            share: {}
                        };
                        for (var i = 0; i < channels.length && APP.shareChannel; i++) {
                            fxzObj.share[channels[i]] = {
                                title: fxzShareInfo.taskTitle,
                                desc: fxzShareInfo.taskSubTitle,
                                link: locHref,
                                imgUrl: fxzShareInfo.shareLinkImg
                            }
                        }
                        var args = {
                            shareTitle: fxzShareInfo.taskTitle,
                            shareSubTitle: fxzShareInfo.taskSubTitle,
                            shareLink: locHref,
                            shareImageUrl: fxzShareInfo.shareLinkImg,
                            info: {
                                extInfo: [APP.srcBizId]
                            },
                            fxzShareInfo: fxzObj
                        };
                        //APP.taskStatus: 1：任务库存不足；2：用户领取次数用完；3：领取任务失败
                        //4：已经领取该任务；5：任务不存在；6：任务已经被抢光
                        if (APP.taskStatus == 6) {
                            args.info.title = "小萌提示：该任务已被抢光， 您可继续分享，但无分享收入；若有人通过您的分享购买了商品，您将获得返佣收入";
                        } else if (APP.taskStatus == 2) {
                            args.info.title = "小萌提示：您的分享机会已用完， 您可继续分享，但无分享收入；若有人通过您的分享购买了商品，您将获得返佣收入";
                        }
                        args.isLogin = isLogin;
                        permitShare = new shareApp(args);
                        //APP登录后的回调函数
                        window.md.changeUserInfo = function () {
                            TA.getUserInfo(function (userInfo) {
                                if (userInfo) { //已登录
                                    appInfo.isLogin = 1;
                                    location.reload(); //登录后需要重新加载页面
                                }
                            });
                        }
                        permitShare.init().permit();
                        //如果是继续分享过来的，根据状态主动调用分享
                        if (APP.showShare == 1) {
                            TA.toShare(permitShare.shareInfoWrap);
                        }
                    }
                } else {//不在APP中,覆盖一下原来的微信分享文案
                    if (res.returnCode == "000000") {
                        var fxzShareInfo = res.responseVo;
                        APP.wxShare.timeline.title = fxzShareInfo.taskTitle;
                        APP.wxShare.timeline.link = location.href;
                        APP.wxShare.timeline.imgUrl = fxzShareInfo.shareLinkImg;
                        APP.wxShare.appMessage.title = fxzShareInfo.taskTitle;
                        APP.wxShare.appMessage.desc = fxzShareInfo.taskSubTitle;
                        APP.wxShare.appMessage.link = location.href;
                        APP.wxShare.appMessage.imgUrl = fxzShareInfo.shareLinkImg;
                    }
                }
            }
        });
    }
    module.exports = new fxzPoint();
});