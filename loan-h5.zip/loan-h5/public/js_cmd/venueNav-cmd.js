define(function(require, exports, module){
    var $ = require("lib_cmd/zepto-cmd"),
        touchApp = require("./touchApp-cmd");

    var TA = new touchApp();

    function specialWidget (args) {
    	this.special_id = args.special_id;
        this.share_title = args.share_title || "";
        this.share_sub_title = args.share_sub_title || "";
        this.share_image_url = args.share_image_url || "";
        this._shareInfo = args.shareInfo;
    }
    specialWidget.prototype = {
    	init: function () {
    		var self = this;
            //跳到APP首页
            $('#btn_toHome').on('click', function () {
                var appV1 = TA.appVersion;
                    var appV2 = 0;
                    if (appV1) {
                        appV2 = parseInt(appV1.replace(/\./g,''));
                    }
                    if (appV2 >= 450) {
                        TA.gotoMainPage("BuyerHome");
                    } else {
                        TA.gotoMainPage("0");
                    }  
            });
            //切换会场
            $('#btn_navList').on('click', function () {
                if ($('#venue_list').hasClass('on')) {
                    $('#venue_list').removeClass('on');
                } else {
                    $('#venue_list').addClass('on');
                }
            });
            $('.venue-jump').on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var link = $(this).attr('href');
                $('#venue_list').removeClass('on');
                location.href = link;
            });
            //在APP内时有分享按钮
            $('#btn_share').on('click', function () {
                TA.getUserInfo(function (userInfo) {
                    if (!userInfo) {
                        userInfo = {};
                    }
                    if (true) {
                        var shopId = userInfo.shop_id || -1;
                        var title = self.share_title,
                            desc = self.share_sub_title,
                            imgUrl = self.share_image_url;
                        var loc = document.location,
                            locHref = loc.pathname + "/share" + loc.search;
                        var reg = /\?/gi;
                        if (reg.test(locHref)) {
                            locHref = locHref + '&vid=' + shopId;
                        } else {
                            locHref = locHref + '?vid=' + shopId;
                        }
                        //分享信息
                        var shareInfo = {};
                        if (self._shareInfo) {
                            shareInfo = self._shareInfo;
                        } else {
                            shareInfo = {
                            weixin: {
                                title: title,
                                desc: desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            timeline: {
                                title: title,
                                desc: desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            weibo: {
                                title: title,
                                desc: desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            qzone: {
                                title: title,
                                desc: desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            qq: {
                                title: title,
                                desc: desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            qweibo: {
                                title: title,
                                desc: desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            yixin: {
                                title: title,
                                desc: desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            ytimeline: {
                                title: title,
                                desc: desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            renren: {
                                title: title,
                                desc: desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            message: {
                                title: title,
                                desc: '【'+title+'】'+desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            copy: {
                                title: title,
                                desc: '【'+title+'】'+desc,
                                link: locHref,
                                imgUrl: imgUrl
                            },
                            qrcode: {
                                title: title,
                                desc: '扫描二维码可查看详情',
                                link: locHref,
                                imgUrl: imgUrl
                            }
                            };
                        }
                        TA.toShare(shareInfo);
                    }
                });
            });
    	}
    }

    module.exports = specialWidget;
});