define(function(require, exports, module){
    var $ = window._$ = require("lib_cmd/zepto-cmd"),
    	eles= {

    	},
	    gks= 			["action", "page", "platform", "user", "business", "app", "extend"],
	    g_action= 		["eventtype", "elementid", "timestamp"],
	    g_page= 		["pagename", "url", "ua", "uuid"],
	    g_platform= 	["platform", "platformversion", "manufacture", "model", "idfa", "imei"],
	    g_user= 		["yunjieid", "uid", "wid", "cip"],
	    g_business= 	["shopid", "producttype", "gid", "wpgoodsid", "aid", "orderno", "ordertype"],
	    g_app= 			["appversion", "appmarket"],
	    g_extend= 		[];


 /**
	@class Statistics
  */
function Statistics(){
  	var self = this;
  	return self;
}

/**
	@protoype {object}
 */

Statistics.prototype= {
	/**
		@param {req}
		@param {res}
		@param {next}
		@returns this
	  */
	init: function(req, res, next){
		var self = this;
		self.data= {};
		return self;
	},
	/**
		@param {req}
		@param {res}
		@param {next}
		@returns this
	  */
	invoke: function(args, fn){
		// var self= this;
		// self.data= {
		// 	StatType: "mdpath",
		// 	timestamp: +new Date(),
		// 	shopid: -1,
		// 	from_app: 0
		// };
		// self.group(args);
		// var	path= formatData(self.data);
		// self.log(null, null, null, path, null);
		// return self;
		var self= this,
			action=     args.action||{},
	        page=       args.page||{},
	        business=   args.business||{},
	        platform=   args.platform||{},
	        user=       args.user||{},
	        app=        args.app||{},
	        extend=     args.extend||{};
	    try{
	        action=     JSON.stringify(action);
	        page=       JSON.stringify(page);
	        business=   JSON.stringify(business);
	        platform=   JSON.stringify(platform);
	        user=       JSON.stringify(user);
	        app=        JSON.stringify(app);
	        extend=     JSON.stringify(extend);
	    }catch(e){
	        fn(null, {code:1000, message: "参数错误", data: e});
	    }
	    //
		self.data= {
			action:     action,
	        page:       page,
	        business:   business,
	        platform:   platform,
	        user:       user,
	        app:        app,
	        extend:     extend
		};
		var path= formatData(self.data);
		self.log(path, fn);
	},
	log: function(path, fn){
		var self= this;
		$.ajax({
                type: "GET",
                url: APP.urls.statistics+ "?"+ path,
                data: null,
                async:true,
                success: function(res){
                    console.log(res);
                    if (fn) {
                    	fn.call(null, res);
                    }
                },
                dataType: "json"
            });
		// var img= new Image();
		// 	img.src= APP.urls.statistics+ "?"+ path;
		return self;
	},
};

//返回url格式
function formatData(args) {
	var str= "";
	for(var k in args){
		str+= "&"+ k+ "="+ encodeURIComponent(args[k]);
	}
	str= str.substr(1);
	return str;
}

 module.exports= Statistics;

});