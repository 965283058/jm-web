define(function(require, exports, module){
    var $ = window._$ = require("lib_cmd/zepto-cmd"),
    	myDialog = require("lib_cmd/myDialog-cmd"),
        Statistics2= require("js_cmd/statistics2-cmd"),
        thirdValidator = null,
		$eles = {},
		eles = {},
        APP = window.APP || {},
        TA= {},
        tipWidget = window.alert;

    // if(APP.isVdianAPP&& !/^(home)|(detail3)|(goodsSpecialDetail)|(jbhInvite)$/ig.test(APP.pageName)){
    //     require.async("js_cmd/touchApp-cmd", function(_TA){
    //         TA= new _TA();
    //         window.md._setRightBtn= 0;
    //         TA.setRightBtn("0"); //先隐藏分享按钮，需要的时候才显示
    //     });
    // }
    // if(!APP.isLogin&& APP.isVdianAPP){
    //     var appauth= require.async("js_cmd/seller/appauth-cmd", function(){
    //         //
    //     });
    // }
	/**********************************
		页面初始化函数
	**********************************/
	function initPage(){
        // 设置提示信息
        if (APP.message) {
            tipWidget(APP.message);
        }

        if ($eles.dataBody.attr('screen') == 'full') {
            // 全屏模式
            $eles.dataBody.css("min-height", Math.min(window.screen.height, document.body.scrollHeight));
        } else {
            //设置版权信息位置为一屏
            $eles.dataBody.css("min-height", (Math.min(window.screen.height, document.body.scrollHeight) - $eles.dataHeader.height() - $eles.dataFooter.height() - 50 )+"px");
        }
        $eles.dataBody.addClass("on");
        //
        if(APP.isWeixin && ("pay" === APP.pageName || "orderDetail" === APP.pageName)){
            $.ajax({
                type: "POST",
                url: APP.urls.follow,
                data: null,
                async:true,
                success: function(res){
                    if(res && res.Data && res.Data.Subscribe){
                        eles.subscribe = true;
                    }else{
                        eles.subscribe = false;
                    }
                },
                dataType: "json"
            });
        }else{
			eles.subscribe = false;
		}
        //订阅号中不能进行微信支付
        var denyWeixinPay = (/(?:wp=)(\w+)/gi.exec(location.href)||[null, null])[1],
            channelSource = (/(?:udc=)(\w+)/gi.exec(location.href)||[null, null])[1];
        if(denyWeixinPay){
            sessionStorage.setItem("denyWeixinPay", denyWeixinPay);
        }
        if(channelSource){
            sessionStorage.setItem("channelSource", channelSource);
        }

        //2 身份验证，v3.0需要强制登录才能进行相关操作
        //if(true!== APP.isLogin){
        if(true){
            // //2-0 事件绑定
            var el= [];
                //底部导航
                el.push("#btn_shopcart");
                el.push("#btn_center");
                //首页，商品详情页 webim入口
                el.push("#btn_webim");

            $(el.join(", ")).on("click", function(evt){
                var href= evt.currentTarget.href;
                if (evt.currentTarget.id == 'btn_webim') {//客服点击打点
                    var sass = new Statistics2();
                    var sass_args = {
                        action: {
                            elementid: 'contactservice',
                            eventtype: "tap"
                        },
                        page: {
                            pagename: APP.pageName,
                            url: location.href
                        },
                        platform: {
                            from_app: APP.isVdianAPP?"true":'false'
                        }
                    };
                    sass.invoke(sass_args, function(result){
                        console.log(result);
                    });
                }
                // checkLogin(evt, {i:1}, function(evt, args){
                //     setTimeout(function () {
                //         location.href= href;
                //     }, 200);                  
                // });
            });
        }//END IF
        //邀请合伙人链接
        getPartnerInviteUrl();
		//底部导航打点
		footerTabStatistic()
    }
    //
    function checkH5Login(_evt, _args, _fn){
        var _self= this,
            _arguments= arguments,
            scrollTop = document.body.scrollTop,
            $eles= {},
            eles= {
                mode: APP.loginMode|| "h5FastLogin"
            },
            _eles= {
                phoneObj: {},
                vcodeObj: {},
                pvcodeObj: {valid: !APP.login_verifyPicCode},
                pageIdx: 0
            },
            _dialog= null;
        //
        if(true=== APP.isLogin){
            _evt&& _evt.preventDefault();
            return _fn&&_fn.apply(_self, _arguments);
        }else if(!thirdValidator){
            require.async('js_cmd/loan/thirdValidator-cmd', function(tvr){
                thirdValidator= tvr;
            });
        }
        if("h5FastLogin" == eles.mode){
            //
            _dialog= dialog(null, {
                TPL_MASK: '',
                TPL: '<div class="widget_mask" style="z-index: {zIndex2};"></div>\
                    <div class="widget_wrap" style="z-index:{zIndex2};min-height:500px;background:#f5f5f5;" ontouchmove="return false;">\
                        <div class="widget-newLogin-header">\
                            <label>注册/登录萌店<span id="btn_newLogin_close">&nbsp;</span></label>\
                        </div>\
                        <div class="widget_newLogin_body">\
                            <form id="form_widget_newLogin" action="javascript:void(0);" method="POST">\
                                <ul>\
                                    <li id="widget_newLogin_step1" class="widget-newLogin-step1 on">\
                                        <div>\
                                            <input type="tel" maxlength="11" name="phoneNo" placeholder="请输入手机号" autocomplete="off" autofocus="autofocus" />\
                                        </div>\
                                        <div>\
                                            <a href="javascript:void(0);" id="widget_newLogin_btn_next" class="btn">下一步</a>\
                                        </div>\
                                    </li>\
                                    <li id="widget_newLogin_step2" class="widget-newLogin-step2">\
                                        <div class="tbox">\
                                            <div>\
                                                <input type="tel" maxlength="4" name="vcode" placeholder="请输入收到的验证码" autocomplete="off" />\
                                            </div>\
                                            <div>\
                                                <a href="javascript:void(0);" id="btn_getVcode" class="btn-getVcode" >获取验证码</a>\
                                            </div>\
                                        </div>\
                                        <div>\
                                            <a href="javascript:void(0);" id="widget_newLogin_btn_login" class="btn">登录</a>\
                                        </div>\
                                    </li>\
                                </ul>\
                            </form>\
                        </div>\
                        <div class="widget-newLogin-footer">\
                            <div style="z-index:{zIndex2};">&copy;2015上海微盟企业发展有限公司</div>\
                        </div>\
                    </div>',
                id: "widget_newLogin",
                type: "newLogin",
                classes: "widget-newLogin"
            }).open();
        }
        //
        $eles= {
            form_widget_newLogin: $("#form_widget_newLogin"),
            widget_newLogin_step1: $("#widget_newLogin_step1"),
            widget_newLogin_step2: $("#widget_newLogin_step2"),
            btn_getVcode: $("#btn_getVcode"),
            btn_newLogin_close: $("#btn_newLogin_close"),
            widget_newLogin_btn_next: $("#widget_newLogin_btn_next"),
            widget_newLogin_btn_login: $("#widget_newLogin_btn_login")
        }
        // 手机号输入
        $eles.form_widget_newLogin[0].phoneNo.addEventListener("input", function(evt){
            eles.phoneObj= $.trim(this.value);
        });
        //验证码输入
        $eles.form_widget_newLogin[0].vcode.addEventListener("input", function(evt){
            eles.vcodeObj= $.trim(this.value);
        });
        //
        if(APP.login_verifyPicCode){
            $eles.form_widget_newLogin[0].verifyPicCode.addEventListener("input", function(evt){
                eles.pvcodeObj= $.trim(this.value);
            });
        }
        // 下一步按钮点击
        $eles.widget_newLogin_btn_next.on("click", function(evt){
            if(eles.phoneObj.valid&& eles.pvcodeObj.valid ){
                if(APP.login_verifyPicCode){
                    APP.verifyPicCode(fn_sendVcode);
                    eles.pvcodeObj= "";
                }else{
                    fn_sendVcode();
                }
            }
        });
        // 验证码发送按钮
        $eles.btn_getVcode.on("click", function(evt){
            if(this.classList.contains("on") ){
                fn_sendVcode();
                this.classList.remove("on");
            }
        });
        // 登录按钮点击
        $eles.widget_newLogin_btn_login.on("click", function(evt){
            if(eles.vcodeObj.valid ){
                fn_doLogin();
            }
        });
        //
        $eles.btn_newLogin_close.on("click", function(evt){
            eles.status= 0;
            _dialog.destroy();
        });
        //2-2 发送验证码
        function fn_sendVcode(validate, passCode){
            var args= {
                mobile: eles.phoneObj.value,
                mode: eles.mode
            };
            if(validate){
                if("string"=== typeof validate){
                    //i.md.cn
                    args.data= {
                        ticket: validate,
                        csnonce: APP.newLogin&& APP.newLogin.csnonce
                    };
                }else{
                    args.validate= validate;
                    args.passCode= passCode;
                }
            }
            var l= loading();
            $.ajax({
                type: "POST",
                url: APP.urls.verify,
                //cache: false,
                data: args,
                async:true,
                success: function(result){
                    l.destroy();
                    if(0== result.code){
                        startTick(59);
                        eles.pageIdx= 2;
                    }else if("200002"== result.code){
                        //风险
                        var passCode= result.data&& result.data.url;
                        passCode= passCode&& passCode.match(/\d+$/)[0];
                        APP.thirdValidation= result.thirdValidation;
                        thirdValidator.showVerify(fn_sendVcode , passCode);
                    }else{
                        alert(result.message);
                        $eles.btn_getVcode.addClass("on");
                    }
                },
                dataType: "json"
            });
            //
            function startTick(seconds){
                var self= this, callee= arguments.callee;
                $eles.btn_getVcode.html(seconds+ "秒后重发");
                if(0=== seconds){
                    $eles.btn_getVcode.html("重发验证码").addClass("on");
                    timer= null;
                }else{
                    timer= setTimeout(function(){
                        callee(--seconds);
                    }, 1000);
                }
            }
            return {
                onend: function(){
                    console.log("end");
                }
            };
        }
        //2-3 登录
        function fn_doLogin(){
            var l= loading(),
                args= {
                    verifycode: eles.vcodeObj.value,
                    mobile: eles.phoneObj.value,
                    mode: eles.mode
                };
            $.ajax({
                type: "POST",
                url: APP.urls.login,
                //cache: false,
                data: args,
                async:true,
                success: function(result){
                    l.destroy();
                    if(0== result.code){
                        APP.isLogin= true;
                        APP.isSelfShop= result.data.isSelfShop;
                        if("h5FastLogin"=== eles.mode){
                            _dialog.destroy();
                            eles.status= 0;
                        }
                        [].splice.call(_arguments, 2, 0, result.data);
                        _arguments[3].apply(null, _arguments);
                    }else{
                        alert(result.message);
                    }
                },
                dataType: "json"
            });
        }
        //
        Object.defineProperties(eles, {
            phoneObj: {
                get: function(){
                    return _eles.phoneObj;
                },
                set: function(v){
                    var phoneObj= {
                        value: v,
                        valid: /^\d{11}$/.test(v)
                    };
                    $eles.widget_newLogin_btn_next[phoneObj.valid&& eles.pvcodeObj.valid? "addClass": "removeClass"]("on");
                    _eles.phoneObj= phoneObj;
                }
            },
            vcodeObj: {
                get: function(){
                    return _eles.vcodeObj;
                },
                set: function(v){
                    var vcodeObj= {
                        value: v,
                        valid: /^\d{4}$/.test(v)
                    };
                    $eles.widget_newLogin_btn_login[vcodeObj.valid? "addClass": "removeClass"]("on");
                    _eles.vcodeObj= vcodeObj;
                }
            },
             pvcodeObj: {
                get: function(){
                    return _eles.pvcodeObj;
                },
                set: function(v){
                    var pvcodeObj= {
                        value: v,
                        valid: /^\w{4,8}$/.test(v)
                    };
                    $eles.widget_newLogin_btn_next[pvcodeObj.valid&& eles.phoneObj.valid? "addClass": "removeClass"]("on");
                    _eles.pvcodeObj= pvcodeObj;
                }
            },
            pageIdx: {
                get: function(){
                    return _eles.pageIdx;
                },
                set: function(v){
                    $eles.widget_newLogin_step1[1=== v? "addClass": "removeClass"]("on");
                    $eles.widget_newLogin_step2[2=== v? "addClass": "removeClass"]("on");
                    _eles.pageIdx= v;
                }
            },
            status: {
                set: function(v){
                    document.body.classList[v? "add": "remove"]("newLogin");
                    !v&& window.scrollTo(0, scrollTop);
                }
            }
        });
        eles.status= 1;
        return false;
    }
    //
    function checkAppLogin(_evt, _args, _fn){
        var _self= this,
            _arguments= arguments;
        //
        if(true=== APP.isLogin){
            _evt&& _evt.preventDefault();
            return _fn&&_fn.apply(_self, _arguments);
        }
        require.async('js_cmd/touchApp-cmd', function(touchApp){
            var TA= new touchApp();
            window.md.changeUserInfo= function () {
                TA.getUserInfo(function (userInfo) {
                    if(userInfo){
                        appLogin(userInfo, _fn);
                    }else{
                        _fn();
                    }
                    window.md.changeUserInfo=function(){};
                });
            }
            
            //
            var args = {
                destClassName: TA.NativeView.LoginPage
            };
            TA.jump(args);
        });
    }

    function appLogin(userInfo, _fn){
        var l= loading(),
            args= {
                mobile: userInfo.mobile,
                uuid:   userInfo.uuid,
                shop_id: userInfo.shop_id,
                wid:    userInfo.wid,
                token:  userInfo.token
            };
        $.ajax({
            type: "POST",
            url: "/api/user/applogin",//APP.urls.applogin,
            cache: false,
            data: args,
            async:true,
            success: function(result){
                l.destroy();
                if(0=== result.code){
                    APP.isLogin= true;
                }else{
                    alert(result.message);
                }
                _fn&&_fn();
            },
            dataType: "json"
        });
    }
            
    //图片懒加载
    var lazyLoad= APP.lazyLoad= (function(){
        function lazyLoad(){
            function lazyLoadImage(el){
                var lazyImg=el.querySelectorAll('*[data-imgsrc]');
                if(!lazyImg.length){
                    return false;
                }
                for(var i=0;i<lazyImg.length;i++){
                    var clientRect= lazyImg[i].getBoundingClientRect();
                   if(clientRect.top<window.innerHeight*3/2&& clientRect.bottom>-window.innerHeight/2&& clientRect.left>-window.innerWidth/2&& clientRect.right<window.innerWidth*3/2){
                        if(lazyImg[i].tagName=='IMG'&& lazyImg[i].src.indexOf("data")!==0 ){
                            lazyImg[i].src=lazyImg[i].dataset.imgsrc;
                        }
                        else{
                            lazyImg[i].style.backgroundImage='url('+lazyImg[i].dataset.imgsrc+')';
                        }
                        lazyImg[i].removeAttribute('data-imgsrc');
                    }
                }
                return true;
            }
            $(window).on('scroll.lazyLoad',function(){
                !lazyLoadImage(document)&&$(this).off('scroll.lazyLoad')
            });
            lazyLoadImage(document);
        }
        return lazyLoad;
    })();
	/**********************************
		页面初始化函数
	**********************************/
	$(function(){
		//页面操作所需元素对象
		$eles = {
			dataBody: $('*[data-role="body"]'),
			dataHeader: $('*[data-role="header"]'),
            dataFooter: $('*[data-role="footer"]'),
            follow_tip: $("#follow_tip"),
            btn_partner: $("#btn_partner")
		};
		//
		eles = (function(){
			function Eles(){
                var subscribe = false;
                // 返回顶部
                if (APP.goTop) {
                    createGoTopBtn();
                }
                // 加载提示
                this.loading = createLoading;
                this.finish = createFinish;

                Object.defineProperty(this, "subscribe", {
                    get: function(){
                        return subscribe;
                    },
                    set: function(v){
                        subscribe = v;
                        console.log(subscribe);
                        $eles.follow_tip[subscribe?"removeClass":"addClass"]("on");
                    }
                });
			}
			return new Eles();
		})();
		//
		initPage();
	});

    /**
     * 返回顶部按钮(动态创建)
     */
    function createGoTopBtn() {
        var gtObj = $('#J_GoTop'),
            html = '';
        if (gtObj.length) {
            return;
        }
        //若有客服按钮，则回到顶部按钮上移
        if($('.consult')){
            html = '<div id="'+ gtObj.selector.slice(1)+'" class="widget-gotop has-consult"><a href="javascript:;" class="icon-gotop">顶部</a></div>';
        }
        else{
            html = '<div id="'+ gtObj.selector.slice(1)+'" class="widget-gotop"><a href="javascript:;" class="icon-gotop">顶部</a></div>';
        }   
        gtObj = $(html).appendTo(document.body);
        

        // 绑定事件
        var _bindUI = function () {
            // 点击
            gtObj.on("click", 'a', function () {
               window.scrollTo(0,0);
            });

            // 滚动
            $(window).on("scroll", function() {
                var scrollTop = document.body.scrollTop,
                    winH =  $(window).height();
                if (scrollTop > winH) {
                    gtObj.show();
                } else {
                    gtObj.hide();
                }
            });
        }();
    }

    /**
     * 加载提示(动态创建)
     * @param container 提示父容器，默认添加到body中
     */
    function createLoading(container) {
        var loadingObj = $('#J_Loading'),
            html = '';
        if (loadingObj.length) {
            return;
        }

        html = '<div id="' + loadingObj.selector.slice(1) + '" class="widget-loading"><i class="icon-loading"></i>加载中...</div>';
        $(html).appendTo($(container || document.body));
    }

    /**
     * 加载完毕提示(动态创建)
     *
     */
    function createFinish (container) {
        var loadFinish = $('#J_finish'),
            html = '';
        if (loadFinish.length) {
            return;
        }

        html = '<div id="' + loadFinish.selector.slice(1) + '" class="widget-finish">已加载全部</div>';
        $(html).appendTo($(container || document.body));
    }
    /**
     * 邀请合伙人
     *
     */
     function getPartnerInviteUrl(){
        if($eles.btn_partner.length){
            APP.urls.partnerInvite_url= "/api/util/partnerInvite";
            function _getPartnerInviteUrl(){
                $.ajax({
                    type: "GET",
                    url: APP.urls.partnerInvite_url,
                    //cache: false,
                    data: null,
                    async:true,
                    success: function(result){
                        if(0== result.code){
                            var p_href= $eles.btn_partner.attr("href");
                            $eles.btn_partner.attr("href", p_href+ "&"+ result.data);
                        }else{
                            console.log(result.message);
                        }
                    },
                    dataType: "json"
                });
            }
            _getPartnerInviteUrl();
        }
     }
	/**
	 * 底部导航打点
	 *
	 */
	function footerTabStatistic(){
		if(document.querySelector('.pintuan-footer')){
			var sass = new Statistics2()
			$('.pintuan-footer a').each(function(i){
				$(this).on('click',function(){
					if(i){
						sass.invoke({
							action: {
								elementid: [,"minegroup",'mine','xiazai'][i],
								eventtype: "tap"
							},
							page: {
								pagename: APP.pageName,
								url: location.href
							}
						})
					}
				})
			})
		}
	}

	/**********************************
		暴露相应对象
	**********************************/
	module.exports = {
		$eles: $eles,
		eles: eles,
        checkH5Login: checkH5Login,
        checkAppLogin: checkAppLogin,
        checkLogin: APP.isVdianAPP? checkAppLogin: checkH5Login,
        Statistics2: Statistics2,
        lazyLoad: lazyLoad,
        appLogin: appLogin
	}
});


