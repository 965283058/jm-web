define(function(require, exports, module){
    var $ = window._$ = require("lib_cmd/zepto-cmd"),
        $eles = {},
        eles = {};

    /**********************************
        页面初始化函数
    **********************************/
    function initPage(){
        //获取购物车信息
            $.ajax({
                type: "POST",
                url: '/api/shopcart/action',
                //cache: false,
                data: {},
                async:true,
                success: function(res){
                    if(0 == res.code){
                        eles.shopcartList = res.data;
                        eles.count= {
                            //以下是新的3.1数量显示方式
                            valid:res.data.validGoodsNum || 0,
                            invalid:res.data.invalidGoodsNum || 0
                        };
                    }else{
                        eles.shopcartList = [];
                    }
                },
                dataType: "json"
            });
    }
    
    /**********************************
        页面初始化函数
    **********************************/
    $(function(){
        //页面操作所需元素对象
        $eles = {
            btn_shopcart_span: $("#btn_shopcart").length ? $("#btn_shopcart span") : $('#link_shopcart')
        }
        eles = (function(){
            function Eles(){
                //收藏状态
                var shopcartList = null;
                var count= null;
                //
                Object.defineProperty(this, "shopcartList", {
                    get: function(){
                        return shopcartList;
                    },
                    set: function(v){
                        shopcartList = v;
                    }
                });
                Object.defineProperty(this, "count", {
                    get: function(){
                        return count;
                    },
                    set: function(v){
                        count = v;
                        $eles.btn_shopcart_span.attr("data-count", count.valid);
                    }
                });
            }
            return new Eles();
        })();
        initPage();
    });

    module.exports = {
        eles: eles
    }
});