define(function (require, exports, module) {
	var $ = require("lib_cmd/zepto-cmd"),
		Statistics2= require("js_cmd/statistics2-cmd"),
        Vue = require('lib_cmd/vue-cmd');
    
	if(APP.isVdianAPP){Vue.component('child-nav',{});return}
	var sass = new Statistics2();

	Vue.component('child-nav', {
		data: function () {
			return {
				redPoint: false
			};
		},
		template: "#component_nav",
		methods: {
			loadCart: function () {
				var self = this;
				$.ajax({
                	type: "POST",
                	url: '/api/shopcart/action',
                	data: {},
                	async:true,
                	success: function(res){
                    	if(0 == res.code && res.data){
                    		self.redPoint = res.data.validGoodsNum > 0 ? true : false;
                    	}
                	},
                	dataType: "json"
            	});
			},
			openNav: function () {
				if (document.getElementById('widget_nav').classList.contains('close')) { //此时是点击打开导航
					document.getElementById('widget_nav').classList.remove('close')
					sass.invoke({
            			action: {
                			elementid: 'shortcut',
                			eventtype: "tap"
            			},
            			page: {
                			pagename: APP.pageName,
                			url: location.href
            			}
        			}, function(result){
        				console.log(result);
     				});
				}
			},
			navJump: function (eid, href) {
				sass.invoke({
            		action: {
                		elementid: eid,
                		eventtype: "tap"
            		},
            		page: {
                		pagename: APP.pageName,
                		url: location.href
            		}
        		}, function(result){
        			console.log(result);
            		setTimeout(function () {
            			location.href = href;
            		},200);
        		});
			}
		},
		created: function () {
			this.loadCart();
		}
	});
});