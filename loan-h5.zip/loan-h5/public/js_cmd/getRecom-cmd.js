define(function (require, exports, module) {
    var $ = require("lib_cmd/zepto-cmd"),
        iTemplate= require("lib_cmd/iTemplate-cmd"),
        //dialog= require("lib_cmd/myDialog-cmd"),
        Statistics2= require("js_cmd/statistics2-cmd"),
        userInfo= null,
        TA = null,
        $eles= {},
        eles= {
            scenarios: /(?:scenarios=)2/i.test(location.href)? 2: 1
        };

    if(APP.isVdianAPP){
        require.async("js_cmd/touchApp-cmd", function(ta){
            TA= new ta();
            TA.getUserInfo(function (ui) {
                userInfo= ui;
            });
            jump= function(wp_goods_id, sellType){
                var aid = wp_goods_id.split("_")[0];
                var args = {
                    destClassName: TA.NativeView.GoodsDetail,
                    segue: {
                        wp_goods_id: wp_goods_id,
                        aid: aid,
                        goods:{
                            sellType: sellType,
                            wp_goods_id: wp_goods_id
                        }
                        //topic: "pintuan"
                    }
                };
                fn_stc(wp_goods_id, function(){
                    TA.jump(args);
                });
            }
        });
    }
    //商品点击打点
    function fn_stc(wp_goods_id, fn){
        if(fn){
            setTimeout(function(){
                fn();
            }, 300);
        }
        var ids= wp_goods_id.split("_");
        new Statistics2().invoke({
            action:     {
                elementid: "recommend",
                eventtype: "tap"
            },
            page:       {
                pagename: APP.pageName,
                url: location.href,
                uuid: userInfo&& userInfo.uuid
            },
            business:   {
                aid: ids[0],
                gid: 0,
                wpgoodsid: wp_goods_id
            },
            platform:   {

            },
            user:       {},
            app:        {},
            extend:     {
                abtestTagrecm: 1,
                recom_list_id: eles.recom_list_id,
                strategy_id: eles.strategy_id
            }
        }, function(result){
            console.log(result);
        });
    }

    function jump(wp_goods_id, sellType){
        fn_stc(wp_goods_id, function(){
            var ids= wp_goods_id.split("_");
            var goodsUrl= "/buyer/goods/detail?vid=0&aid="+ids[0]+"&gid="+ids[1]+"&iswp=true&scenarios="+ (parseInt(sellType)||1);
            location.href = goodsUrl;
        });
    }

    //
    function initData(args, fn){
        if (!args.data.scenarios) {
            args.data.scenarios= eles.scenarios;
        }  
        if( APP.isVdianAPP
            &&("goodsSpecialDetail"=== APP.pageName)
            &&("android"=== TA.appType.toLowerCase() )
            &&(parseFloat(TA.appVersion)<3.3 )
        ){
            //版本过低
            return;
        }
        if(!args.data.prodList|| !/[\d-]+/g.test(args.data.prodList[0])){
            return;
        }
        args.data.wid= userInfo&&userInfo.wid?userInfo.wid:"";
         var TPL_PRICE= '',
            TPL = '';
            if(APP.isVdianAPP&&(2!== eles.scenarios) ){
                //app分销
                TPL_PRICE = '<div>\
                                <p class="r_p1">佣金<span>￥{commission_1}.<span style="font-size:12px;">{commission_2}</span></span></p>\
                                <p class="r_p2"><span style="margin:0;">￥{sale_price1}.{sale_price2}</span> <del>￥{market_price}</del></p>\
                            </div>';
            }else{
                 TPL_PRICE = ' <div>\
                                <p class="r_p1">￥<span>{sale_price1}</span>.{sale_price2}</del></p>\
                                <p class="r_p2"><del>￥{market_price}</span></p>\
                            </div>';
            }
            //
            TPL = '<li>\
                <a href="javascript:;" class="goods-item" data-id="{wp_goods_id}" data-sellType="{sellType}" data-idx="{idx}">\
                    <figure>\
                        <div>\
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NkAAIAAAoAAggA9GkAAAAASUVORK5CYII=" style="background-image: url({index_image})">\
                        </div>\
                    </figure>\
                    <figcaption>\
                        <div>\
                            <p>{title}</p>\
                        </div>'+
                        TPL_PRICE + 
                    '</figcaption>\
                </a>\
            </li>';
            
            $.ajax({
                type: "POST",
                url: APP.urls.getRecommendAll,
                dataType: 'json',
                data: args.data,
                success: function (res) {
                    if (res.code||res.code==undefined) return;
                    res.data.goods_list= res.data.goods_list|| res.data.goods_lists;
                    if (res.code == 0&& res.data.goods_list.length>0) {
                        eles.recom_list_id= res.data.recom_list_id;
                        eles.strategy_id= res.data.strategy_id;
                        //排序
                        var _goods_ids= res.data.goods_ids, _goods_list= [];
                        res.data.goods_list.forEach(function(v, k){
                            for(var i=0, ci; ci= _goods_ids[i]; i++){
                                if(v.wp_goods_id=== ci[1]){
                                    v.idx= ci[0];
                                    break;
                                }
                            }
                            if (v.wp_is_del==false) {
                                _goods_list.push(v);
                            }
                        });
                        _goods_list= _goods_list.sort(function(a1, a2){
                            return a1.idx>a2.idx? 1: -1;
                        });
                        //
                        var html = iTemplate.makeList(TPL, _goods_list, function (k, v, i) {
                            var sale_price_all = parseFloat(v.sale_price).toFixed(2).toString().split('.'),
                                commission_all= parseFloat(v.weike_commission).toFixed(2).toString().split('.');
                            return {
                                sale_price1: sale_price_all[0],
                                sale_price2: sale_price_all[1],
                                commission_1: commission_all[0],
                                commission_2: commission_all[1],
                                highMarketPrice: parseFloat(v.highMarketPrice).toFixed(2),
                                commission: (v.weike_commission || 0).toFixed(2),
                                commisionOn: APP.isVdianAPP&&(2!== eles.scenarios)? "": "hidden" //萌店app并且非直销
                            }
                        }),
                        $html= $(html);
                        fn(null, $html);
                        $html.on("click", function(evt){
                            evt.preventDefault();
                            var et= evt.target;
                            jump(et.dataset.id, eles.scenarios||et.dataset.sellType);
                        });
                    }else {
                        fn(res);
                    }
                    //$('.widget-loading').hide();
                },
                error: function () {
                    fn(new Error("unknow error"));
                    //$('.widget-loading').hide();
                }
            });
    }
    //
    module.exports= {
        initData: function(args, fn){
            setTimeout(function(){
                initData(args, fn);
            }, 100);
        }
    }
});
