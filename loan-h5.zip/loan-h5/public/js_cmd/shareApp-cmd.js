/******允许APP对当前页面进行分享*********/
define(function (require, exports, module) {
	var $ = require("lib_cmd/zepto-cmd"),
		touchApp = require("./touchApp-cmd");

	var TA = new touchApp();

	function permitShare (args) {
		if (!window.md) {
			console.log('no app no share');
			return;
		}
		this.shareTitle = args.shareTitle || "";
		this.shareSubTitle = args.shareSubTitle || "";
		this.shareLink = args.shareLink || "";
		this.shareImageUrl = args.shareImageUrl || "";
        this.info = args.info || {};
        this.shareInfo = args.shareInfo; //当各渠道分享信息不同时用此项
        this.shareInfoWrap = {};//由于迭代，后面shareInfo将放到shareInfoWrap中再传给APP
        this.shareMethod= 2== args.shareMethod? "toShareInvite": "toShare"; //只是二维码分享图标的区别
	    this.fxzShareInfo = args.fxzShareInfo; //分享赚时的分享信息
        this.isLogin = args.isLogin || false;//APP是否登录
    }
	permitShare.prototype = {
		//配置分享信息
		init: function () {
			var self = this;
            if (!self.shareInfo) {
			    self.shareInfo = {
				    weixin: {
                	   title: self.shareTitle,
                	   desc: self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
            	   },
            	   timeline: {
            		   title: self.shareTitle,
                	   desc: self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
            	   },
            	   weibo: {
                        title: self.shareTitle,
                	   desc: self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
                    },
                    qzone: {
                	   title: self.shareTitle,
                	   desc: self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
                    },
                    qq: {
                	   title: self.shareTitle,
                	   desc: self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
                    },
                    qweibo: {
                	   title: self.shareTitle,
                	   desc: self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
                    },
                    yixin: {
                	   title: self.shareTitle,
                	   desc: self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
                    },
                    ytimeline: {
                	   title: self.shareTitle,
                	   desc: self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
                    },
                    renren: {
                	   title: self.shareTitle,
                	   desc: self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
                    },
                    message: {
                	   title: self.shareTitle,
                	   desc: '【'+self.shareTitle+'】' + self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
                    },
                    copy: {
                	   title: self.shareTitle,
                	   desc: '【'+self.shareTitle+'】' + self.shareSubTitle,
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl
                    },
                    qrcode: {
                	   title: self.shareTitle,
                	   desc: '扫描二维码可查看详情',
                	   link: self.shareLink,
                	   imgUrl: self.shareImageUrl         
                    },
                    md: {
                       title: self.shareTitle,
                       desc: self.shareSubTitle,
                       link: self.shareLink,
                       imgUrl: self.shareImageUrl 
                    }
			    }
            };
            self.shareInfoWrap = {
                info: self.info,
                share: self.shareInfo
            };
			return self;
		},
		permit: function () {
			if (!window.md) {
				return;
			}
			var self = this;
			window.md.onShare = function (btn) {
                if (btn >= 4 && btn < 8) {//分享赚分享按钮
                    if (self.isLogin) { //已登录
                        TA[self.shareMethod](self.fxzShareInfo);
                    } else {//未登录需要跳登录页
                        var loginArgs = {
                            destClassName: TA.NativeView.LoginPage
                        };
                        TA.jump(loginArgs);
                    }
                } else {
				    TA[self.shareMethod](self.shareInfoWrap);
                }
			}
		}
	}

	module.exports = permitShare;
});