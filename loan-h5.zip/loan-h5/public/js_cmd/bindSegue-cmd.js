define(function(require,exports,module){
	var $=require("lib_cmd/zepto-cmd")
	var touchApp=require("js_cmd/touchApp-cmd")
	var PopPage=require("js_cmd/PopPage-cmd")
	var pp
	var TA = new touchApp()
	var bindSegue={
		bind:function(el,segues){
			if(!segues)return;
			segues.dest=segues.dest||segues.destClassName
			$(el).each(function(i){
				var segue=segues[i]||segues
				if(segue.tips){
					if(!document.getElementById('notice')){
						pp=new PopPage('notice')
						pp.addWindow({
							id:0,
							html:'\
								<div>\
									<h6></h6>\
									<p></p>\
								</div>\
								<footer>知道了</footer>\
							',
							action:function(win){
								win.querySelector('footer').addEventListener('click',function(){
									pp.close()
								})
							}
						})
					}
					this['data-segue-tip']=segue
					$(this).on('click',bindSegue.tipSegue)
					return
				}
				if(APP.isVdianAPP){
					this['data-segue']=segue
					$(this).on('click',bindSegue.jumpSegue)
					return
				}
				switch(segue.dest.split('|')[+('android'!==TA.osType)]){
					case TA.NativeView.WebView:
						this['data-segue-link']=segue.segue.web.url
						break
					case TA.NativeView.GoodsDetail:
						this['data-segue-link']='/buyer/goods/detail?aid='+segue.segue.aid+'&gid='+(segue.segue.wp_goods_id||segue.segue.goods.wp_goods_id).split("_")[1]+ '&scenarios='+segue.segue.goods.sellType+'&topic='+segue.segue.goods.topic+'&activityId='+segue.segue.pid+'&iswp=true'
						break
					case TA.NativeView.VShopDetail:
						this['data-segue-link']='/buyer/vshop/index?aid='+segue.segue.aid
				}
				if(this['data-segue-link']){
					$(this).on('click',bindSegue.linkSegue)
				}
			})
		},
		tipSegue:function(){
			document.querySelector('#notice h6').innerHTML=this['data-segue-tip'].tips.dialog&&this['data-segue-tip'].tips.dialog.title
			document.querySelector('#notice p').innerHTML=this['data-segue-tip'].tips.dialog.content
			pp.pop(false,true)
		},
		jumpSegue:function(){
			var self= this;
			setTimeout(function(){
				TA.jump(self['data-segue']);
			}, 150);
		},
		linkSegue:function(){
			var self= this;
			setTimeout(function(){
				location.href=self['data-segue-link']
			}, 150);
		}
	}
	module.exports=bindSegue
})