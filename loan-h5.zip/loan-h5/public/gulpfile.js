"use strict";
var gulp = require('gulp'); 
var rename= require('gulp-rename');
//var uglify= require('gulp-uglify');
//var cmdMerger= require('gulp-cmd-merger');  
var rev= require('gulp-rev');
var cssmin= require("gulp-minify-css");
var revCollector= require('gulp-rev-collector');
var mdJsBuild = require("./md-js-build/index.js");
var through = require('through2');
require('gulp-awaitable-tasks')(gulp);
var clean= require("gulp-clean");
var fs= require("fs");
var path= require("path");

//fix 4 ext
function trimExt(){
	return through.obj(function(file, enc, callback ){
		var ctx= file.contents.toString('utf8');
		ctx= ctx.replace(/\.(js)/gi, "");
		file.contents= new Buffer(ctx);
		callback(null, file);
	});
}
//
var domain= "http://stc.vd.cn";
	domain= "";
//资源匹配，并替换，对于config.baseUrl 的逻辑需要注意
var reg_resFile= new RegExp( (domain.length?"(?:config\\.baseUrl\\s*\\+\\s*)?":"")+ "(['\"\\(])([\\.\\/\\w_-]*(css|imgs|res|lib)\\/)(([\\w\\/]*)-\\w{10}\\.(css|js|svg|jpg|jpeg|png|gif))", "gi");

function addDomain(){
	return through.obj(function(file, enc, callback ){
		var ctx= file.contents.toString('utf8');
		ctx= ctx.replace(reg_resFile, function($1, $2, $3, $4, $5){
			return `${$2}${domain}/${$4}/${$5}`;
		});
		file.contents= new Buffer(ctx);
		callback(null, file);
	});
}
//
function reVersion(){
	return through.obj(function(file, enc, callback){
		var ctx= file.contents.toString("utf-8");
			ctx= ctx.replace(/'(views|public)(-c)?'\)/g, function($1, $2, $3){
				return `'${$2}-c')`;
			});
		file.contents= new Buffer(ctx);
		callback(null, file);
	});
}

var mdMerger= (function(){
	var cmds= {},
		info= "/**\n *\t@author: eric\n *\t@email: eric@weimob.com, 478857585@qq.com\n *\t@date: "+(new Date()) +"\n *\t@version: 306\n */\n";
	function collect(){
		return through.obj(function(file, enc, callback){
			if(/(-417\.js$)/.test(file.path) ){
				return callback(null, file);
			}
			var ctx= file.contents.toString("utf-8");
			var dep= {},
				subdep= {};
			var seaIds= ctx.match(/(js|lib)_cmd\/[\w-\/_\.]+(?="(,|\]))/gi);
			if(seaIds&& seaIds[0]&& !(seaIds[0] in cmds) ){
				cmds[seaIds[0] ]= {
					deps: seaIds.slice(1),
					seaId: seaIds[0],
					ctx: ctx
				};
			}
			callback(null, file);
		});
	}
	function merge(){
		return through.obj(function(file, enc, callback){
			var ctx= file.contents.toString("utf-8");
			var allids= [],
				allcmds= [info, ctx];
			function mg(dep){
				var subSeaIds= dep.deps,
					subSeaId= null,
					i=0;
				while(subSeaId= subSeaIds[i++] ){
					if(allids.indexOf(subSeaId)>-1|| !(subSeaId in cmds) ){

					}else{
						allids.push(subSeaId);
						if(!/(lib_cmd)/.test(subSeaId)){
						//if(!/(lib_cmd)|(main-cmd)|(shareApp-cmd)|(statistics2-cmd)|(touchApp-cmd)|(thirdValidator-cmd)|(appauth-cmd)/.test(subSeaId)){
							allcmds.push(cmds[subSeaId].ctx );
						}
						mg(cmds[subSeaId] );
					}
				};
			}
			mg(cmds[ctx.match(/(js|lib)_cmd\/[\w-\/_\.]+/gi)[0] ] );
			var ctx2= allcmds.join('');
			file.contents= new Buffer(ctx2);
			callback(null, file);
		});
	}

	return {
		collect: collect,
		merge: merge
	};
})();

// step1 css, imgs等非cmdjs文件md5命名, 并替换到cmdjs, views-c
gulp.task('step1', ['step0'], function*(){
	console.log("[imgs,css,font等资源md5]");
	// 首先不依赖其他资源的文件md5
	yield gulp.src(['./imgs/**/*', './res/**/*', './lib/**/*'], { base: './'} )
		.pipe(gulp.dest('../public-c/') )
        .pipe(rev() )
        .pipe(gulp.dest('../public-c/') )
        .pipe(rev.manifest() )
        //.pipe(trimExt() )
        .pipe(gulp.dest('../public-c/rev-1') );

    // 资源替换到css 并对css做md5
    console.log("[imgs,css,font等资源的引用路径替换]");
    yield gulp.src(['../public-c/rev-1/rev-manifest.json', './css/**/*.css'],  { base: './'})
     	.pipe(revCollector() )
        .pipe(addDomain() )
        .pipe(gulp.dest('../public-c/') )
        .pipe(rev() )
        .pipe(gulp.dest('../public-c/') )
        .pipe(rev.manifest() )
        //.pipe(trimExt() )
        .pipe(gulp.dest('../public-c/rev-3') );

    // 资源替换到cmdjs
    console.log("[修改js对css，imgs，font的引用]");
    yield gulp.src(['../public-c/**/rev-manifest.json', './js_cmd/**/*.js', './lib_cmd/**/*.js'], { base: './'} )
        .pipe(revCollector() )
        .pipe(addDomain() )
        .pipe(mdJsBuild.cmdFormat() )
        .pipe(rev() )
        .pipe(rename({ suffix: '-417' }) )
        .pipe(gulp.dest('./build') )
        .pipe(rename(function(parsedPath){
			parsedPath.basename= parsedPath.basename.replace("-417", "");
		}) )
        .pipe(mdJsBuild.processUglify() )
        .pipe(gulp.dest('./build') )
        .pipe(rev.manifest() )
        .pipe(trimExt() )
        .pipe(gulp.dest('../public-c/rev-2') );

    // 资源替换到ejs
    console.log("[修改ejs对css，imgs，font的引用]");
    yield gulp.src(['../public-c/rev-1/rev-manifest.json', '../public-c/rev-3/rev-manifest.json', '../views/**/*.ejs'] )
        .pipe(revCollector() )
        .pipe(addDomain() )
        .pipe(gulp.dest('../views-c') );
});


//step2 js
gulp.task('step2', ['step1'], function*(){
	 // 资源替换到cmdjs
	console.log("[修改js对模块的引用路径]");
    yield gulp.src(['../public-c/rev-2/rev-manifest.json', './build/**/*.js'], { base: './build'} )
        .pipe(revCollector() )
        .pipe(addDomain() )
        .pipe(mdMerger.collect() )
        .pipe(gulp.dest('../public-c') );

    console.log("[js文件压缩]");
    yield gulp.src(['../public-c/js_cmd/**/*.js', '!../public-c/js_cmd/**/*-417.js'], {base: '../public-c'} )
        .pipe(mdMerger.merge() )
        .pipe(gulp.dest('../public-c') );

    // 资源替换到ejs
    console.log("[修改ejs对js的引用]");
    yield gulp.src(['../public-c/rev-2/rev-manifest.json', '../views-c/**/*.ejs'] )
        .pipe(revCollector() )
        .pipe(addDomain() )
        .pipe(gulp.dest('../views-c') );
});


gulp.task('js-version', function(){
	console.log("[修改时间戳文件，以清缓存]");
	return gulp.src(['../worker.js'])
		.pipe(reVersion() )
		.pipe(gulp.dest('../'));
});

gulp.task('clean-build', ['step2'], function(){
	console.log("[清除build临时目录]");
	return gulp.src(['./build', '../public-c/rev-{1,2,3}'])
		.pipe(clean({
			force: true
		}) );
});

gulp.task('step0', function(){
	console.log("[清除自动构建目录]");
	return gulp.src(['../public-c', '../views-c', './build'])
		.pipe(clean({
			force: true
		}) );
});

gulp.task("default", ["step0", "step1", "step2", "js-version", "clean-build"], function(){
	console.log("success");
} );

//