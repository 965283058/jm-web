define(function(require, exports, module){
    var Swipe = require("lib_cmd/swipe-cmd");

	var imagePreview = function () {
		var imgsObj = {}, groupObj = {} , groupId = 1000, et = null, current;
		$('*[data-widget="img_prev_view"]').forEach(function(dw){
			groupObj = {};
			groupId += 1;
			imgsObj[groupId] = [];
			(function(groupId){
				$(dw).on("click", function(evt){
					et = evt.target;
                    if ("IMG" == et.tagName) {
                        if (/^data:image/.test(et.src)) {
                            current = et.dataset.img|| et.dataset.imgsrc;
                        } else {
                            current = et.src;
                        }
                        if (typeof window.WeixinJSBridge != 'undefined') {
                            WeixinJSBridge.invoke('imagePreview', {'current': current, 'urls': imgsObj[groupId]});
                        } else {
                            previewImage({'current': current, 'urls': imgsObj[groupId]});
                        }
                    }
				}).find("img").forEach(function(v){
					var dataImg = v.dataset.img|| v.dataset.imgsrc|| v.src;
					groupObj[dataImg] = dataImg;
				});
				//数组去重复
				imgsObj[groupId] = Object.keys(groupObj);
			})(groupId);
		});
	};

    /**
     * 预览图片(微信外)
     * @param options {
     *            current: '', // 当前显示的图片链接
     *            urls: [] // 需要预览的图片链接列表
     *        }
     */
    function previewImage(options) {
        options = options || {};
        var ulHtml = [],
            urls = options.urls || [],
            currIndex = urls.lastIndexOf(options.current),
            winH = window.innerHeight;
        urls.forEach(function (url) {
            ulHtml.push('<li><div style="height:'+ winH +'px;" class="img-wrap"><img src="' + url + '"></div></li>');
        });
        ulHtml = ulHtml.join('');

        dialog("", {
            TPL: '<div style="z-index:{zIndex2};" class="widget-preview"><ul>' + ulHtml + '</ul><div class="widget-preview-indicate"></div></div>',
            classes:'dialog-preview-widget',
            clickFn: function() {
                this.destroy();
            }
        }).open();
        // 渲染Swipe
        new Swipe($(".widget-preview")[0], {
            speed: 500,
            startSlide: currIndex,
            indicate: ".widget-preview-indicate"
        });
    }

    module.exports = imagePreview;
});