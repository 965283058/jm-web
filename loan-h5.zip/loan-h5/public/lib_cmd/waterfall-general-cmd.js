/**
 * 通用的瀑布流展示插件
 */
define(function (require, exports, module) {
	var $ = require("lib_cmd/zepto-cmd");
	/**
	 * 瀑布流展示类
	 * @param obj {String} DOM元素ID
	 * @param options {Object} 配置参数
	 */
	function waterfall (obj, options) {
		this.container = $('#'+obj);
		if (!this.container) return null;
		//retreive options
		this.options = options || {};
		this.columns = this.options.columns || 2; //瀑布流列数
		this.getTpl = this.options.getTpl || function (arg) {return '';}; //展示数据模板方法
		//
		this.colsHeight = []; //存储各列的高度
		this.water = null; //存储需要显示的数据
		//
		this.init();
	}
	waterfall.prototype = {
		//初始化
		init: function () {
			var self = this;
			var TPL_COL = '';
			for (var i = 0; i < self.columns; i++) {
				TPL_COL += '<ul id="waterfall_col' + i +'"></ul>';
				self.colsHeight[i] = {colNum: i, height: 0};
			}
			self.container.html(TPL_COL);
		},
		//设置需要展示的数据，格式必须为[{},{},{}...]
		setData: function (data) {
			var self = this;
			//判断是否为数组
  			if (Object.prototype.toString.call(data) !== '[object Array]') {
  				return self;
  			}
  			//
  			self.water = data;
  			return self;
		},
		//展示数据
		display: function (callback) {
			var self = this,
				dropSeq = 0; //显示到哪一个数据
			//递归
			function recursive(){
				//对添加商品信息后的各列按高度重新升序排序
				self.colsHeight.sort(function (a, b) {
					return a.height - b.height == 0 ? a.colNum - b.colNum : a.height - b.height;
				});	
				//加一个商品至最短列,待加载完毕重写该列高度
				if(self.water[dropSeq]){
					var drop = [self.water[dropSeq]];   //获取一个商品数据
					var html = self.getTpl(drop);       //生成该商品数据的展示模板
					var id = self.colsHeight[0].colNum; //获取最短列的id
					$('#waterfall_col'+id).append(html); //将数据添加到最短的列
					dropSeq++;
					$('#waterfall_col'+id).find('img').last()[0].onload = function () {
						self.colsHeight[0].height = $('#waterfall_col'+id).height();
						if(self.water[dropSeq]){
							recursive();
						} else {
							//所有图片都已加载完，执行回调
							if (callback) {
								callback();
							}
						}
					}
				}
			}
			recursive();
		},
		//重置函数，用于清楚存储的各列高度
		reset: function () {
			var self = this;
			self.colsHeight = [];
			for (var i = 0; i < self.columns; i++) {
				self.colsHeight[i] = {colNum: i, height: 0};
			}
			self.water = [];
			return self;
		}
	}

	module.exports = waterfall;
});