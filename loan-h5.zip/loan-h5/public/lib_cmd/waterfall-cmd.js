define(function(require, exports, module){
	var $ = require('lib_cmd/zepto-cmd'),
		main = require("js_cmd/main-cmd"),
		iTemplate = require('lib_cmd/iTemplate-cmd');

	var waterfall = function(element, options){
		if(!element) return null;

		//retreive options
		this.options = options || {};
		this.columns = this.options.columns || 2; //瀑布流列数
		this.pageSize = this.options.pageSize || 10; //每次加载商品数
		this.url = this.options.url; //为获取商品信息所需请求的地址
		this.curPage = this.options.cur || 1; //当前页
		this.colsHeight = []; //存储各列的高度
		this.isBind = false; //是否绑定滚动加载事件
		this.totle = this.options.total || 0; //总页数
		this.lock = false; //防止连续滚动所造成的重复加载请求
		this.monthNew = options.monthNew; //判断是否是本月上新
		//retreive dom elements
		this.container = $(element);
		//ajax参数
		this.category_id = this.options.category_id;
		this.ajaxMethod = this.options.category_id ? 'POST' : 'GET';

		//加载动画
		main.eles.loading('.div-section-hot');
		this.loader = $('#J_Loading');

		//商品信息模板
		this.TPL = '<li>\
						<a href="/buyer/goods/detail?sid='+ APP.shopInfo.shop_id +'&gid={wk_itemid}">\
							<figure>\
								<div>\
									<span class="recommend {recommend}">店长推荐</span>\
									<img src="{index_image}" />\
								</div>\
							</figure>\
							<figcaption>\
								<p>{title}</p>\
								<p><span>￥{sale_price_1}</span><span>.{sale_price_2}</span></p>\
							</figcaption>\
						</a>\
					</li>';

		//this.init();
	}
	waterfall.prototype = {
		init: function(alreadyLoadData){ //alreadyLoad表示初始化之前是否已加载过一次数据
			var self = this;
			var TPL_COL = '';
			for(var i = 0; i<self.columns; i++){
				TPL_COL += '<ul id="waterfall_col' + i +'"></ul>';
				self.colsHeight[i] = {colNum: i, height: 0};
			}
			self.container.html(TPL_COL);
			//初次加载
			if(alreadyLoadData){
				self.appendInitData(alreadyLoadData);
			}
			else{
				self.loadList();
			}
		},
		appendInitData: function(data){
			var self = this,
				res_sim = data,
				k_sim = 0;
			//递归
			function recursive(){
				//对添加商品信息后的各列按高度重新升序排序
				self.colsHeight.sort(function(a, b){
					return a.height - b.height;
				});	
				//加一个商品至最短列,待加载完毕重写该列高度
				if(res_sim[k_sim]){
					var data_tmp = [res_sim[k_sim]];
					var html = iTemplate.makeList(self.TPL, data_tmp, function(k,v){
						var str = v.sale_price.toString().split(".");
						return {
							recommend: v.is_recommend == 1 ? '' : 'off',
							sale_price_1: str[0] || "0",
							sale_price_2: str[1] || "00"
						}
					});
					var id = self.colsHeight[0].colNum;
					$('#waterfall_col'+id).append(html);
					k_sim++;
					$('#waterfall_col'+id).find('img').last()[0].onload = function(){
						self.colsHeight[0].height = $('#waterfall_col'+id).height();
						if(res_sim[k_sim]){
							recursive();
						}
					}
				}
			}
			recursive();
		},
		loadList: function(){
			var self = this;
			self.lock = true;//锁定，防止多次加载
			var ajaxData = {};
			if(self.category_id){
				ajaxData = {
					category_ids: [self.category_id],
					page_size: self.pageSize,
					page_num: self.curPage
				};	
			}
			else{
				ajaxData = {
					cur: self.curPage,
					pageSize: self.pageSize,
					monthNew: self.monthNew
				};
			}
			if(self.loader.length && self.loader.css('visibility') == 'hidden'){
				self.loader.css('visibility', 'visible');
			}
			$.ajax({
				type: self.ajaxMethod,
				url: self.url,
				data: ajaxData, 
				dataType: 'json',
				success: function(res){
				self.loader.css('visibility', 'hidden');
				res = res[self.category_id] ? res[self.category_id] : res;
				if(!res.data.data_lists.length){
					return;
				}
				else{
					self.curPage += 1;
					self.lock = false;//解锁
					//若加载页大于总页数，则去掉滚动请求数据事件
					if(self.curPage > self.total && self.isBind){
						$(window).off('scroll');
					}
					var res_sim = res.data.data_lists,
						k_sim = 0;
					//递归
					function recursive(){
						//对添加商品信息后的各列按高度重新升序排序
						self.colsHeight.sort(function(a, b){
							return a.height - b.height;
						});	
						//加一个商品至最短列,待加载完毕重写该列高度
						if(res_sim[k_sim]){
							var data_tmp = [res_sim[k_sim]];
							var html = iTemplate.makeList(self.TPL, data_tmp, function(k,v){
								var str = v.sale_price.toString().split(".");
								return {
									recommend: v.is_recommend == 1 ? '' : 'off',
									sale_price_1: str[0] || "0",
									sale_price_2: str[1] || "00"
								}
							});
							var id = self.colsHeight[0].colNum;
							$('#waterfall_col'+id).append(html);
							k_sim++;
							$('#waterfall_col'+id).find('img').last()[0].onload = function(){
								self.colsHeight[0].height = $('#waterfall_col'+id).height();
								if(res_sim[k_sim]){
									recursive();
								}
							}
						}
					}
					recursive();
				}
				
			},
			error: function(){
				alert('error');
			}
		});
		},
		bindSc: function(){
			var self = this;
			$(window).on('scroll', function(){
				if(!self.lock){
					if($(this).height() + $(this).scrollTop() > $('body').height() - 200){
						self.loadList();
					}
				}
			});
			self.isBind = true;
			return self;
		}
	}

	module.exports = waterfall;
})
