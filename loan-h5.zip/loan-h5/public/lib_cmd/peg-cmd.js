/**
 * 元素固定插件,目前只支持吸顶，留待扩展
 */
define(function (require, exports, module) {
	function peg (options) {
		//获取配置参数
		this.el = document.getElementById(options.element);
		if (!this.el) {
			return;
		}
		this.position = options.position || "top";
		this.custom = options.custom; //{top: 10px; left: 10px;}
		//定义样式
		this.cssTop = "position: fixed; top: 0; left: 0; z-index: 100;";
		//执行
		this.fix();
	}
	peg.prototype = {
		fix: function () {
			var self = this,
				initPosition = self.el.offsetTop,
				checkPostion = "top"; //默认为top

			if (self.position.toLowerCase() === "top") {
				checkPostion = "top";
			}

			window.onscroll = function () {
				//获取目前滚动到的位置
				var currentPostion = document.documentElement.scrollTop || document.body.scrollTop;
				//
				if (checkPostion === "top") {
					if (initPosition <= currentPostion) {
						self.el.style.cssText = self.custom || self.cssTop;
					} else {
						self.el.style.cssText = "";
					}
				}
			}
		}
	}

	module.exports = peg;
});