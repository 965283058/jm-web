define(function(require, exports, module){
    var $ = window._$ = require("lib_cmd/zepto-cmd"),
    	main = require("js_cmd/main-cmd"),
    	iTemplate = require("lib_cmd/iTemplate-cmd"),
    	iScroll = require("lib_cmd/iScroll-cmd"),
    	touchApp = require("js_cmd/touchApp-cmd");

    var $eles = {},
		eles = {};

	var appVersionOrder = 320; //能跳APP原生订单确认页的最低版本app
    var TA = new touchApp();
   	var skuDialogScroll = null;
	var currentGoodsInfo = APP.goodsInfo; //当前使用的商品信息，不再直接从currentGoodsInfo中调
	/**
	 *用于和外部通信的信息,通过initThisWidget.setInfo来设置
	 *目前已定的格式有
	 * {
		inAPP: true/false, //判断是否走app下单
		topic: '', //专题名称
		tuanId: 234234, //参团id，可用来判断是参团还是开团
		isPintuan: true/false, //判断是开团还是单独购买
		notShow: 1//若为1则不显示sku弹框
	 * }
	 */
	var _info = {};

    function initThisWidget () {
    	defineElements();
    	//
		initPage();
    }
    initThisWidget.prototype = {
    	//设置商品信息，默认是用currentGoodsInfo
    	setGoodsInfo: function (goodsInfo) {
    		currentGoodsInfo = goodsInfo;
    		eles.sku = goodsInfo.sku;
    		eles.sku_name_list = goodsInfo.sku_name_list;
    	},
    	//用来这是该文件中的全局变量，以便触发事件调用
    	setInfo: function (args) {
    		_info = args;
    	}
    }

    function initPage(){
		//需要初始化两遍
		_info.isPintuan = true;
		eles.sku = currentGoodsInfo.sku;
		eles.sku_name_list = currentGoodsInfo.sku_name_list;
		_info.isPintuan = false;
		eles.sku = currentGoodsInfo.sku;
		eles.sku_name_list = currentGoodsInfo.sku_name_list;
		
		// if( (2 != currentGoodsInfo.product_type && 1 != currentGoodsInfo.shelves) || (2 == currentGoodsInfo.product_type && (1!=currentGoodsInfo.shelves || 1!= currentGoodsInfo.shop_shelves ) )  ){
		// 	//商品已下架
		// 	eles.btip_widget_config = [1, "商品已经下架啦~"];
		// }else if(0 == currentGoodsInfo.total_sku_num){
		// 	//商品已售完
		// 	eles.btip_widget_config = [1, "商品已经售完啦~"];
		// }else if(2== currentGoodsInfo.is_del ||(2 == currentGoodsInfo.product_type && currentGoodsInfo.wp_is_del) ){
		// 	//商品已删除
		// 	eles.btip_widget_config = [1, "商品已经删除啦~"];
		// }else if("yiyuangou"=== APP.topic){
			
		// }else{
            // 如果只有一个规格，则默认选中该规格
            eles.useDefaultSku&& setDefaultSku(true);
			
			$eles.btn_sku_dialog_close.on("click", function(evt){
				eles.sku_dialog_show = !eles.sku_dialog_show;
			});
			//确认页面立即购买点击事件
			$eles.btn_sku_dialog_buy.on("click", function(evt){
				if(APP.isSelfShop){
					return alert("您不能购买自己的商品哦！");
				}
				if(!eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku']){
					tip("请选择规格");
					return;
				}
				buy(evt);
			});
			//H5购买
			$eles.btn_buy.on("click", function(evt){
				main.checkLogin(evt, null, function(){
					//只显示确认按钮					
					eles.sku_dialog_show = {value: !eles.sku_dialog_show, okBtnTrigger: $eles.btn_sku_dialog_buy};					
					return;
				});
			});
			//APP购买
			$eles.btn_buy_app.on('click', function (evt) {
				eles.sku_dialog_show = {value: !eles.sku_dialog_show, okBtnTrigger: $eles.btn_sku_dialog_buy};
			});
		//}
		$eles.detail_navs.find("a").on("click", function(evt){
			var idx = this.getAttribute("data-idx");
			eles.detail_navs_idx = idx;
		});
	}

	function buy(evt){
		if(!eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'].wp_sku_id){
			tip("请选择规格");
			return;
		}
		if (_info.inApp) { //走APP
			var isWp=!!!currentGoodsInfo.wk_itemid;
			var args = {
            	destClassName: TA.NativeView.ConfirmOrder,
            	segue: {
               		wp_goods_id: currentGoodsInfo.wk_itemid || currentGoodsInfo.wp_goods_id,
                	aid: isWp?currentGoodsInfo.aid:'0',
                	goodsDetail: {
                   		goodsSkuId: eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'].wk_itemid || eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'].wp_sku_id,
                    	goodsNum: eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'].sum,
                    	bizType: _info.bizType,
                    	bizItemId: _info.bizItemId,
                    	bizActivityId: _info.bizActivityId
                	}
            	}
        	};
        	//判断是否是专题商品
        	if (_info.topic) {
        		args.segue.topic = _info.topic;
        	}
        	TA.jump(args);
		} else { //走H5
			cartOrders();
		}
		
		function cartOrders(){
			var _l = loading();
			var isWp=!!!currentGoodsInfo.wk_itemid;
			var goods_data = [{
				shop_id: isWp?'0':APP.shopId,
				aid:isWp?currentGoodsInfo.aid:'0',
				share_shop_id:isWp ? (APP.param ? APP.param.vid || '' : '') : '',
				goods: [{
					goods_id:currentGoodsInfo.wk_itemid || currentGoodsInfo.wp_goods_id,
					good_sku_id:eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'].wk_itemid || eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'].wp_sku_id,
					goods_num:eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'].sum
				}]
			}];
			//判断是否为专题商品
			if(_info.topic){
				goods_data[0].topic=_info.topic;
				//判断是否为团购
				if('pintuan'==_info.topic && currentGoodsInfo.pintuan && currentGoodsInfo.pintuan.activityId){
					goods_data[0].goods[0].biz_type=1;
					goods_data[0].goods[0].biz_activity_id=currentGoodsInfo.pintuan.activityId;
					//是参团还是开团
					if (_info.tuanId) {
						goods_data[0].goods[0].biz_item_id = _info.tuanId; //是参团，传团id
					}
				}
			}
			$.ajax({
				type: "POST",
				url: APP.urls.cartSplitOrders_url,
				//cache: false,
				data: {
				   goods_data: goods_data,
				   city_id: APP.address_city || '110100',
    		   	   from_where: 0
				},
				async:true,
				success: function(result){
					_l.destroy();
					if(0 == result.code){
						console.log(result.data);
						submit(result.data);
					}else{
						alert(result.message);
					}
				},
				dataType: "json"
			});
		}

		function submit(value){
			var form = document.createElement('form'),
			hidden = document.createElement('input');

			var postPage=APP.urls.balanceCenter_page,
				__checkInfo = {
					goodsList: value,
					from: 'detail'
				};
			// 当拆单数据只有1个，且tax_message 为空
			if(__checkInfo.goodsList && 1==__checkInfo.goodsList.length){
        		postPage=APP.urls.check_page;
        		__checkInfo.goodsList=__checkInfo.goodsList[0];
			}

			hidden.setAttribute('type', 'hidden');
			hidden.value = JSON.stringify(__checkInfo);
			hidden.setAttribute('name', '__checkInfo');

			form.appendChild(hidden);
			form.setAttribute('method', 'POST');
			form.setAttribute('action', postPage);
			form.submit();
		}
	}
	function initSkuDialogScroll(){
		skuDialogScroll = new iScroll(document.getElementById("scroller_sku_list"),{
			hideScrollbar:false,
			handleClick:false,
			onBeforeScrollStart: function(e){}
		});
		initSkuDialogScroll = function(){}
		$eles.sku_dialog_min.on("click", function(evt){
			var cur_sku= null;
			//console.log(eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku']);
			if(eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku']){
				cur_sku = eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'];
				cur_sku.sum -=1;
			}else if(eles.sku_name_list.length>0){
				return;
			}else{
				var ks = Object.keys(eles.sku);
				cur_sku = eles.sku[ks[0]||0];
			}
			eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'] = cur_sku;
		});
		$eles.sku_dialog_plus.on("click", function(evt){
			var cur_sku= null;
			if(eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku']){
				cur_sku = eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'];
				cur_sku.sum +=1;
			}else if(eles.sku_name_list.length>0){
				return;
			}else{
				var ks = Object.keys(eles.sku);
				cur_sku = eles.sku[ks[0]||0];
			}
			eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'] = cur_sku;
		});
		$eles.sku_dialog_number.on("change", function(evt){
			var cur_sku= null;
			if(eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku']){
				cur_sku = eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'];
			}else if(eles.sku_name_list.length>0){
				return;
			}else{
				var ks = Object.keys(eles.sku);
				cur_sku= eles.sku[ks[0]||0];
			}
			cur_sku.sum = parseInt(evt.target.value);
			eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'] = cur_sku;
		});
	}

	//初始化skuDialog数据
	function initSkuDiaogDate(sku_name_list){
		var that = this;
		var TPL_section = '<section>\
							<div>\
								<label>{name}</label>\
							</div>\
							<div>\
								{skus}\
							</div>\
						</section>',
			TPL_sku = '<label class="label-radio">\
						<input type="radio" name="sku_{idx}" value="{val}"/>\
						<span>{name}</span>\
					</label>',
			HTML = '',
			HTML_sku = "";
		HTML = iTemplate.makeList(TPL_section, sku_name_list, function(k, v){
			//that.KEYS[k] = [];
			HTML_sku = iTemplate.makeList(TPL_sku, v.list_val, function(kk, vv){
				//that.KEYS[k].push(vv.key);
				return {
					idx: k
				}
			});
			return {
				skus: HTML_sku
			}
		});
		$eles.sku_dialog_list_sku.html(HTML);
	}
	//sku规格选择事件
	function initSkuDataEvt(){
		var that = this,
			checkeds = [];
		var $inputs = $eles.sku_dialog_list_sku.find("input");
		$inputs.on("click", skuCalc);
		//
		var invalidKEYS = [];
		
		skuCalc();
		function skuCalc(evt){
			var _this = this;
			checkeds = [];
			$inputs.forEach(function(v){
				// if((_this.name == v.name) && (v!=_this) ){
				// 	v.checked = false;
				// 	v.removeAttribute("checked");
				// }
				if(v.checked){
					checkeds.push(v.value);
				}
			});
			//根据条件对input进项状态处理
			for(var i=0, ci, sum = 0, flag = true; ci = $inputs[i]; i++){
				/*1:默认计算相关规格是否可购买*/
				ci.disable1 = 0;
				sum = 0;
				for(var j in that.sku){
					var reg = new RegExp('\\b'+ci.value+'\\b', 'gi');
					if(reg.test(j) ){
						eles.ch
						sum += that.sku[j].sku_num;
					}
				}
				if(0 == sum){
					ci.disable1++;
				}else{
					
				}
				/*2:根据已选中的规格判断是否可购买*/
				if(checkeds.length){
					ci.disable2 = 0;
					//对已选中的商品进行各种组合
					var zh = getZuhe(checkeds);
					zh.forEach(function(zv, zi){
						var sum = 0, _inArr = false;
						for(var j in that.sku){
							var inArr = zv.every(function(v){
								var reg = new RegExp('\\b'+v+'\\b', 'gi');
								return reg.test(j);
							});
							if(inArr){
								var reg = new RegExp('\\b'+ci.value+'\\b', 'gi');
								if(reg.test(j)){
									_inArr = true;
									sum += that.sku[j].sku_num;
								}
							}
						}
						if(0 == sum && _inArr){
							ci.disable2++;
						}else{
							
						}
					});
					
				}
				//
				if(ci.disable1 || ci.disable2){
					ci.setAttribute("disabled", "disabled");
				}else{
					ci.removeAttribute("disabled");
				}
			}
			if (checkeds.length == eles.sku_name_list.length) {
				eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'] = eles.sku[checkeds.join(":")];
			}else{
				eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'] = eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'] || {};
			}
			eles.checkeds = checkeds;
		}
	}
	//
	function getZuhe(arr){
		//arr_temp checked 选中的组合s
		var arr_temp = [];
		for(var i=0, ci; ci = arr[i]; i++){
			for(var j=0, len = arr_temp.length, cj; cj = arr_temp[j]; j++){
				if(j>=len){
					break;
				}
				var t = cj.slice(0);
				t.push(ci);
				arr_temp.push(t);
			}
			arr_temp.push([ci]);
		}
		return arr_temp;
	}

    // 设置默认选中规格
    function setDefaultSku(checkUnique) {
        var skuList = eles.sku_name_list,
            unique = true, // 规格是否唯一(仅当每个类别仅有一个规格时为true)
            skuObj = null,
            valArr = [];
        for (var i = 0, len = skuList.length; i < len; i++) {
            skuObj = skuList[i] || {};
            if (Array.isArray(skuObj.list_val)) {
                if (skuObj.list_val.length > 1) {
                    unique = false;
                }
                valArr.push((skuObj.list_val[0] || {}).val);
            }
        }
        if (checkUnique && !unique) {
            return;
        }

        // 选中每个类别的第一个规格
        for (i = 0, len = valArr.length; i < len; i++) {
            if (valArr[i]) {
                $("input[value='" + valArr[i] + "']").trigger('click');
            }
        }
    }
    //设置默认选中和默认数据
	function setDefaultChecked(checkedObject){
		var skuListString="";
		checkedObject=checkedObject || {};
		if(checkedObject.key){
			var $dom=null;
			$eles.sku_dialog_list_sku.find("input").forEach(function(dom,i){
				$dom=$(dom);
				if(checkedObject.key.indexOf($dom.val())>-1){
					skuListString+='"'+$dom.trigger('click').next().text()+'" ';
				}
			});
		}

		var saleObject={
			price:null,
			subtitle: null,
			num: null
		};
		(function(checkedObject){
			if(checkedObject.sale_price){
				saleObject.price=formatPrice("￥"+checkedObject.sale_price.toFixed(2));
			}else{
				saleObject.price=getPrice(currentGoodsInfo.sale_prices)
			}
			saleObject.subtitle=checkedObject.showLabel?!skuListString?'':'已选 '+skuListString:'请选择 '+getSkuName(currentGoodsInfo.sku_name_list);
			saleObject.num=isNaN(checkedObject.sum)?0:checkedObject.sum;
		})(checkedObject);
		var goodsInfo=currentGoodsInfo;
		$eles.sku_dialog_label_sale_price.html(saleObject.price);
		$eles.sku_dialog_label_title.html(saleObject.subtitle);
		$eles.sku_dialog_number.val(saleObject.num);
		$eles.sku_dialog_label_inventory.html("	(剩余"+ (checkedObject.sku_num||goodsInfo.total_sku_num) + (goodsInfo.buy_limit>0? ("，限购"+goodsInfo.buy_limit+"件"):"件") +")"); //	(剩余99，限购2件)
		$eles.sku_dialog_number.trigger('change');
		function getPrice(currentPrice){
			if(currentPrice.length>1 && currentPrice[0].toFixed(2) != currentPrice.slice(-1)[0].toFixed(2)){
				return formatPrice('￥'+currentPrice[0].toFixed(2))+' ~ '+formatPrice('￥'+currentPrice.slice(-1)[0].toFixed(2));
			}else{
				return formatPrice('￥'+currentPrice[0].toFixed(2));
			}
		}

		function getSkuName(skuNameList){
			if(!skuNameList) return '';
			var _res='';
			skuNameList.forEach(function(obj){
				_res+=obj.name+' ';
			})
			return _res;
		}
	}
	//
	function formatPrice(str){
		return str.replace(/\d{1,}(?=\.)/g, function($1, $2){
			return '<span>'+$1+'</span>';
		});
	}
    /**
     * 规格弹出层按钮显示：
     *     当商品规格未选中，点击加入购物车/立即购买，跳出的弹窗应只显示“确认”按钮，点击后购物车加1/到下单页。
     * @param okBtnTrigger 确认按钮处理逻辑
     */
    function displaySkuDialogBtn(okBtnTrigger) {
    	var _okBtnTriger= null;
    	$eles.btn_sku_dialog_ok.click(function(evt){
    		console.log(typeof _okBtnTriger);
    		_okBtnTriger&& _okBtnTriger.trigger("click");
    	});
    	displaySkuDialogBtn= function(okBtnTrigger){
    		$eles.btn_sku_dialog_add2shopcart.css("display", okBtnTrigger ? 'none' : 'block');
	        $eles.btn_sku_dialog_buy.css("display", okBtnTrigger ? 'none' : 'block');
	        $eles.btn_sku_dialog_ok.css("display", okBtnTrigger ? 'block' : 'none');
	        _okBtnTriger= okBtnTrigger;
    	}
    	displaySkuDialogBtn(okBtnTrigger);
    	return displaySkuDialogBtn;
    }

	/**********************************
		页面初始化函数
	**********************************/
	function defineElements () {
		//页面操作所需元素对象
		$eles = {
			btn_add2favourite: $("#btn_add2favourite"),
			list_topic: $("#list_topic"),
			comment_info_box:$("#comment_info_box"),
			//
			//label_sku_price: $("#label_sku_price"),
			label_sale_price: $("#label_sale_price"),
			//
			link_show_sku_dialog: $("#link_show_sku_dialog"),
			//
			detail_navs: $("#detail-navs"),
			detail_sections: $("#detail_sections>section"),
			//btn_moreComments:$("#btn_moreComments"),	
			//
			sku_dialog: $("#sku_dialog"),
			btn_sku_dialog_close: $("#btn_sku_dialog_close"),
			sku_dialog_label_title: $("#sku_dialog_label_title"),
			sku_dialog_label_sale_price: $("#sku_dialog_label_sale_price"),
			sku_dialog_list_sku: $("#sku_dialog_list_sku"),
			sku_dialog_table_number: $("#sku_dialog_table_number"),
			sku_dialog_label_inventory: $("#sku_dialog_label_inventory"),
			sku_dialog_btn_group: $("#sku_dialog_btn_group"),
			sku_dialog_min: $("#sku_dialog_min"),
			sku_dialog_plus: $("#sku_dialog_plus"),
			sku_dialog_min_box: $("#sku_dialog_min").parent('div'),
			sku_dialog_plus_box: $("#sku_dialog_plus").parent('div'),
			sku_dialog_number: $("#sku_dialog_number"),
			btn_sku_dialog_add2shopcart: $("#btn_sku_dialog_add2shopcart"),
			btn_sku_dialog_buy: $("#btn_sku_dialog_buy"),
			btn_sku_dialog_ok: $("#btn_sku_dialog_ok"),
			//底部导航
			btip_widget: $("#btip_widget"),
			link_shopcart: $("#link_shopcart"),
			btn_add2shopcart: $("#btn_add2shopcart"),
			btn_buy: $("#btn_buy"),
			btn_buy_app: $("#btn_buy_app"),//在app内购买
			freight_txt: $('#freight_txt'),
			box_favNum:$('#box_favNum')
		}
		//
		eles = (function(){
			function Eles(){
				var sku = null;
				var sku_name_list = null;
				var cur_sku = null;
				var cur_pintuan_sku = null;
				var sku_dialog_show = false;
				//收藏状态
				var fav_status = false;

				var sku_btn_disabled=[true,false];//控制购买时候的数量+/-的变灰情况
				//辅助
				var checkeds = [];
				btip_widget_config = [false, false];

				this.useDefaultSku= false; //是否开启默认规则选中的初始化
				//
				var current_shop_id= 0;

				//
				var detail_navs_idx = 0;
				//更多评论
				var moreComments= false;

				Object.defineProperty(this, "sku_dialog_show", {
					get: function(){
						return sku_dialog_show;
					},
					set: function(v){
                        if ($.isPlainObject(v)) {
                            sku_dialog_show = v.value;
                            displaySkuDialogBtn(v.okBtnTrigger);
                        } else {
                            sku_dialog_show = v;
                            displaySkuDialogBtn();
                        }
                        // 如果是多规格，则默认选择第一个规格
                        if (eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'] && sku_dialog_show) {
                        	//eles.useDefaultSku && setDefaultSku();
                        	//当规格只有一个的时候，默认选中，当规格多个的时候均不选中
                            var $inputs = $eles.sku_dialog_list_sku.find("input");
                            if(1==$inputs.length){
                            	setDefaultSku();
                            }
                        }else{
                        	if(!eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku']){
								eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku'] = eles.sku[Object.keys(eles.sku)[0]||0];
                        	}
                        }
						$eles.sku_dialog[0].classList[sku_dialog_show?"remove":"add"]("hidden");
						initSkuDialogScroll();

						skuDialogScroll.refresh();
						if (sku_dialog_show) {
                        	setDefaultChecked(eles[_info.isPintuan?'cur_pintuan_sku':'cur_sku']);
						}
					}
				});
				//
				Object.defineProperty(this, "sku_name_list", {
					get: function(){
						return sku_name_list;
					},
					set: function(v){
						sku_name_list = v;
						initSkuDiaogDate.call(this, sku_name_list);
						if(sku_name_list.length>0){
							//绑定规格选择事件
							initSkuDataEvt.call(this);
						}else{
							if(eles.useDefaultSku){
								var ks = Object.keys(this.sku);
								this.cur_sku = this.sku[ks[0]||0];
								eles.checkeds = [0];
							}
						}
					}
				});

				Object.defineProperty(this, "cur_sku", {
					get: function(){
						return cur_sku;
					},
					set: function(v){
						cur_sku = v;
						cur_sku.sum = Math.max(1, Math.min(cur_sku.sku_num, cur_sku.sum) );
						if(0 == cur_sku.sku_num){
							cur_sku.sum = 0;
						}
						$eles.sku_dialog_number.val(cur_sku.sum||0);
						if(cur_sku.sale_price){
							$eles.label_sale_price.html(formatPrice("￥"+cur_sku.sale_price.toFixed(2) ) );
							$eles.sku_dialog_label_sale_price.html("￥"+cur_sku.sale_price.toFixed(2) );
						} else {
							$eles.label_sale_price.html(formatPrice("￥"+currentGoodsInfo.sale_price.toFixed(2) ) );
							$eles.sku_dialog_label_sale_price.html("￥"+currentGoodsInfo.sale_price.toFixed(2) );
						}
						$eles.sku_dialog_label_inventory.html("	(剩余"+ (cur_sku.sku_num||currentGoodsInfo.total_sku_num) + (currentGoodsInfo.buy_limit>0? ("，限购"+currentGoodsInfo.buy_limit+"件"):"件") +")"); //	(剩余99，限购2件)
						eles.checkeds = eles.checkeds;
						eles.sku_btn_disabled=[cur_sku.sum<=1,cur_sku.sum>=cur_sku.sku_num];
						//
						function formatPrice(str){
							return str.replace(/\d{1,}(?=\.)/g, function($1, $2){
								return '<span>'+$1+'</span>';
							});
						}
					}
				});
				//
				Object.defineProperty(this, "cur_pintuan_sku", {
					get: function(){
						return cur_pintuan_sku;
					},
					set: function(v){
						cur_pintuan_sku = v;
						cur_pintuan_sku.sum = Math.max(1, Math.min(cur_pintuan_sku.sku_num, cur_pintuan_sku.sum) );
						if(0 == cur_pintuan_sku.sku_num){
							cur_pintuan_sku.sum = 0;
						}
						$eles.sku_dialog_number.val(cur_pintuan_sku.sum||0);
						if(cur_pintuan_sku.sale_price){
							$eles.label_sale_price.html(formatPrice("￥"+cur_pintuan_sku.sale_price.toFixed(2) ) );
							$eles.sku_dialog_label_sale_price.html("￥"+cur_pintuan_sku.sale_price.toFixed(2) );
						} else {
							$eles.label_sale_price.html(formatPrice("￥"+currentGoodsInfo.sale_price.toFixed(2) ) );
							$eles.sku_dialog_label_sale_price.html("￥"+currentGoodsInfo.sale_price.toFixed(2) );
						}
						$eles.sku_dialog_label_inventory.html("	(剩余"+ (cur_pintuan_sku.sku_num||currentGoodsInfo.total_sku_num) + (currentGoodsInfo.buy_limit>0? ("，限购"+currentGoodsInfo.buy_limit+"件"):"件") +")"); //	(剩余99，限购2件)
						eles.checkeds = eles.checkeds;
						eles.sku_btn_disabled=[cur_pintuan_sku.sum<=1,cur_pintuan_sku.sum>=cur_pintuan_sku.sku_num];
						//
						function formatPrice(str){
							return str.replace(/\d{1,}(?=\.)/g, function($1, $2){
								return '<span>'+$1+'</span>';
							});
						}
					}
				});
				//
				Object.defineProperty(this, "sku", {
					get: function(){
						return sku;
					},
					set: function(v){
						sku = v;
					}
				});
				Object.defineProperty(this, "sku_btn_disabled", {
					get: function(){
						return sku_btn_disabled;
					},
					set: function(v){
						$([$eles.sku_dialog_min_box[0],$eles.sku_dialog_plus_box[0]]).removeClass();
						if(!v || 2!=v.length)
							v=[true,false];
						if(!!v[0])
							$eles.sku_dialog_min_box.addClass('disabled');
						if(!!v[1])
							$eles.sku_dialog_plus_box.addClass('disabled');

					}
				});
				//
				Object.defineProperty(this, "checkeds", {
					get: function(){
						return checkeds;
					},
					set: function(v){
						checkeds = v;
						//已经选中一种明确的组合 
						var checkeds_title = [[], []],
							titles_v = [];
						for(var i=0, ci, flag; ci = this.sku_name_list[i]; i++){
							var _v = "", flag_v = false;
							flag = checkeds.length && ci.list_val.some(function(v, vi){
								flag_v = checkeds.indexOf(v.val)>-1;
								if(flag_v){
									_v = v.name;
								}
								return flag_v;
							});
							if(flag){
								checkeds_title[0].push(ci.name);
								titles_v.push('"'+_v+'"');
							}else{
								checkeds_title[1].push(ci.name);
							}
						}
						//
						var html = ["请选择"];
						var isCountOnly=false,countOnlyHtml=''; //当sku只为数量的时候的判断及文案
						var showLabel='';	//显示结果
						if(checkeds_title[1].length>0){
							html = html.concat(checkeds_title[1]);
							//html.push("数量");
						}else{
							if(titles_v && titles_v.length){
								html = titles_v;//.concat("数量："+ this.cur_sku.sum+"");
								html=['已选'].concat(html);
							}else{
								//本情况为只有数量的情况
								isCountOnly=true;
								countOnlyHtml=html.concat("数量");
								html = titles_v;//.concat("数量："+ this.cur_sku.sum+"");
							}
						}
						showLabel=html.join(" ");
						$eles.sku_dialog_label_title.html(showLabel);
						if(isCountOnly)
							showLabel=countOnlyHtml.join(" ");
						$eles.link_show_sku_dialog.find("div>div").eq(0).html(showLabel);
					}
				});
				//
				Object.defineProperty(this, "fav_status", {
					get: function(){
						return fav_status;
					},
					set: function(v){
						fav_status = v;
						$eles.btn_add2favourite[fav_status?"addClass":"removeClass"]("on");
					}
				});
				//
				Object.defineProperty(this, "detail_navs_idx", {
					get: function(){
						return detail_navs_idx;
					},
					set: function(v){
						detail_navs_idx = v;
						$eles.detail_navs.find("a").removeClass("on").eq(detail_navs_idx).addClass("on");
						$eles.detail_sections.removeClass("on").eq(detail_navs_idx).addClass("on");
					}
				});
				//
				Object.defineProperty(this, "btip_widget_config", {
					set: function(v){
						btip_widget_config = v;
						$eles.btip_widget[v[0]?"removeClass":"addClass"]("hidden").find("#btip_label").html(v[1]);
						$eles.btn_add2shopcart.addClass("disabled");
						$eles.btn_buy.addClass("disabled");
					}
				});
				//
				Object.defineProperty(this, "moreComments", {
					set:function(v){
						if(!APP.comments){
							return;//暂无评价
						}
						moreComments= !!v;
						var l= loading();
						if(v){
							var state= {
								pageName: "comments"
							};
							history.pushState(state, "评论", location.href);
							comments.eles.pageShow= true;
						}
						setTimeout(function(){
							$('header[data-role="header"], section[data-role="body"]')[v?"hide": "show"]();
							comments.$eles.goods_comments[v? "show": "hide"]();
							l.destroy();
						}, 100);
					}
				});

				//
				Object.defineProperty(this, "current_shop_id", {
					get: function(){
						return currentGoodsInfo.aid&&(currentGoodsInfo.aid+"").length>1? currentGoodsInfo.aid: currentGoodsInfo.shop_id;
					}
				});

			}
			return new Eles();
		})();
	}
    module.exports = initThisWidget;
});